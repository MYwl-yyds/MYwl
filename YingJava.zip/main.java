//勿改
String 脚本名称 = "YingJava";
String 脚本作者 = "末影MYwl";
String 脚本版本 = "0.5.7";
long 脚本加载=System.currentTimeMillis();
Thread 附属=new Thread(new Runnable() {
    public void run() {
        loadJava(JavaPath+"/YingJava/附属/import.java");
        loadJava(JavaPath+"/YingJava/附属/YingJava/OtherJava.java");
        loadJava(JavaPath+"/YingJava/附属/YingJava/FileJava.java");
        loadJava(JavaPath+"/YingJava/附属/FunctionJava/GroupsJava.java");
        loadJava(JavaPath+"/YingJava/附属/YingJava/TimeJava.java");
        loadJava(JavaPath+"/YingJava/附属/YingJava.java");
        loadJava(JavaPath+"/YingJava/附属/YingJava/YingJava.java");
        loadJava(JavaPath+"/YingJava/附属/FunctionJava/WxyyJava.java");
    }
});
附属.start();
Thread 系统=new Thread(new Runnable() {
    public void run() {
        loadJava(JavaPath+"/YingJava/系统/菜单.java");
        loadJava(JavaPath+"/YingJava/系统/开关.java");
        loadJava(JavaPath+"/YingJava/系统/自定义脚本/main.java");
        loadJava(JavaPath+"/YingJava/系统/自定义脚本.java");
        loadJava(JavaPath+"/YingJava/系统/群聊系统.java");
        loadJava(JavaPath+"/YingJava/系统/开关系统.java");
        loadJava(JavaPath+"/YingJava/系统/配置设置.java");
        loadJava(JavaPath+"/YingJava/系统/智能系统.java");
        loadJava(JavaPath+"/YingJava/系统/娱乐系统/娱乐系统.java");
        loadJava(JavaPath+"/YingJava/系统/娱乐系统/娱乐_排行榜.java");
        loadJava(JavaPath+"/YingJava/系统/娱乐系统/娱乐_抽卡池.java");
        loadJava(JavaPath+"/YingJava/系统/娱乐系统/娱乐_菜票.java");
        loadJava(JavaPath+"/YingJava/系统/娱乐系统/娱乐/娱乐_个人信息.java");
        loadJava(JavaPath+"/YingJava/系统/娱乐系统/娱乐/娱乐_礼包.java");
        loadJava(JavaPath+"/YingJava/系统/娱乐系统/娱乐/娱乐_签到.java");
        loadJava(JavaPath+"/YingJava/系统/娱乐系统/娱乐_游戏.java");
        loadJava(JavaPath+"/YingJava/系统/娱乐系统/娱乐_井字棋.java");
        loadJava(JavaPath+"/YingJava/系统/娱乐系统/娱乐_银行系统.java");
        loadJava(JavaPath+"/YingJava/系统/娱乐系统/娱乐_打劫系统.java");
        loadJava(JavaPath+"/YingJava/系统/娱乐系统/娱乐_奴隶系统.java");
        loadJava(JavaPath+"/YingJava/系统/娱乐系统/娱乐_商城系统.java");
        loadJava(JavaPath+"/YingJava/系统/娱乐系统/娱乐_婚姻系统.java");
        loadJava(JavaPath+"/YingJava/系统/音乐系统.java");
        loadJava(JavaPath+"/YingJava/系统/定时任务.java");
        loadJava(JavaPath+"/YingJava/系统/整点报时.java");
        loadJava(JavaPath+"/YingJava/系统/查询功能.java");
        loadJava(JavaPath+"/YingJava/系统/站长工具.java");
        loadJava(JavaPath+"/YingJava/系统/图片功能.java");
        loadJava(JavaPath+"/YingJava/系统/短剧功能.java");
        loadJava(JavaPath+"/YingJava/系统/接口功能.java");
    }
});
系统.start();
try {
    附属.join();
    系统.join();
} catch (InterruptedException e) {
    Thread.currentThread().interrupt();
}
long 加载结束=System.currentTimeMillis();
double 加载耗时=(加载结束-脚本加载)/1000.0;
Toast("["+脚本名称+"]加载成功,耗时:"+加载耗时+"秒");