
import netscape.javascript.JSException;

HashMap sendTimeMap = new HashMap();
public void 设置助手(String content, int characterId, int personalityId, String qun) {
    String charactersURL = "https://yiyanapp.baidu.com/api/admin/character/user/set?appname=newapp&sid=1&ut=1&ua=1&bdvc=0&zid=1&cfrom=1&from=1&scheme=1&network=1&ds_stc=1&ds_lv=1";
    String eventMessage = GLM(charactersURL, "{\"characterId\":" + characterId + ",\"personalityId\":" + personalityId + ",\"speed\":2,\"isDefault\":1,\"isOffice\":1}");
    JSONObject firstJsonObject = new JSONObject(eventMessage);
    String errmsg = firstJsonObject.getString("errmsg");
    if ("success".equals(errmsg)) {
        写("Groups/"+qun,"智能系统_文心", "characterId", characterId);
        删("Groups/"+qun,"智能系统_文心", "sessionId");
        删("Groups/"+qun,"智能系统_文心", "parentId");
        删("Groups/"+qun,"智能系统_文心", "上下文");
        sendm(qun, errmsg.replace("success", "设置成功开始新的对话。"),0);
    } else {
        sendm(qun, "设置失败"+errmsg,0);
    }
}
public void 智能系统(Object data) {
    String content = data.content;
    String qun = data.talker;
    String wxid=data.sendTalker;
    String name = getName(wxid);
    if (mWxid.equals(qun)) {
        if (content.startsWith("绑定手机号")) {
            String text = content.substring(5).trim();
            if (text.matches("^[1][3-9][0-9]{9}$")) {
                写("全局/智能系统", "配置", "手机号", text);
                String json = sendPost("https://wappass.baidu.com/wp/api/security/getphonestatus", "username=" + text);
                JSONObject jsonObj = new JSONObject(json);
                String getphonestatus = jsonObj.getJSONObject("errInfo").getString("msg");
                String message = "已成功绑定";
                if (getphonestatus.equals("不存在")) {
                    message += "\n该手机号没有注册百度账号。";
                }
                sendm(qun, message,0);
            } else {
                sendm(qun, "手机号格式不正确，请输入有效的11位手机号。",0);
            }
        }
        if (content.equals("获取验证码")) {
            String phoneNumber = 读("全局/智能系统", "配置", "手机号","");
            if (phoneNumber == null || phoneNumber.isEmpty()) {
                sendm(qun, "请先绑定手机号。",0);
                return;
            }
            String json = sendPost("https://wappass.baidu.com/wp/api/login/sms", "username=" + phoneNumber);
            if (json == null || json.isEmpty()) {
                sendm(qun, "发送验证码失败，请稍后再试。",0);
            return;
            }
            try {
                JSONObject jsonObj = new JSONObject(json);
                String accessToken = jsonObj.getJSONObject("errInfo").getString("msg");
                if (accessToken.equals("发送成功")) {
                    sendm(qun, "验证码发送成功！",0);
                    sendTimeMap.put(qun + wxid, data.createTime);
                } else {
                    sendm(qun, "发送验证码失败：" + accessToken,0);
                }
            } catch (JSONException e) {
                sendm(qun, "解析响应时发生错误：" + e.getMessage(),0);
            }
        }
        if (content.startsWith("填写")) {
            String text = content.substring(2).trim();
            Long sendTime = sendTimeMap.get(qun + wxid);
            if (sendTime == null) {
                return;
            }
            if (text.isEmpty()) {
                sendm(qun, "请输入验证码。",0);
                return;
            }
            if (!text.matches("^[0-9]{1,6}$")) {
                sendm(qun, "验证码格式不正确，请输入有效的数字验证码。",0);
                return;
            }
            String phoneNumber = 读("全局/智能系统", "配置", "手机号","");
            if (phoneNumber == null || phoneNumber.isEmpty()) {
                sendm(qun, "请先绑定手机号。",0);
                return;
            }
            if (data.createTime - sendTime > 120000) {
                sendTimeMap.remove(qun + wxid);
                sendm(qun, "验证码已过期，请重新发送。",0);
                return;
            }
            String jsonString = jsonPost("https://wappass.baidu.com/wp/api/login", "adapter=&alg=v3&baiduId=D09244776DB2F005AA824E24A9330FBB%3AFG%3D1&client=android&clientfrom=native&countrycode=&elapsed=7&encryptedId=&encryptedType=living&extrajson=%257B%2522src%2522%253A%2522newapp_auth%2522%257D&from=sms&fuid=FOCoIC3q5fKa8fgJnwzbE3sZaS3poGTofPItBD67MTHOloTQtOTfZukshuG%2BjikL3DVuo%2BoEAaoaMh0DfSusGhzMQRO1HJDsdbKLu3sE7zNoyfGxQF26EbMs7xcE6wa%2BFtO%2FX3DrXOvwdz4XdlPTscSXOHDp45fH5s50XgdbS8lvPL0O%2BTAyPVpQkqA8uTDR8h7gGjbBmqTpG7EWEYOVkEffRHVQ0ZCSH2kK5BUwLho%2BK%2Bm5yt34J1b38mcnfYJ4T9hewWOCtBIF6R5xxZVDKxhIpo8tzK1xKUriLZyOCg%2BT%2ByBiQdQknC2tNHu28vwejaV%2BOSeOQXPxID1IFTMprZ51iOAQnT1VKe%2FXFXNdnbIaBe50BOc9JkK59WCg2il1zX1kid5l%2FLWpjl%2BbQvb5M%2FMex6iuQhZ2Cahs3Gp92pfMmsJVpQn2jAt%2F8oa7AzX9QJ2d9PBYiHvFkXPB8B7OcVef%2BZQEdv4Xk6oxLbSwl2ac4RwUTUIKBYqJkj%2FvdDT5Azd1piWPzVgXDb6anUQXSqTqtRfLzClYTvrx%2FBmSaeKun%2BpqsqI%2BmxWcBOpDz7pSJIRe3dJwr3xIAX0cdDh7gVdirjaJSd15OAZkSH61woO3XoiK1Q6jm8ifDaTFgO8id9WtLqu%2FN%2BorJimmYmWZjfS6JiKsRDhUpcyZMTvFxmgxamFkuTFIeUjMckiJQW4ILoCrkm8hW9vBus5L2pQrKemCazBpJxzoM1ZvfiMWPRfe11ETS64e6qJhrkEKUVLZXRMKisqLgKhuBHjX3FZpfwgosmJo00s5KFZ1l2VA7YNddXFyKfMoepS9ZNjHjmOyJRWVjvwAdAaiXoIktBDxDv3sxKGVrO91LA9eAk%2FnPS4wmn0v7fH9jYYaFbmyK3nmTCp%2Bd8jLRzvLq4arA4LqbAnXcBRqKssNaF7lLAf5%2F2SLEvf%2BlHHVrxo2eLLjiaQSNX19GvRCXE9euaxv9alXehmqPhwW3AN0n9RlprqIAy0MVF9iO2nXvJbF%2BOyn1dtoYvG9XlaMde0nDMojYM%2F3KWsgTaxN9Hrv5Y7boI3mtAj34kilDqdVbEvi8vfiLqZ%2FzLoFvvQhrdbVoWDGSMB4GOZME9npuM2PYhk99Q40%2BWAwzRo50Ct50x8t5gyP643QwrmanNhKYOyBgAZxlsaae6fyp7sL9nrACHpLGl63ajZd1PmCOjNA43n8dU%2B8olXP8cSTQyUvg5bG6rt5%2BCOubu7x42DfGPRbBCKlIj4Ghwc2j1hG5A7amLiICvNS%2BKT8PFIdu9kJ9rOIZmCBob4FjeyUeWZoaLrpb7p%2B23tbJfBjDnKqt7PnOy%2B6%2FSOYELWf8FBMu6pHv6aNZ%2FWjd3jowaaatICsHnp3D8YEv43dK48%3D&gid=2655F9D-E845-4E43-9679-DAE5D1A6D733&isFromShareLogin=false&isVoiceSmsLogin=0&lang=zh-cn&liveAbility=1&loginFrom=&loginmerge=&noguide=0&passAppHash=484ccfe7ffc755914e85fbbc59b9eb91&passAppVersion=1633938859&regfrom=page&rinfo=%7B%22fuid%22%3A%22d5465c130b820670e826e2333abbc621%22%7D&session_id=2655F9D-E845-4E43-9679-DAE5D1A6D733-v2-1711919972889-login_history&shaOne=00ae4950f0ecdc6398ec03bd95fef901c8aa9bc7&sig=NXlDU3ZiNm94dlVQcCtMdHY2djY1dW1hNmRPWWpWWmtpM2srbTFJcUNSSFNKQjk4SGxOaFJXQkNqV2ZWazY0Kw%3D%3D&sms=1&smsvc="+text+"&subpro=&supFaceLogin=&suppcheck=1&supportCheck=1&time=1711920075&tpl=newapp&tt=1711920074650&u=https%253A%252F%252Fwap.baidu.com&username=" + phoneNumber);
            if (jsonString == null || jsonString.isEmpty()) {
                sendm(qun, "登录请求失败，请稍后再试。",0);
                return;
            }
            try {
                JSONObject jsonObject = new JSONObject(jsonString);
                String accessToken = jsonObject.getJSONObject("errInfo").getString("no");
                if (accessToken.equals("0")||accessToken.equals("400410")) {
                    写("全局/智能系统", "配置", "CK", jsonObject.getJSONObject("data").getString("bduss"));
                    sendm(qun, "登录成功。",0);
                    String mmmmmmm = GLM("https://yiyanapp.baidu.com/api/auth/screen?appname=newapp&sid=66771_3-66901_2-63871_2-66764_3&ut=23013RK75C_14_34_Xiaomi&ua=1080_2268_android_3.0.0.11_420&bdvc=0&zid=7vlmDkz5W2lAhM1xlUZ1ZAiW7onFclGqa67e-lmppsCdchtWFcjEx4X-1H6ingjPn0E_gdTj59sf-GhXdmfO14g&uid=laSlu_iI-8gT8v8E_uSuu_unHaleivuK_avhujuB2tKoLqqqB&cfrom=1033055a&from=1033055a&scheme=baiduwanhua&network=1_-1&c3_aid=A00-HEC7HMOZ22NGIGGB7DSZYWILSF5VBEJQ-A5BDADWY&ds_stc=0.9441&ds_lv=7", "{\"text\":\"13\",\"isQuery\":\"1\",\"promptId\":\"\",\"characterId\":\"1034\",\"chatMode\":0,\"messageType\":\"text\"}");
                } else {
                    sendm(qun, jsonObject.getJSONObject("errInfo").getString("msg"),0);
                }
            } catch (JSONException e) {
                sendMsg(qun, "解析响应时发生错误：" + e.getMessage(),0);
            }
        }
        if(content.startsWith("设置key")) {
            String xhkey = content.substring(5);
            if(xhkey==null||xhkey.equals("")) {
                return;
            }
            写("全局/智能系统","配置","xhAPIPassword",xhkey);
            sendm(qun,"星火AI key 设置成功",0);
        }
        if(content.startsWith("设置模型")) {
        String sjxstr = content.substring(4);
        if(sjxstr==null||sjxstr.equals("")) {
            return;
        }
        if(sjxstr.equals("lite")||sjxstr.equals("generalv3")||sjxstr.equals("pro-128k")||sjxstr.equals("generalv3.5")||sjxstr.equals("max-32k")||sjxstr.equals("4.0Ultra")) {
            写("全局/智能系统","配置","xhmodel",sjxstr);
            sendm(qun,"星火AI模型已设置为"+sjxstr,0);
        }else{
            return;
        }
    }
    }
    if(mWxid.equals(wxid)) {
        if (content.equals("设置依依AI女孩")) {
            设置助手(content, 1034, 1512, qun);
        } else if (content.equals("设置依依二次元萌妹")) {
            设置助手(content, 1034, 1513, qun);
        } else if (content.equals("设置依依骄傲大小姐")) {
            设置助手(content, 1034, 1514, qun);
        } else if (content.equals("设置依依脑洞少女")) {
            设置助手(content, 1034, 1515, qun);
        } else if (content.equals("设置小言AI男孩")) {
            设置助手(content, 1091, 1504, qun);
        } else if (content.equals("设置小言幽默风趣")) {
            设置助手(content, 1091, 1505, qun);
        } else if (content.equals("设置小言温柔暖男")) {
            设置助手(content, 1091, 1506, qun);
        } else if (content.equals("设置小言中二少年")) {
            设置助手(content, 1091, 1507, qun);
        }else if (content.equals("设置费翔")) {
            写("Groups/"+qun,"智能系统_文心", "characterId", 44760);
            删("Groups/"+qun,"智能系统_文心", "sessionId");
            删("Groups/"+qun,"智能系统_文心", "parentId");
            删("Groups/"+qun,"智能系统_文心", "上下文");
            sendm(qun, "设置成功开始新的对话。",0);
        }else if (content.equals("设置洛天依")) {
            写("Groups/"+qun,"智能系统_文心", "characterId", 1135);
            删("Groups/"+qun,"智能系统_文心", "sessionId");
            删("Groups/"+qun,"智能系统_文心", "parentId");
            删("Groups/"+qun,"智能系统_文心", "上下文");
            sendm(qun, "设置成功开始新的对话。",0);
        }else if (content.equals("重置对话")) {
            删("Groups/"+qun,"智能系统_文心", "sessionId");
            删("Groups/"+qun,"智能系统_文心", "parentId");
            删("Groups/"+qun,"智能系统_文心", "上下文");
            sendm(qun,"已重置",0);
        }
    }
    if(content.equals("智能系统")) {
        String text = "◈星火──\n" + 
        "[e]xh+内容\n" + 
        "[e]设置key+APIPassword*\n" + 
        "[e]设置随机性+(0-1)\n" + 
        "[e]设置灵活度+(1-6)\n" + 
        "[e]设置模型+模型类型*\n" + 
        "[e][开启/关闭]多轮对话\n" + 
        "[e]清空对话\n" + 
        "[e]星火AI说明\n" + 
        "◈文心──\n" + 
        "[e]绑定手机号+号码*\n" + 
        "[e]获取验证码*\n" + 
        "[e]填写+验证码*\n" + 
        "[e]glm+内容\n" + 
        "[e]重置对话\n" + 
        "[e]人物设定\n" + 
        "PS:带\"*\"标识需私聊自己发送";
        sendm(qun,text,0);
    }
    if(content.equals("人物设定")) {
        String text = "[e]设置费翔\n[e]设置洛天依\n[e]设置依依AI女孩\n[e]设置依依二次元萌妹\n[e]设置依依骄傲大小姐\n[e]设置依依脑洞少女\n[e]设置小言AI男孩\n[e]设置小言幽默风趣\n[e]设置小言温柔暖男\n[e]设置小言中二少年";
        sendm(qun,text,0);
    }
    if (content.startsWith("GLM")||content.startsWith("glm")) {
        String text = content.substring(3);
        if(text.equals(""))
        {
            return;
        }
        String savedData = 读("Groups/"+qun,"智能系统_文心","上下文","");
        JSONArray data;
        if (savedData.isEmpty()) {
            data = new JSONArray();
        } else {
            data = new JSONArray(savedData);
        }
        String payloadTemplate = "{\"content\":\""+escapeJson(text)+"\",\"sessionId\":\""+读("Groups/"+qun,"智能系统_文心", "sessionId","")+"\",\"contentType\":\"text\",\"parentId\":\""+读("Groups/"+qun,"智能系统_文心", "parentId","")+"\",\"context\":"+data+",\"model\":\"eb35\",\"from\":\"app\",\"promptId\":\"\",\"botId\":\"60725\",\"characterId\":\""+读("Groups/"+qun,"智能系统_文心", "characterId","")+"\",\"environment\":{\"live\":{\"visOnline\":{\"pdt\":\"10170\",\"per\":\"4179\",\"audio_ctrl\":\"{\\\"mid\\\":\\\"\\\",\\\"sampling_rate\\\":24000}\"}},\"interveneId\":\"\",\"hostTag\":\"main_chat\"}}";
        String eventMessage = GLM("https://yiyanapp.baidu.com/chat/completions?appname=newapp&sid=66771_3-68314_1-66901_2-66764_3&ut=23013RK75C_14_34_Xiaomi&ua=1080_2268_android_3.0.0.11_420&bdvc=0&zid=bLawYM-JYFYjli-mR9_1P2ZfQ5VXKKyYsp5nYRnnBTVoqUqouZsIu89rtHeKNI9L9VIQ7NnQiieITjZOhVGEfrA&uid=laSlu_iI-8gT8v8E_uSuu_unHaleivuK_avhujuB2tKoLqqqB&cfrom=1033055a&from=1033055a&scheme=baiduwanhua&network=1_-1&c3_aid=A00-HEC7HMOZ22NGIGGB7DSZYWILSF5VBEJQ-A5BDADWY&ds_stc=0.9441&ds_lv=7&jt=", payloadTemplate);
        if (eventMessage != null && !eventMessage.isEmpty()) {
            String[] lines = eventMessage.split("data:");
            if (lines.length > 1) {
                String firstLine = lines[1].trim();
                if (!firstLine.isEmpty()) {
                    if (!firstLine.endsWith("}")) {
                        firstLine += "}";
                    }
                    try {
                        JSONObject firstJsonObject = new JSONObject(firstLine);
                        if (firstJsonObject.getInt("errno") != 0) {
                            sendm(qun, "错误："+firstJsonObject.getString("errmsg"),0);
                            return;
                        }
                        JSONObject messageInfos = firstJsonObject.getJSONObject("data").getJSONObject("data").getJSONObject("messageInfos");
                        JSONObject ask = messageInfos.getJSONObject("ask");
                        JSONObject answer = messageInfos.getJSONObject("answer");
                        String sessionId = firstJsonObject.getJSONObject("data").getJSONObject("data").getString("sessionId");
                        String askMessageId = ask.getString("messageId");
                        String answerMessageId = answer.getString("messageId");
                        JSONArray messageIdArray = new JSONArray();
                        messageIdArray.put(answerMessageId);
                        messageIdArray.put(askMessageId);
                        String messageIdArrayString = messageIdArray.toString();
                        JSONArray jsonArray1 = new JSONArray(""+data);
                        JSONArray jsonArray2 = new JSONArray(""+messageIdArrayString);
                        JSONArray mergedJsonArray = new JSONArray();
                        for (int i = 0; i < jsonArray1.length(); i++) {
                            mergedJsonArray.put(jsonArray1.get(i));
                        }
                        for (int i = 0; i < jsonArray2.length(); i++) {
                            mergedJsonArray.put(jsonArray2.get(i));
                        }
                        String[] mergedArray = new String[mergedJsonArray.length()];
                        for (int i = 0; i < mergedJsonArray.length(); i++) {
                            mergedArray[i] = mergedJsonArray.getString(i);
                        }
                        写("Groups/"+qun,"智能系统_文心", "上下文",mergedJsonArray.toString());
                        写("Groups/"+qun,"智能系统_文心","parentId",answerMessageId);
                        写("Groups/"+qun,"智能系统_文心","sessionId",sessionId);
                    } catch (JSONException e) {
                        sendm(qun, ""+e,0);
                    }
                }
            }
            StringBuilder content1 = new StringBuilder();
            JSONObject musicData = new JSONObject();
            List imageUrls = new ArrayList();
            for (int i = 1; i < lines.length; i++) {
                String line = lines[i].trim();
                if (!line.isEmpty()) {
                    if (!line.endsWith("}")) {
                        line += "}";
                    }
                    try {
                        JSONObject jsonObject = new JSONObject(line);
                        JSONObject data = jsonObject.getJSONObject("data").getJSONObject("data");
                        String currentContent = data.getString("content");
                        content1.append(currentContent);
                        if (data.has("pluginRsp")) {
                            JSONObject pluginRsp = data.getJSONObject("pluginRsp");
                            if (pluginRsp.has("music")) {
                                JSONObject music = pluginRsp.getJSONObject("music");
                                musicData.put("title", music.getString("name") + "_" + music.getString("author"));
                                musicData.put("description", pluginRsp.getJSONObject("music").getString("lyric"));
                                musicData.put("thumb", music.getString("pic"));
                                musicData.put("musicDataUrl", music.getString("music"));
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
            String messageToSent = content1.toString();
            Pattern imgPattern = Pattern.compile("<img src=\"(.*?)\" ");
            Matcher imgMatcher = imgPattern.matcher(messageToSent);
            while (imgMatcher.find()) {
                imageUrls.add(imgMatcher.group(1));
            }
            messageToSent = messageToSent.replaceAll("<img src=\".*?\" /><br>", "");
            for (String imageUrl : imageUrls) {
                sendPic(qun, imageUrl);
            }
            if (!messageToSent.trim().isEmpty()) {
                if (musicData.length() > 0) {
                    sendm(qun, messageToSent,0);
                    sendMusicCard(qun, musicData);
                } else {
                    sendm(qun, messageToSent,0);
                }
            }
        } else {
            sendm(qun, "没有收到有效的回应。",0);
        }
    }
    if(content.startsWith("xh")) {
        String xhdh = content.substring(2);
        String xhurl = "https://spark-api-open.xf-yun.com/v1/chat/completions";
        String xh上下文 = 读("Groups/"+qun+"/Users",wxid+"_user","星火AI上下文","空");
        String xh随机性 = 读("Groups/"+qun,"智能系统_星火","temperature","0.5");
        String xh灵活度 = 读("Groups/"+qun,"智能系统_星火","top_k","4");
        String xh模型 = 读("全局/智能系统","配置","xhmodel","lite");
        int xh多轮对话 = 读整("Groups/"+qun,"智能系统_星火","多轮对话");
        String xhAPIPassword = 读("全局/智能系统","配置","xhAPIPassword","空");
        if(xhdh==null||xhdh.equals("")) {
            return;
        }else{
            if(xhAPIPassword.equals("空")) {
                sendm(qun,"@"+name+"\n未设置apikey",0);
                return;
            }else{
                if(xh多轮对话==1) {
                    try {
                        String xhdata;
                        if(xh上下文.equals("空")) {
                            xhdata = "{\"model\":\""+xh模型+"\",\"messages\":[{\"role\":\"user\",\"content\":\""+xhdh+"\"}],\"temperature\":"+xh随机性+",\"top_k\":"+xh灵活度+"}";
                        }else{
                            xhdata = "{\"model\":\""+xh模型+"\",\"messages\":["+xh上下文+",{\"role\":\"user\",\"content\":\""+xhdh+"\"}],\"temperature\":"+xh随机性+",\"top_k\":"+xh灵活度+"}";
                        }
                        byte[] input = xhdata.getBytes("utf-8");
                        HttpURLConnection connection = (HttpURLConnection) new URL(xhurl).openConnection();
                        connection.setRequestMethod("POST");
                        connection.setRequestProperty("Content-Type", "application/json");
                        connection.setRequestProperty("Authorization", "Bearer "+xhAPIPassword);
                        connection.setDoOutput(true);
                        connection.getOutputStream().write(input);
                        BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                        String line;
                        StringBuilder response = new StringBuilder();
                        while ((line = reader.readLine()) != null) {
                            response.append(line);
                        }
                        reader.close();
                        String xhdhdata = response.toString();
                        xhdhdata = xhdhdata.trim();
                        String code = 数据处理.JSON(xhdhdata,"code");
                        if(code.equals("0")) {
                            String ai = 数据处理.JSON(xhdhdata,"choices");
                            ai = 截取.取中间(ai,"[","]");
                            ai = 数据处理.JSON(ai,"message");
                            String aidh = 数据处理.JSON(ai,"content");
                            aidh = aidh.replace("###", "");
                            aidh = aidh.replace("**", "");
                            aidh = aidh.replace("$$", "");
                            aidh = aidh.replace("\\text", "");
                            aidh = aidh.replace("\\frac", "");
                            aidh = aidh.replace("\\times", "");
                            aidh = aidh.replace("```", "[代码]");
                            aidh = aidh.replace("\\div", "");
                            if(xh上下文.equals("空")) {
                                写("Groups/"+qun+"/Users",wxid+"_user","星火AI上下文","{\"role\":\"user\",\"content\":\""+xhdh+"\"},"+ai);
                                sendm(qun,"@"+name+"\n"+aidh,0);
                            }else{
                                写("Groups/"+qun+"/Users",wxid+"_user","星火AI上下文",xh上下文+",{\"role\":\"user\",\"content\":\""+xhdh+"\"},"+ai);
                                sendm(qun,"@"+name+"\n"+aidh,0);
                            }
                        }else{
                            String error = 数据处理.JSON(xhdhdata,"message");
                            sendm(qun,"星火AI接口调用出现错误："+error,0);
                        }
                    } catch (JSException e) {
                        sendm(qun,"星火AI出现异常:"+e,0);
                    }
                }else{
                    try {
                        String xhdata = "{\"model\":\""+xh模型+"\",\"messages\":[{\"role\":\"user\",\"content\":\""+xhdh+"\"}],\"temperature\":"+xh随机性+",\"top_k\":"+xh灵活度+"}";
                        byte[] input = xhdata.getBytes("utf-8");
                        HttpURLConnection connection = (HttpURLConnection) new URL(xhurl).openConnection();
                        connection.setRequestMethod("POST");
                        connection.setRequestProperty("Content-Type", "application/json");
                        connection.setRequestProperty("Authorization", "Bearer "+xhAPIPassword);
                        connection.setDoOutput(true);
                        connection.getOutputStream().write(input);
                        BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                        String line;
                        StringBuilder response = new StringBuilder();
                        while ((line = reader.readLine()) != null) {
                            response.append(line);
                        }
                        reader.close();
                        String xhdhdata = response.toString();
                        String code = 数据处理.JSON(xhdhdata,"code");
                        if(code.equals("0")) {
                            String aidh = 数据处理.JSON(xhdhdata,"choices");
                            aidh = 截取.取中间(aidh,"[","]");
                            aidh = 数据处理.JSON(aidh,"message");
                            aidh = 数据处理.JSON(aidh,"content");
                            aidh = 数据处理.JSON(aidh,"message");
                            aidh = aidh.replace("###", "");
                            aidh = aidh.replace("**", "");
                            aidh = aidh.replace("$$", "");
                            aidh = aidh.replace("\\text", "");
                            aidh = aidh.replace("\\frac", "");
                            aidh = aidh.replace("\\times", "");
                            aidh = aidh.replace("```", "[代码]");
                            aidh = aidh.replace("\\div", "");
                            sendm(qun,"@"+name+"\n"+aidh,0);
                        }else{
                            String error = 数据处理.JSON(xhdhdata,"message");
                            sendm(qun,"星火AI接口调用出现错误："+error,0);
                        }
                    } catch (JSException e) {
                        sendm(qun,"星火AI出现异常:"+e,0);
                    }
                }
            }
        }
    }
    if(content.equals("开启多轮对话")||content.equals("关闭多轮对话")) {
        if(content.contains("开启")) {
            写("Groups/"+qun,"智能系统_星火","多轮对话",1);
            sendm(qun,"@"+name+"\n本群多轮对话开启成功",0);
            return;
        }
        if(content.contains("关闭")) {
            写("Groups/"+qun,"智能系统_星火","多轮对话",0);
            sendm(qun,"@"+name+"\n本群多轮对话关闭成功",0);
            return;
        }
    }
    if(content.startsWith("设置随机性")) {
        String sjxstr = content.substring(5);
        if(sjxstr==null||sjxstr.equals("")) {
            return;
        }
        if(sjxstr.equals("0")||sjxstr.equals("0.1")||sjxstr.equals("0.2")||sjxstr.equals("0.3")||sjxstr.equals("0.4")||sjxstr.equals("0.5")||sjxstr.equals("0.6")||sjxstr.equals("0.7")||sjxstr.equals("0.8")||sjxstr.equals("0.9")||sjxstr.equals("1")) {
            写("Groups/"+qun,"智能系统_星火","temperature",sjxstr);
            sendm(qun,"@"+name+"\n本群星火AI随机性已设置为"+sjxstr,0);
        }else{
            return;
        }
    }
    if(content.startsWith("设置灵活度")) {
        String sjxstr = content.substring(5);
        if(sjxstr==null||sjxstr.equals("")) {
            return;
        }
        if(sjxstr.equals("1")||sjxstr.equals("2")||sjxstr.equals("3")||sjxstr.equals("4")||sjxstr.equals("5")||sjxstr.equals("6")) {
            写("Groups/"+qun,"智能系统_星火","top_k",sjxstr);
            sendm(qun,"@"+name+"\n本群星火AI灵活度已设置为"+sjxstr,0);
        }else{
            return;
        }
    }
    if(content.equals("清空对话")) {
        删("Groups/"+qun+"/Users",wxid+"_user","星火AI上下文");
        sendm(qun,"@"+name+"\n清空成功",0);
    }
    if(content.equals("星火AI说明")) {
        String text = "1.设置key+APIPassword\nAPIPassword需自行前往讯飞星火AI开放平台自行获取\nhttps://console.xfyun.cn/\n" + 
        "2.设置模型+模型类型\n模型类型：\nlite   指向Lite版本;\ngeneralv3   指向Pro版本;\npro-128k   指向Pro-128K版本;\ngeneralv3.5   指向Max版本;\nmax-32k   指向Max-32K版本;\n4.0Ultra   指向4.0 Ultra版本;\n" + 
        "3.开启/关闭 多轮对话\n可开关当前聊天的AI上下文对话";
        sendm(qun,"@"+name+"\n"+text,0);
    }
}
public 保存图片(String 目录,String 链接) {
    try {
        File file = new File(目录);
        File directory = file.getParentFile();
        if (directory != null && !directory.exists()) {
            directory.mkdirs();
        }
        URL url = new URL(链接);
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(5 * 1000);
        InputStream inStream = conn.getInputStream();
        byte[] data = readInputStream(inStream);
        File imageFile = new File(目录);
        FileOutputStream outStream = new FileOutputStream(imageFile);
        outStream.write(data);
        outStream.close();
    } catch (e) {
        Toast("图片保存失败：" + e);
    }
}
public static byte[] readInputStream(InputStream inStream) throws Exception {
    ByteArrayOutputStream outStream = new ByteArrayOutputStream();
    byte[] buffer = new byte[1024];
    int len = 0;
    while( (len=inStream.read(buffer)) != -1 ) {
        outStream.write(buffer, 0, len);
    }
    inStream.close();
    return outStream.toByteArray();
}