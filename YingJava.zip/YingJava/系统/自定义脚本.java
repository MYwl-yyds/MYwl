public void 自定义脚本(Object data) {
    String content = data.content;
    String qun = data.talker;
    String wxid = data.sendTalker;
    String name = getName(wxid);
    if(content.equals("自定义脚本")&&wxid.equals(mWxid)) {
        String text = "[e]写脚本#文件名称#内容";
        text += "\n[e]删脚本#文件名称";
        text += "\n[e]清空脚本";
        text += "\n[e]读脚本#文件名称(该功能暂无法使用)";
        sendm(qun,text,0);
    }
    if(content.startsWith("写脚本#")&&wxid.equals(mWxid)) {
        String zdyjb = content.substring(4);
        if(zdyjb==null) {
            return;
        }
        String wj = 截取.开头(zdyjb,"#")+".java";
        String nr = 截取.末尾(zdyjb,"#");
        if(wj==null||nr==null) {
            return;
        }
        String csnr3 = 截取.开头(wj,".java");
        String csnr1 = "public static void "+csnr3+"(Object data) {\n    String content = data.content;\n    String qun = data.talker;\n    String wxid = data.sendTalker;\n    ";
        String csnr2 = "\n    return;\n}";
        String jbnr = ReadFile(JavaPath + "/YingJava/系统/自定义脚本/自定义/"+wj);
        jbnr = 截取.取中间(jbnr, csnr1, csnr2);
        if(jbnr==null) {
            WriteFile(JavaPath + "/YingJava/系统/自定义脚本/自定义/"+wj,csnr1+nr+csnr2);
            sendm(qun,"@"+name+"\n写入/创建成功,手动重载脚本生效",0);
        }else{
            WriteFile(JavaPath + "/YingJava/系统/自定义脚本/自定义/"+wj,csnr1+jbnr+"\n"+nr+csnr2);
            sendm(qun,"@"+name+"\n写入/创建成功,手动重载脚本生效",0);
        }
        String zdyjbjz = ReadFile(JavaPath + "/YingJava/系统/自定义脚本/main.java");
        String jbjz1 = "long 自定义脚本加载=System.currentTimeMillis();\nThread 自定义脚本=new Thread(new Runnable() {\n    public void run() {\n";
        String jbjz2 = "    "+"}\n});\n自定义脚本.start();\ntry {\n    自定义脚本.join();\n} catch (InterruptedException e) {\n    Thread.currentThread().interrupt();\n}\nlong 自定义脚本加载结束=System.currentTimeMillis();\ndouble 自定义脚本加载耗时=(自定义脚本加载结束-自定义脚本加载)/1000.0;\nToast"+'('+'"'+"["+'"'+"+脚本名称+"+'"'+"]自定义脚本加载成功,耗时:"+'"'+"+自定义脚本加载耗时+"+'"'+"秒"+'"'+");";
        zdyjbjz = 截取.取中间(zdyjbjz,jbjz1,jbjz2);
        if(zdyjbjz==null) {
            WriteFile(JavaPath + "/YingJava/系统/自定义脚本/main.java",jbjz1+"loadJava(JavaPath+"+'"'+"/YingJava/系统/自定义脚本/自定义/"+wj+'"'+");"+jbjz2);
        }else{
            WriteFile(JavaPath + "/YingJava/系统/自定义脚本/main.java",jbjz1+zdyjbjz+"\n"+"loadJava(JavaPath+"+'"'+"/YingJava/系统/自定义脚本/自定义/"+wj+'"'+");"+jbjz2);
        }
    }
    if(content.startsWith("删脚本#")&&wxid.equals(mWxid)) {
        String jbjz1 = "long 自定义脚本加载=System.currentTimeMillis();\nThread 自定义脚本=new Thread(new Runnable() {\n    public void run() {\n";
        String jbjz2 = "    "+"}\n});\n自定义脚本.start();\ntry {\n    自定义脚本.join();\n} catch (InterruptedException e) {\n    Thread.currentThread().interrupt();\n}\nlong 自定义脚本加载结束=System.currentTimeMillis();\ndouble 自定义脚本加载耗时=(自定义脚本加载结束-自定义脚本加载)/1000.0;\nToast"+'('+'"'+"["+'"'+"+脚本名称+"+'"'+"]自定义脚本加载成功,耗时:"+'"'+"+自定义脚本加载耗时+"+'"'+"秒"+'"'+");";
        String sjb = content.substring(4);
        if(sjb==null) {
            return;
        }
        DeleteFile(JavaPath+"/YingJava/系统/自定义脚本/自定义/"+sjb+".java");
        String zdyjbjz = ReadFile(JavaPath + "/YingJava/系统/自定义脚本/main.java");
        String zdyjbjz1 = 截取.开头(zdyjbjz,"loadJava(JavaPath+"+'"'+"/YingJava/系统/自定义脚本/自定义/"+'"'+sjb+".java"+'"'+");");
        String zdyjbjz2 = 截取.末尾(zdyjbjz,"loadJava(JavaPath+"+'"'+"/YingJava/系统/自定义脚本/自定义/"+'"'+sjb+".java"+'"'+");");
        WriteFile(JavaPath + "/YingJava/系统/自定义脚本/main.java",jbjz1+"\n"+jbjz2);
        sendm(qun,"@"+name+"\n删除 "+sjb+" 文件成功,手动重载脚本生效",0);
    }
    if(content.equals("清空脚本")&&wxid.equals(mWxid)) {
        String jbjz1 = "long 自定义脚本加载=System.currentTimeMillis();\nThread 自定义脚本=new Thread(new Runnable() {\n    public void run() {\n";
        String jbjz2 = "    "+"}\n});\n自定义脚本.start();\ntry {\n    自定义脚本.join();\n} catch (InterruptedException e) {\n    Thread.currentThread().interrupt();\n}\nlong 自定义脚本加载结束=System.currentTimeMillis();\ndouble 自定义脚本加载耗时=(自定义脚本加载结束-自定义脚本加载)/1000.0;\nToast"+'('+'"'+"["+'"'+"+脚本名称+"+'"'+"]自定义脚本加载成功,耗时:"+'"'+"+自定义脚本加载耗时+"+'"'+"秒"+'"'+");";
        DeleteDir(JavaPath+"/YingJava/系统/自定义脚本/自定义");
        CreateDir(JavaPath+"/YingJava/系统/自定义脚本/自定义");
        WriteFile(JavaPath + "/YingJava/系统/自定义脚本/main.java",jbjz1+jbjz2);
        sendm(qun,"@"+name+"\n清空成功,手动重载脚本生效",0);
    }
    if(content.equals("读脚本#")&&wxid.equals(mWxid)) {
        String djb = content.substring(4);
        if(djb==null||djb.equals("")) {
            sendm(qun,"1",0);
            return;
        }
        sendm(qun,"2",0);
        String csnr1 = "public static void "+djb+"(Object data) {\n    String content = data.content;\n    String qun = data.talker;\n    String wxid = data.sendTalker;\n    ";
        String csnr2 = "\n    return;\n}";
        String jb = ReadFile(JavaPath + "/YingJava/系统/自定义脚本/自定义/"+djb+".java");
        jb = 截取.取中间(jb,csnr1,csnr2);
        sendm(qun,"3",0);
        if(jb==null||jb.equals("")) {
            sendm(qun,"@"+name+"\n"+djb+" 脚本内容为空,可能该文件不存在或者存在未写入代码",0);
        }else{
            sendm(qun,"@"+name+"\n"+djb+" 脚本内容\n"+jb,0);
        }
    }
}