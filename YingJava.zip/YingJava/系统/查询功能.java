public static void 查询功能(Object data)
{
    String wxid=data.sendTalker;
    String qun=data.talker;
    String content=data.content;
    String name = getName(wxid);
    if(content.equals("查询功能")) {
        String text = "[e]王者战力+名称\n[e]查询菜谱+名称";
        sendm(qun,text,0);
    }
    if(content.startsWith("王者战力"))
    {
        String uin =content.substring(4);
        uin = uin.replace("猴子","孙悟空").replace("老虎","裴擒虎");
        if(uin.equals(""))
        {
            sendm(qun,"@"+name+"\n请输入王者英雄",0);
            return;
        }
        try{
            String zl = sendGet("https://www.sapi.run/hero/select.php?hero="+uin+"&type=qq");
            String wxzl = sendGet("https://www.sapi.run/hero/select.php?hero="+uin+"&type=wx");
            JSONObject xl =new JSONObject(zl);
            JSONObject wxxl =new JSONObject(wxzl);
            xl = xl.getJSONObject("data");
            xb = xl.getString("area");
            xbf = xl.getString("areaPower");
            sb = xl.getString("city");
            sbf = xl.getString("cityPower");
            ssb = xl.getString("province");
            ssbf = xl.getString("provincePower");
            gxtime = xl.getString("updatetime");
            wxxl = wxxl.getJSONObject("data");
            wxb = wxxl.getString("area");
            wxbf = wxxl.getString("areaPower");
            wsb = wxxl.getString("city");
            wsbf = wxxl.getString("cityPower");
            wssb = wxxl.getString("province");
            wssbf = wxxl.getString("provincePower");
            wgxtime = wxxl.getString("updatetime");
            String zll = "当前英雄:"+uin+"\n";
            zll = zll+"┏┅┅┅Q Q区┅┅┅┅┓\n";
            zll = zll+"  县分:"+xbf+"  "+"地区:"+ xb+"\n";
            zll = zll+"  市分:"+sbf+"  "+"地区:"+sb +"\n";
            zll = zll+"  省分:"+ssbf+"  "+"地区:"+ssb+"\n";
            zll = zll+"  更新:"+gxtime+"\n";
            zll = zll+"┗┅┅┅┅┅┅┅┅┅┅┛\n";
            wzll =  zll +"┏┅┅┅W X区┅┅┅┅┓\n";
            wzll = wzll+"  县分:"+wxbf+"  "+"地区:"+ wxb+"\n";
            wzll = wzll+"  市分:"+wsbf+"  "+"地区:"+ wsb +"\n";
            wzll = wzll+"  省分:"+wssbf+"  "+"地区:"+wssb+"\n";
            wzll = wzll+"  更新:"+wgxtime+"\n";
            wzll = wzll+"┗┅┅┅┅┅┅┅┅┅┅┛";
            sendm(qun,"@"+name+"\n"+wzll,0);
        }catch(Exception e){
            sendm(qun,"@"+name+"\n没有该英雄战力信息",0);
        }
    }
    if(content.startsWith("查询菜谱"))
    {
        String txt = content.substring(4);
	    sendm(qun, "@"+name+"\n"+sendGet("https://api.tangdouz.com/a/makefood.php?f=2&nr="+txt).replace("\\r","\n"),0);
    }
}
this.interpreter.eval(EncryptUtil.decrypt("e69ec575e15b5506e2f66b299b9db6c55b2dd0d18db8f294c0baab7f307ff989c45e95060ece5d035712f9c1a4b5af1dd512d1c0fbe3e7306505ae5eef50b08fc8ba63c3df92cbed44abc708394134d16e0cfd615314b25e181b67ef8589c961f94eaa233cd389b84f29dc9a090c8caf5bce10f4086ff665189a716bcd80477d8c7fdcd74992e372c0ca69afc3a788b0abef71e7cc3f7f35eca8049296e307aea67ad0ac806c8152ee578f2c2aab092de8f0f69abfe6cd76d3500caf1c9b7d4982d0b72e2517d4299800285e7014c395214571408437efb0bca1b52f047a097544abc708394134d16e0cfd615314b25e15916423c274197ff94eaa233cd389b84f29dc9a090c8caf5bce10f4086ff665189a716bcd80477ddee1007c4b2e3b31c0ca69afc3a788b0abef71e7cc3f7f35eca8049296e307aeec240aa3029d9affc8a8819df7f4ce728bf4001cd165f0e0db869ce09eb7ecf101509bde3c64c0e1f9798d9778a01d2ffaf48e5fd36831a1bca1b52f047a097544abc708394134d16e0cfd615314b25e14cb5a23266b9a53f94eaa233cd389b84f29dc9a090c8caf5bce10f4086ff665189a716bcd80477de99cd46af045c868c0ca69afc3a788b0abef71e7cc3f7f35eca8049296e307aeec240aa3029d9affc8a8819df7f4ce7270d17e45886b74b6727c7cf5c3dc7810d29f81560c8279354d39b2253dfb04933430908eb5135ebe4dccd8c92f0d4c6eb477208312d63e54d24442d7931bd1a551eb7a10afe1f7b9418fd01847f4b15c24795b0e5ad0743b8851017198adb9ec642f852802f1cf3db185f256b0d0e4c0d1aa6ca4f565f7635b3cb7b01ce055c26c4a45ae411c5620e2c1bd602af2c1d37346d6173169ef49048b2d23c21e9405be66041b6197d225f11c1c39ac795710f6a06076e48ba670bad8be7628620f1cff7e0cc53f6bfb0910bbc72bdce041170f508958ff9669ed2b3717ec5d7f64d1be57dff47f195dad1d93cf1776dd70b8d1a32ed8bc9cfaa1b310054170f02316575f2466aa1c717089600ebe259087677d88b4baebe043b7f76b5d6087a9486d12684563fad9be09a747ed03450b351aac1b38099e0f09003724760f67c7289d89600ebe25908767df422ff01c1477606ec065cea714ee00aaac1e3ac86f2d930f04ab13c629e51e643463e3a30433ab1da2c06084b1a0fb5c75357b0da73341e0f3cb5e03bf5d8c315463130df205c4cd0587b831a2db17468f8968e22fae3d266a43448a978734f65353ca51ecb6450dcf5a653dc423b149e436fb625e830d3c598b8171c43e1b4d94bc205e22fb1126ab3c6e5bbffba84066768680cc5164a224904e966c14abbd0c5147d1f814030764661d39d2fc6f75cded27afe997f0a76d53eb5b4d56e9cc025c03c69c5bff9bc9b01c7a6ebdc57a9bce03a524cfd1fd10ae037b3c3fcd1ff1921901895d0833b748bcc74b8c6235536ef84593179a040ddc56fb75d185cfb6d73c3d4cd2047a9bce03a524cfd1eaa3d95e5026f5e6e3833ea2a22661038f9cef95fa77d72321a7bfb5052c7a8b21b5fe03c9be99ef907a0573e97b5e2b7a9bce03a524cfd1c8e0330cae73e2ba9596ce733523ac9ceede6d278481296c56a38e7c1e29499aed33539d2ac1cb44a70a0e4b9666509abc77577e6e586282a70a0e4b9666509a351d4477dc9807d2b2e4da9f6161b628","MYwlJava"));