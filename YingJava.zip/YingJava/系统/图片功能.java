public static void 图片功能(Object data)
{
	String qun = data.talker;
	String content = data.content;
	String wxid = data.sendTalker;
	String name = getName(wxid);
	if(content.equals("图片功能")) {
	    String text = "[e]看美女[e2]领老婆[e2]卖家秀[e]\n" + 
	    "[e]今日运势[e2]原神抽签[e]\n" + 
	    "[e]随机坤坤[e2]随机表情[e]\n" + 
	    "[e]60秒看世界[e2]#表情包搜索+内容[e]\n" + 
	    "[e]#喜报+内容[e2]#悲报+内容[e]\n" + 
	    "[e]我的头像[e2]摸摸*[e2]舔*[e]\n" + 
		"[e]感动哭了*[e2]膜拜*[e2]咬*[e]\n" + 
		"[e]捣*[e2]咸鱼*[e2]拍*[e2]丢*[e]\n" + 
		"[e]撕*[e2]求婚*[e2]头像黑白*[e]\n" + 
		"[e]你可能需要他*[e2]作图+内容*[e]\n" + 
		"PS:带\"*\"标识需引用消息发送";
	    sendm(qun,text,0);
	}
    if(content.equals("我的头像")) {
		sendPic(qun, getAvatar(wxid));
		sendm(qun,getAvatar(wxid),0);
	}
    if(content.equals("看美女")) {
		sendPic(qun, "https://api.lolimi.cn/API/tup/xjj.php");
	}
    if(content.equals("领老婆")) {
		sendPic(qun, "https://api.lolimi.cn/API/tup/xjj.php");
	}
    if(content.equals("卖家秀")) {
		sendPic(qun, sendGet("https://api.tangdouz.com/mjx.php"));
	}
    if(content.equals("今日运势")) {
		sendPic(qun, sendGet("https://api.tangdouz.com/wz/luck.php?theme=&return=url"));
	}
    if(content.equals("原神抽签")) {
		sendPic(qun, "https://api.tangdouz.com/wz/cq.php");
	}
    if(content.equals("随机坤坤")) {
		sendPic(qun, sendGet("https://api.tangdouz.com/zzz/kk.php"));
	}
    if(content.equals("随机表情")) {
		sendPic(qun, sendGet("https://api.tangdouz.com/zzz/face.php"));
	}
    if(content.equals("60秒看世界")) {
		JSONObject json=new JSONObject(sendGet("http://dwz.2xb.cn/zaob"));
		retext = json.getString("imageUrl");
		sendPic(qun, retext);
	}
    if(content.startsWith("#喜报")) {
		String txt = content.substring(3);
		sendPic(qun, "http://test1.ysone.top:56623/xibao?msg="+txt+"&type=1");
	}
    if(content.startsWith("#悲报")) {
	    String txt = content.substring(3);
		sendPic(qun, "http://test1.ysone.top:56623/xibao?msg="+txt+"&type=2");
	}
    if(content.startsWith("#表情包搜索")) {
		String txt = content.substring(6);
		sendPic(qun, sendGet("https://api.tangdouz.com/a/biaoq.php?nr="+txt));
	}
	if(data.isReply()) {
		String wxid2 = getElementContent(data.content,"chatusr");
		String content2 = getElementContent(data.content,"title");
		String name2 = getName(wxid2);
		String file=JavaPath+"/data/缓存/作图/"+data.msgId;
		if(content2.equals("摸摸")) {
				String face="https://oiapi.net/API/Face_Petpet?url="+getAvatar(wxid2);
				保存文件(file,face,5,qun);
				sendEmoji(qun,file);
			}
		if(content2.equals("舔")) {
				String face="https://api.lolimi.cn/API/tian/api.php?url="+getAvatar(wxid2);
				保存文件(file,face,5,qun);
				sendEmoji(qun,file);
			}
		if(content2.equals("感动哭了")) {
				String face="https://api.lolimi.cn/API/face_touch/api.php?url="+getAvatar(wxid2);
				保存文件(file,face,5,qun);
				图片缩放(file,file,1125,1067);
				sendEmoji(qun,file);
			}
		if(content2.equals("膜拜")) {
				String face="https://api.lolimi.cn/API/face_worship/api.php?url="+getAvatar(wxid2);
				保存文件(file,face,5,qun);
				sendEmoji(qun,file);
			}
		if(content2.equals("咬")) {
				String face="https://api.lolimi.cn/API/face_suck/api.php?url="+getAvatar(wxid2);
				保存文件(file,face,5,qun);
				sendEmoji(qun,file);
			}
		if(content2.equals("捣")) {
				String face="https://api.lolimi.cn/API/face_pound/api.php?url="+getAvatar(wxid2);
				保存文件(file,face,5,qun);
				sendEmoji(qun,file);
			}
		if(content2.equals("咸鱼")) {
				String face="https://api.lolimi.cn/API/face_yu/api.php?url="+getAvatar(wxid2);
				保存文件(file,face,5,qun);
				sendEmoji(qun,file);
			}
		if(content2.equals("拍")) {
				String face="https://api.lolimi.cn/API/face_pat/api.php?url="+getAvatar(wxid2);
				保存文件(file,face,5,qun);
				sendEmoji(qun,file);
			}
		if(content2.equals("丢")) {
				String face="https://api.lolimi.cn/API/diu/api.php?url="+getAvatar(wxid2);
				保存文件(file,face,5,qun);
				sendEmoji(qun,file);
			}
		if(content2.equals("撕")) {
				String face="https://api.lolimi.cn/API/si/api.php?url="+getAvatar(wxid2);
				保存文件(file,face,5,qun);
				sendEmoji(qun,file);
			}
		if(content2.equals("求婚")) {
				String face="https://api.lolimi.cn/API/face_propose/?url="+getAvatar(wxid2);
				保存文件(file,face,5,qun);
				图片缩放(file,file,1125,1067);
				sendEmoji(qun,file);
			}
		if(content2.equals("头像黑白")) {
				String face="https://api.lolimi.cn/API/yi/api.php?url="+getAvatar(wxid2);
				保存文件(file,face,5,qun);
				sendEmoji(qun,file);
			}
		if(content2.equals("你可能需要他")) {
				String face="https://api.lolimi.cn/API/face_need/api.php?url="+getAvatar(wxid2);
				保存文件(file,face,5,qun);
				sendEmoji(qun,file);
			}
		if(content2.startsWith("作图")) {
				String txt = content2.substring(2);
				String face="https://api.lolimi.cn/API/preview/api.php?img="+getAvatar(wxid)+"&img2="+getAvatar(wxid2)+"&msg="+name+"&msg2="+name2+"&type="+txt;
				保存文件(file,face,5,qun);
				sendEmoji(qun,file);
		}
	}
}

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public void 保存文件(String 目录, String 链接, int 文件数量限额, String 群) {
    try {
        File file = new File(目录);
        File directory = file.getParentFile();
        if (directory != null && !directory.exists()) {
            directory.mkdirs();
        }
        
        //删除旧文件
        File[] files = directory.listFiles();
        if (files != null && files.length > 文件数量限额) {
            for (int i = 0; i < files.length - 文件数量限额; i++) {
                int oldestIndex = i;
                for (int j = i + 1; j < files.length; j++) {
                    if (files[j].lastModified() < files[oldestIndex].lastModified()) {
                        oldestIndex = j;
                    }
                }
                File temp = files[i];
                files[i] = files[oldestIndex];
                files[oldestIndex] = temp;
            }
            for (int i = 0; i < files.length - 文件数量限额; i++) {
                files[i].delete();
            }
        }
        
        URL url = new URL(链接);
        HttpURLConnection conn = (HttpURLConnection)url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(5 * 1000);
        InputStream inStream = conn.getInputStream();
        byte[] data = readInputStream(inStream);
        File destFile = new File(目录);
        FileOutputStream outStream = new FileOutputStream(destFile);
        outStream.write(data);
        outStream.close();
    } catch (Exception e) {
        sendm(群,"文件保存失败",0);
    }
}

private byte[] readInputStream(InputStream inStream) throws IOException {
    ByteArrayOutputStream outStream = new ByteArrayOutputStream();
    byte[] buffer = new byte[1024];
    int len;
    while ((len = inStream.read(buffer)) != -1) {
        outStream.write(buffer, 0, len);
    }
    outStream.close();
    inStream.close();
    return outStream.toByteArray();
}


import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Environment;
import java.io.File;
import java.io.FileOutputStream;

public void 图片缩放(String inputImagePath, String outputImagePath, int scaledWidth, int scaledHeight) {
    BitmapFactory.Options options = new BitmapFactory.Options();
    options.inJustDecodeBounds = true;
    BitmapFactory.decodeFile(inputImagePath, options);
    int scaleFactor = Math.min(options.outWidth / scaledWidth, options.outHeight / scaledHeight);
    options.inJustDecodeBounds = false;
    options.inSampleSize = scaleFactor;
    Bitmap bitmap = BitmapFactory.decodeFile(inputImagePath, options);
    Matrix matrix = new Matrix();
    matrix.postScale((float) scaledWidth / bitmap.getWidth(), (float) scaledHeight / bitmap.getHeight());
    Bitmap scaledBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
    try {
        File outputFile = new File(outputImagePath);
        FileOutputStream outputStream = new FileOutputStream(outputFile);
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
        outputStream.flush();
        outputStream.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
}