public void 菜单(Object data) {
    String content = data.content;
    String qun = data.talker;
    String wxid = data.sendTalker;
    String name = getName(wxid);
    String mname = getName(mWxid);
    开关(data);
    if(wxid.equals(mWxid)) {
        if(content.equals("开关系统")) {
            String text = "[e]群聊系统["+开关状态(qun,"群聊系统")+"]\n" + 
            "[e]智能系统["+开关状态(qun,"智能系统")+"]\n" + 
            "[e]娱乐系统["+开关状态(qun,"娱乐系统")+"]\n" + 
            "[e]音乐系统["+开关状态(qun,"音乐系统")+"]\n" + 
            "[e]定时消息["+开关状态(qun,"定时消息")+"]\n" + 
            "[e]整点报时["+开关状态(qun,"整点报时")+"]\n" + 
            "[e]查询功能["+开关状态(qun,"查询功能")+"]\n" + 
            "[e]站长工具["+开关状态(qun,"站长工具")+"]\n" + 
            "[e]图片功能["+开关状态(qun,"图片功能")+"]\n" + 
            "[e]短剧功能["+开关状态(qun,"短剧系统")+"]\n" + 
            "[e]接口功能["+开关状态(qun,"接口功能")+"]\n" + 
            "PS:可发送 开启/关闭+功能名称";
            sendm(qun,text,0);
        }
        if(content.equals("配置设置")) {
            String text = "[e]查看配置信息\n" + 
            "◈类型──\n" + 
            "[e]切换文字发送\n" + 
            "[e]切换图片发送\n" + 
            "◈标题──\n" + 
            "[e]设置标题+内容\n" + 
            "[e]恢复默认标题\n" + 
            "◈尾巴──\n" + 
            "[e]设置尾巴+内容\n" + 
            "[e]恢复默认尾巴\n" +
            "◈表情──\n" + 
            "[e]设置表情1/2+表情\n" + 
            "[e]恢复默认表情\n" + 
            "◈全局──\n" + 
            "[e]全局标题+内容\n" + 
            "[e]全局尾巴+内容\n" + 
            "[e]全局表情1/2+表情\n" + 
            "[e]全局恢复默认";
            sendm(qun,text,0);
        }
        if(content.equals("主人系统")) {
            String text = "◈点券──\n" + 
            "[e]充值点券+数量*\n" + 
            "[e]扣除点券+数量*\n" + 
            "[e]清空点券*\n" + 
            "◈物品──\n" + 
            "[e]奖励物品+物品*\n" + 
            "[e]没收物品+物品*\n" + 
            "◈体力──\n" + 
            "[e]增加体力+数量*\n" + 
            "[e]扣除体力+数量*\n" + 
            "[e]清空体力*\n" + 
            "◈存款──\n" + 
            "[e]增加存款+数量*\n" + 
            "[e]扣除存款+数量*\n" + 
            "[e]清空存款*\n" + 
            "◈奴隶──\n" + 
            "[e]清空奴隶主*\n" + 
            "[e]清空奴隶*\n" + 
            "◈脚本──\n" + 
            "[e]自定义脚本\n" + 
            "◈自义──\n" + 
            "[e]自定义功能(开发中)\n" + 
            "PS:带\"*\"标识需引用消息发送";
            sendm(qun,text,0);
            return;
        }
        if(data.isReply()) {
            String wxid2 = getElementContent(data.content,"chatusr");
            String content2 = getElementContent(data.content,"title");
            String name2 = getName(wxid2);
            if(content2.startsWith("充值点券")) {
                String textStr = content2.substring(4);
                try {
                    int textInt = Integer.parseInt(textStr);
                    int currentPoints = 读整("Groups/"+qun+"/Users",wxid2+"_user", "点券");
                    写("Groups/"+qun+"/Users", wxid2+"_user", "点券", currentPoints + textInt);
                    sendm(qun, "已成功给 "+name2+" 充值点券",0);
                } catch (NumberFormatException e) {
                    sendm(qun, "无效的数字格式，请重新输入",0);
                } catch (StringIndexOutOfBoundsException e) {
                    sendm(qun, "输入内容不正确，请重新输入",0);
                }
            }
            if(content2.startsWith("扣除点券")) {
                String textStr = content2.substring(4);
                try {
                    int textInt = Integer.parseInt(textStr);
                    int currentPoints = 读整("Groups/"+qun+"/Users", wxid2+"_user", "点券");
                    if (currentPoints >= textInt) {
                        写("Groups/"+qun+"/Users", wxid2+"_user", "点券", currentPoints - textInt);
                        sendm(qun, "已成功扣除 "+name2+" 的点券",0);
                    } else {
                        sendm(qun, name2+" 点券余额不足，无法扣除",0);
                    }
                } catch (NumberFormatException e) {
                    sendm(qun, "无效的数字格式，请重新输入",0);
                } catch (StringIndexOutOfBoundsException e) {
                    sendm(qun, "输入内容不正确，请重新输入",0);
                }
            }
            if(content2.startsWith("奖励物品")) {
                String textStr = content2.substring(4);
                if (textStr.equals("匕首")||textStr.equals("电棍")||textStr.equals("手枪")||textStr.equals("激光剑")||textStr.equals("火箭筒")||textStr.equals("导弹")||textStr.equals("核弹")) {
                    写("Groups/"+qun+"/Users", wxid2+"_user", textStr, 1);
                    sendm(qun, "已成功将 " + textStr+ " 奖励给 "+ name2,0);
                } else {
                    sendm(qun, "输入的内容不是系统所拥有的物品或装备，请重新输入",0);
                }
            }
            if(content2.startsWith("没收物品")) {
                String textStr = content2.substring(4);
                if (textStr.length >= 2) {
                    int currentQuantity = 读整("Groups/"+qun+"/Users", wxid2+"_user", textStr);
                    if (currentQuantity > 0&&(textStr.equals("匕首")||textStr.equals("电棍")||textStr.equals("手枪")||textStr.equals("激光剑")||textStr.equals("火箭筒")||textStr.equals("导弹")||textStr.equals("核弹"))) {
                        写("Groups/"+qun+"/Users", wxid2+"_user", textStr, 0);
                        String zb = 读("Groups/"+qun+"/Users",  wxid2+"_user", "当前装备");
                        if(textStr=="匕首"&&zb==1) {
                            删("Groups/"+qun+"/Users",  wxid2+"_user", "装备数据");
                            删("Groups/"+qun+"/Users",  wxid2+"_user", "当前装备");
                        }
                        if(textStr=="电棍"&&zb==2) {
                            删("Groups/"+qun+"/Users",  wxid2+"_user", "装备数据");
                            删("Groups/"+qun+"/Users",  wxid2+"_user", "当前装备");
                        }
                        if(textStr=="手枪"&&zb==3) {
                            删("Groups/"+qun+"/Users",  wxid2+"_user", "装备数据");
                            删("Groups/"+qun+"/Users",  wxid2+"_user", "当前装备");
                        }
                        if(textStr=="激光剑"&&zb==4) {
                            删("Groups/"+qun+"/Users",  wxid2+"_user", "装备数据");
                            删("Groups/"+qun+"/Users",  wxid2+"_user", "当前装备");
                        }
                        if(textStr=="火箭筒"&&zb==5) {
                            删("Groups/"+qun+"/Users",  wxid2+"_user", "装备数据");
                            删("Groups/"+qun+"/Users",  wxid2+"_user", "当前装备");
                        }
                        if(textStr=="导弹"&&zb==6) {
                            删("Groups/"+qun+"/Users",  wxid2+"_user", "装备数据");
                            删("Groups/"+qun+"/Users",  wxid2+"_user", "当前装备");
                        }
                        if(textStr=="核弹"&&zb==7) {
                            删("Groups/"+qun+"/Users",  wxid2+"_user", "装备数据");
                            删("Groups/"+qun+"/Users",  wxid2+"_user", "当前装备");
                        }
                        sendm(qun, "已成功没收 "+ name2 + " 的 " + textStr,0);
                    } else {
                        sendm(qun, name2+" 没有 "+textStr+"，无法没收",0);
                    }
                } else {
                    sendm(qun, "输入的内容不是系统所拥有的物品或装备，请重新输入",0);
                }
            }
            if(content2.equals("清空点券")) {
                int currentPoints = 读整("Groups/"+qun+"/Users", wxid2+"_user", "点券");
                if (currentPoints > 0) {
                    写("Groups/"+qun+"/Users", wxid2+"_user", "点券", 0);
                    sendm(qun, "已成功清空 "+name2+" 的点券",0);
                } else {
                    sendm(qun, "清空失败，"+name2+" 没有点券或点券欠费",0);
                }
            }
            if(content2.startsWith("增加体力")) {
                String textStr = content2.substring(4);
                try {
                    int textInt = Integer.parseInt(textStr);
                    int tl = 读整("Groups/"+qun+"/Users", wxid2+"_user", "体力");
                    if(tl + textInt >= 100) {
                        写("Groups/"+qun+"/Users", wxid2+"_user", "体力", 100);
                    }else{
                        写("Groups/"+qun+"/Users", wxid2+"_user", "体力", tl + textInt);
                    }
                    sendm(qun, "已成功给 "+name2+" 增加体力",0);
                } catch (NumberFormatException e) {
                    sendm(qun, "无效的数字格式，请重新输入",0);
                } catch (StringIndexOutOfBoundsException e) {
                    sendm(qun, "输入内容不正确，请重新输入",0);
                }
            }
            if(content2.startsWith("扣除体力")) {
                String textStr = content2.substring(4);
                try {
                    int textInt = Integer.parseInt(textStr);
                    int tl = 读整("Groups/"+qun+"/Users", wxid2+"_user", "体力");
                    if(tl - textInt < 0) {
                        写("Groups/"+qun+"/Users", wxid2+"_user", "体力", 0);
                        sendm(qun, "已清空 "+name2+" 的体力",0);
                    }else{
                        写("Groups/"+qun+"/Users", wxid2+"_user", "体力", tl - textInt);
                        sendm(qun, "已成功扣除 "+name2+" 的体力",0);
                    }
                } catch (NumberFormatException e) {
                    sendm(qun, "无效的数字格式，请重新输入",0);
                } catch (StringIndexOutOfBoundsException e) {
                    sendm(qun, "输入内容不正确，请重新输入",0);
                }
            }
            if(content2.equals("清空体力")) {
                int tl = 读整("Groups/"+qun+"/Users", wxid2+"_user", "体力");
                if (tl > 0) {
                    写("Groups/"+qun+"/Users", wxid2+"_user", "体力", 0);
                    sendm(qun, "已成功清空 "+name2+ " 的体力",0);
                } else {
                    sendm(qun, "清空失败，"+name2+" 没有体力",0);
                }
            }
            if(content2.startsWith("增加存款")) {
                String textStr = content2.substring(4);
                try {
                    int textInt = Integer.parseInt(textStr);
                    int ck = 读整("全局/银行系统", wxid2, "存款");
                    写("全局/银行系统", wxid2, "存款", ck + textInt);
                    sendm(qun, "已成功给 "+name2+" 增加存款",0);
                } catch (NumberFormatException e) {
                    sendm(qun, "无效的数字格式，请重新输入",0);
                } catch (StringIndexOutOfBoundsException e) {
                    sendm(qun, "输入内容不正确，请重新输入",0);
                }
            }
            if(content2.startsWith("扣除存款")) {
                String textStr = content2.substring(4);
                try {
                    int textInt = Integer.parseInt(textStr);
                    int ck = 读整("全局/银行系统", wxid2, "存款");
                    if(ck - textInt < 0) {
                        写("全局/银行系统", wxid2, "存款", 0);
                        sendm(qun, "已清空 "+name2+" 的存款",0);
                    }else{
                        写("全局/银行系统", wxid2, "存款", ck - textInt);
                        sendm(qun, "已成功扣除 "+name2+" 的存款",0);
                    }
                } catch (NumberFormatException e) {
                    sendm(qun, "无效的数字格式，请重新输入",0);
                } catch (StringIndexOutOfBoundsException e) {
                    sendm(qun, "输入内容不正确，请重新输入",0);
                }
            }
            if(content2.startsWith("清空存款")) {
                int ck = 读整("全局/银行系统", wxid2, "存款");
                if (ck > 0) {
                    写("全局/银行系统", wxid2, "存款", 0);
                    sendm(qun, "已成功清空 "+name2+" 的存款",0);
                } else {
                    sendm(qun, "清空失败，对方没有存款",0);
                }
            }
            if(content2.equals("清空奴隶")) {
                String nl =读("Groups/"+qun+"/Users", wxid2 + "_user", "奴隶", "无");
                if(nl.equals("无")) {
                    sendm(qun, name2 + " 没有奴隶",0);
                    return;
                }
                删("Groups/"+qun+"/Users", nl + "_user", "奴隶主");
                删("Groups/"+qun+"/Users", nl + "_user", "赎身价格");
                写("Groups/"+qun+"/Users",nl+"_user","奴隶系统保护机制",GetTime(4));
                删("Groups/"+qun+"/Users", wxid2 + "_user", "奴隶");
                sendm(qun, "清空成功,奴隶已和他解除绑定",0);
            }
            if(content2.equals("清空奴隶主")) {
                String nlz = 读("Groups/"+qun+"/Users", wxid2 + "_user", "奴隶主","无");
                if(nlz.equals("无")) {
                    sendm(qun, name2 + " 没有奴隶主",0);
                    return;
                }
                删("Groups/"+qun+"/Users", nlz + "_user", "奴隶");
                写("Groups/"+qun+"/Users",wxid+"_user","奴隶系统保护机制",GetTime(4));
                删("Groups/"+qun+"/Users", wxid2 + "_user", "奴隶主");
                删("Groups/"+qun+"/Users", wxid2 + "_user", "赎身价格");
                sendm(qun, "清空成功,奴隶主已和他解除绑定",0);
            }
        }
    }
    if(content.equals("菜单")) {
        String text = "◈系统──\n" + 
        "[e]开关设置[e2]开关系统[e]\n" + 
        "[e]配置设置[e2]主人系统[e]\n" + 
        "[e]关于脚本[e2]等待添加[e]\n" + 
        "◈功能──\n" + 
        "[e]群聊系统[e2]智能系统[e]\n" + 
        "[e]娱乐系统[e2]音乐系统[e]\n" + 
        "[e]定时任务[e2]整点报时[e]\n" + 
        "[e]查询功能[e2]站长工具[e]\n" + 
        "[e]图片功能[e2]短剧功能[e]\n" + 
        "[e]接口功能[e2]等待添加[e]";
        sendm(qun,text,0);
        return;
    }
    if(content.equals("关于脚本")) {
        File folder=new File(JavaPath);
        long 结束加载=data.createTime;
        String formattedSize = 目录大小(folder);
        String text = "[脚本名称]"+脚本名称+"\n" + 
        "[脚本作者]"+脚本作者+"\n" + 
        "[脚本版本]"+脚本版本+"\n" + 
        "[WX版本]"+VersionName(mContext)+"("+VersionCode(mContext)+")\n" + 
        "[账号昵称]"+mname+"\n" + 
        "[目录大小]"+formattedSize+"\n" + 
        "[运行时长]"+formatTime((float)(结束加载-脚本加载));
        sendm(qun,text,0);
        return;
    }
}
/*private String 开关状态(String qun, String txt) {
	String feature = 读("Groups/"+qun,"开关", txt, "0");
	return "1".equals(feature) ? "√" : "×";
}*/