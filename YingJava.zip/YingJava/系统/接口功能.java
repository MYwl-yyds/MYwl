public static void 接口功能(Object data){
    String qun = data.talker;
    String content = data.content;
    String wxid=data.sendTalker;
    String name = getName(wxid);
    if(content.equals("接口功能")) {
        String text ="[e]解析视频+链接";
        text += "\n[e]资源探嗅+网站";
        sendm(qun,text,0);
    }
    if (content.startsWith("解析视频")) {
        try {
            int startIndex = content.lastIndexOf("https://");
            String videoUrl = content.substring(startIndex);
            String encodedUrl = URLEncoder.encode(videoUrl, "UTF-8");

            JSONObject json = new JSONObject(sendGet("https://xiaoapi.cn/API/zs_dspjx.php?url=" + encodedUrl));
            String code = json.getString("code");

            if ("201".equals(code) || "202".equals(code)) {
                sendm(qun, json.getString("msg"));
                return;
            }
            // 处理抖音链接
            if (encodedUrl.contains("douyin.com")) {
                String musicUrl = json.optString("music", "不存在");
                String videoDownloadUrl = json.optString("video", "不存在");
                String music = json.optString("music", "不存在");
                JSONArray covers = json.optJSONArray("cover");
                StringBuilder coverUrls = new StringBuilder();
                if (covers != null && covers.length() > 0) {
                    for (int i = 0; i < covers.length(); i++) {
                        coverUrls.append("\n").append(covers.getString(i));
                    }
                } else {
                    coverUrls.append(json.optString("cover", "不存在"));
                }
                sendm(qun, "封面：" + coverUrls.toString() + "\n视频：" + videoDownloadUrl + "\n音乐：" + music);
                return;
            }
            // 处理快手链接
            if (encodedUrl.contains("kuaishou.com")) {
                String videoType = json.getString("type");
                String videoTitle = json.getString("title");
                String videoCover = json.getString("cover");
                switch (videoType) {
                    case "Atlas":
                        JSONArray imageUrls = json.getJSONArray("img_url");
                        StringBuilder imageUrlList = new StringBuilder("解析如下:");
                        for (int i = 0; i < imageUrls.length(); i++) {
                            imageUrlList.append("\n").append(imageUrls.getString(i));
                        }
                        String musicDownloadUrl = json.getJSONObject("music").getString("url");
                        sendm(qun, imageUrlList + "\n音乐URL: " + musicDownloadUrl);
                        break;
                    case "Video":
                        String videoPlayUrl = json.getString("url");
                        String authorName = json.getJSONObject("author").getString("name");
                        JSONObject webCardData = new JSONObject();
                        webCardData.put("title", authorName);
                        webCardData.put("description", videoTitle);
                        webCardData.put("thumb", videoCover);
                        webCardData.put("webpageUrl", videoPlayUrl);
                        sendWebCard(qun, webCardData);
                        break;
                    default:
                        sendm(qun, "未知类型: " + videoType);
                        break;
                }
            }
        } catch (Exception e) {
            sendm(qun, "错误: " + e.getMessage());
        }
    }
    if(content.startsWith("资源探嗅")) {
        String zytx = content.substring(4);
        if(zytx==null||zytx.equals("")) {
            return;
        }
        if(网站状态.Get(zytx)==true) {
            String zy = sendGet("https://api.pearktrue.cn/api/website/resources.php?url="+zytx);
            String zytx1 = 数据处理.JSON(zy,"code");
            if(zytx1.equals("200")) {
                String zyzt = 数据处理.JSON(zy,"message");
                String zysl = 数据处理.JSON(zy,"count");
                String zylist =数据处理.JSON(zy,"data");
                zylist = 数据处理.JSONlist(数据处理.JSON(zylist,"list"),"type","name","src",1);
                String text = "@"+name+"\n"+zyzt+"\n资源数量:"+zysl+zylist;
                text = text.replace("序号=", "\n资源");
                text = text.replace("type=", "类型:");
                text = text.replace("name=", "资源名称:");
                text = text.replace("src=", "资源链接:");
                sendm(qun,text,0);
            } else {
                sendm(qun,"@"+name+"\n"+数据处理.JSON(zy,"message"),0);
            }
        } else {
            sendm(qun,"@"+name+"\n资源探嗅 接口疑似失效",0);
        }
    }
}
