public String joinGroup(String xmlContent) {
    DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
    DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
    InputSource is = new InputSource(new StringReader(xmlContent));
    Document doc = dBuilder.parse(is);
    doc.getDocumentElement().normalize();
    NodeList linkList = doc.getElementsByTagName("link_list").item(0).getChildNodes();
    JSONObject json = new JSONObject();
    for (int i = 0; i < linkList.getLength(); i++) {
        Node linkNode = linkList.item(i);
        if (linkNode.getNodeType() == Node.ELEMENT_NODE && "link".equals(linkNode.getNodeName())) {
            Element linkElement = (Element) linkNode;
            String linkName = linkElement.getAttribute("name");
            NodeList memberList = linkElement.getElementsByTagName("memberlist");
            if (memberList.getLength() > 0) {
                Node memberListNode = memberList.item(0);
                NodeList nicknameList = ((Element) memberListNode).getElementsByTagName("nickname");
                if (nicknameList.getLength() > 0) {
                    Node nicknameNode = nicknameList.item(0);
                    json.putOpt(linkName, nicknameNode.getTextContent());
                }
            }
        }
    }
    return json.toString();
}
public void 群聊系统(Object data) {
    String content = data.content;
    String qun = data.talker;
    String wxid = data.sendTalker;
    String name = getName(wxid);
    String quname = getName(qun);
    int qunr = getChatMembers(qun)+1;
    String 进群通知 = 读("Groups/"+qun,"进退群","进群通知","[邀请名]邀请[被邀名]进群大家热烈欢迎！");
    String 退群通知 = 读("Groups/"+qun,"进退群","进群通知","[退群名]退出本群，请珍惜在本群的每一天！");
    if(data.type == 570425393) {
        if(content.contains("加入")) {
            String joinGroup =joinGroup(data.content);
            JSONObject json = new JSONObject(joinGroup);
            String name="未知";
            if(json.has("adder")) {
                name=json.getString("adder");
            } else if(json.has("names")) {
                name=json.getString("names");
            } else if(json.has("username")) {
                name=json.getString("username");
            }
            String text = 进群通知;
            text = text.replace("[邀请名]",json.optString("from", json.optString("username",getName(mWxid))));
            text=text.replace("[被邀名]",name);
            text=text.replace("[群名字]",quname);
            text=text.replace("[群人数]",qunr);
            sendm(qun,text,0);
        }
    }
    if(data.type==10000) {
        if(content.contains("退出")) {
            String name = 截取.开头(content, "(");
            if(name==null) {
                name = 截取.开头(content, "退出");
            }
            String text = 退群通知;
            text=text.replace("[退群名]",name);
            text=text.replace("[群名字]",quname);
            text=text.replace("[群人数]",(getChatMembers(qun)+1));
            sendm(qun,text,0);
        }
    }
    if(mWxid.equals(wxid)) {
        if(content.startsWith("修改进群通知"))
        {
            String text = content.substring(6);
            写("Groups/"+qun, "进退群", "进群通知", text);
            sendm(qun, "@"+name+" \n进群通知已设置",0);
            return;
        }
        if(content.equals("清空进群通知")) {
            删("Groups/"+qun, "进退群", "进群通知");
            sendm(qun,"@"+name+" \n已恢复默认进群通知", 0);
            return;
        }
        if(content.startsWith("修改退群通知"))
        {
            String text = content.substring(6);
            写("Groups/"+qun, "进退群", "退群通知", text);
            sendm(qun, "@"+name+" \n退群通知已设置",0);
            return;
        }
        if(content.equals("清空退群通知")) {
            删("Groups/"+qun, "进退群", "退群通知");
            sendm(qun,"@"+name+" \n已恢复默认退群通知", 0);
            return;
        }
        if(content.equals("进退群")) {
            String text = "[e]查看本群进退群通知\n◈进群通知─\n[e]修改进群通知+内容\n[e]清空进群通知\n◈退群通知─\n[e]修改退群通知+内容\n[e]清空退群通知";
            sendm(qun,text,0);
        }
        if(content.equals("查看本群进退群通知")) {
            String text = "进群通知:"+读("Groups/"+qun, "进退群", "进群通知","[邀请名]邀请[被邀名]进群大家热烈欢迎！")+"\n退群通知:"+读("Groups/"+qun, "进退群", "退群通知", "[退群名]退出本群，请珍惜在本群的每一天！");
            sendm(qun, "@"+name+" \n本群进退群通知↓\n"+text, 0);
        }
    }
}