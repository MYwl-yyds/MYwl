public void 站长工具(Object data) {
	String content = data.content;
	String qun = data.talker;
	String wxid=data.sendTalker;
	String name = getName(wxid);
	String pingURL = "https://api.pearktrue.cn/api/website/ping.php?url=[网址]";
	String 网站截图URL = "https://xiaoapi.cn/API/wzjp.php?url=[网址]";
	String 短网址生成URL = "https://api.pearktrue.cn/api/short/dwz.php?url=[网址]";
	String 备案查询URL = "https://api.pearktrue.cn/api/icp/?domain=[网址]";
	String ip定位URL = "https://yuanxiapi.cn/api/iplocation/?ip=[网址]";
	String 同ip查询URL = "https://api.pearktrue.cn/api/website/sameip/?ip=[网址]";
	String 收录量查询URL = "https://api.pearktrue.cn/api/website/shoulu.php?url=[网址]";
	if(content.equals("站长工具")) {
	    String text = "[e]ping [ip/域名]\n" + 
	    "[e]访问+域名\n" + 
	    "[e]短网址生成+域名\n" + 
	    "[e]备案查询+域名\n" + 
	    "[e]同IP查询+ip\n" + 
	    "[e]收录量查询+域名\n" + 
	    "[e]IP定位+IP\n" + 
	    "[e]网站截图+网站";
	    sendm(qun,text,0);
	}
	if(content.startsWith("ping "))
	{
		String text = content.substring(5);
		try {
		pingURL = pingURL.replace("[网址]", text);
		    if(网站状态.Get(pingURL)==true) {
		        JSONObject json = new JSONObject(sendGet(pingURL));
		        String code=json.getString("code");
		        if(code.equals("201")) {
                    sendm(qun,json.getString("msg"));
                    return;
                }
		        JSONObject json = json.getJSONObject("data");
		        String wz = json.getString("host");
		        String ip = json.getString("ip");
		        String dz = json.getString("location");
		        String zx = json.getString("min");
		        String pj = json.getString("average");
		        String zd = json.getString("max");
		        sendm(qun,"@"+name+"\n网址:"+wz+"\nIP:"+ip+"\n地址:" + dz+"\n最小延迟:"+ zx+"\n最大延迟:"+zd+"\n平均延迟:"+pj,0);
		        return;
		    }
	    } catch(e) {
		    sendm(qun, "@"+name+"\n错误: " + e,0);
	    }
	}
	if(content.startsWith("访问")) {
		String text = content.substring(2);
	    sendm(qun,"@"+name+"\n"+sendGet(text),0);
		return;
	}
	if(content.startsWith("网站截图")) {
	    String text = content.substring(4);
	    String encodedUrl = URLEncoder.encode(text, "UTF-8");
	    网站截图URL = 网站截图URL.replace("[网址]",encodedUrl);
	    JSONObject json = new JSONObject(sendGet(网站截图URL));
	    String code=json.getString("code");
        if(code.equals("201")) {
            sendm(qun,"@"+name+"\n"+json.getJSONObject("data").getString("msg"),0);
            return;
        }
        String img_url=json.getJSONObject("data").getString("img_url");
	    sendPic(qun,img_url);
	    return;
	}
	if(content.startsWith("短网址生成")) {
		String text = content.substring(5);
		短网址生成URL = 短网址生成URL.replace("[网址]",text);
		JSONObject json = new JSONObject(sendGet(短网址生成URL));
		String code=json.getString("code");
            if(code.equals("201")) {
                sendm(qun,"@"+name+"\n"+json.getString("msg"),0);
                return;
            }
		String long_url = json.getString("long_url");
		String short_url = json.getString("short_url");
		sendm(qun,"@"+name+"\n网址:" + long_url+"\n短网址:\n" + short_url,0);
		return;
	}
    if(content.startsWith("备案查询")) {
		String text = content.substring(4);
		try {
		备案查询URL = 备案查询URL.replace("[网址]",text);
		JSONObject json = new JSONObject(sendGet(备案查询URL));
		String code=json.getString("code");
		String domain=json.getString("domain");
            if(code.equals("201")) {
                sendm(qun,json.getString("msg"));
                return;
            }
		JSONObject data = json.getJSONObject("data");
		String hostingparty = data.getString("hostingparty");
		String filingnumber = data.getString("filingnumber");
		String audittime = data.getString("audittime");
		String websitename = data.getString("websitename");
		sendm(qun,"@"+name+"\n名字:" + hostingparty+"\n备案号:"+ filingnumber+"\n名称:" + websitename+"\n地址:" + domain+"\n时间:"+ audittime,0);
		return;
		} catch(e) {
			sendm(qun, "@"+name+"\n错误: " + e,0);
		}
	}
	if(content.startsWith("IP定位"))
	{
		String text = content.substring(4);
		try {
		ip定位URL = ip定位URL.replace("[网址]",text);
		JSONObject json = new JSONObject(sendGet(ip定位URL));
		String ip = json.getString("ip");
		String szdz = json.getString("Digitaladdress");
		String dz = json.getString("location");
		sendm(qun,"@"+name+"\nIP:"+ip+"\n数字地址:"+szdz+"\n地址:"+dz,0);
} catch(e) {
			sendm(qun, "@"+name+"\n错误: " + e,0);
		}
		return;
	}
	if(content.startsWith("同IP查询"))
	{
		String text = content.substring(5);
		String result = "";
		try {
		同ip查询URL =同ip查询URL.replace("[网址]",text);
		JSONObject json = new JSONObject(sendGet(同ip查询URL));
		String code=json.getString("code");
		if(code.equals("201")) {
                sendm(qun,json.getString("msg"));
                return;
            }
			JSONArray dataArray = json.getJSONArray("data");
			int q = Math.min(10, dataArray.length());
			for(int i = 0; i < q; i++) {
				JSONObject item = dataArray.getJSONObject(i);
				result += "\n地址:" + item.getString("domain")+"\n时间:"+item.getString("time");
			}
			sendm(qun, "@"+name+"\n同网站ip下的域名"+result+"\n只显示前十个(共查询到"+dataArray.length()+"个)",0);
		} catch(e) {
			sendm(qun, "@"+name+"\n错误: " + e,0);
		}
		return;
	}
	if(content.startsWith("收录量查询"))
	{
		String text = content.substring(5);
		try {
		收录量查询URL = 收录量查询URL.replace("[网址]",text);
		JSONObject json = new JSONObject(sendGet(收录量查询URL));
		String code=json.getString("code");
		if(code.equals("201")) {
                sendm(qun,json.getString("msg"));
                return;
            }
		JSONObject json = json.getJSONObject("data");
		String baidu = json.getString("baidu");
		String sougou = json.getString("sougou");
		String m360 = json.getString("360");
		String google = json.getString("google");
		sendm(qun,"@"+name+"\n百度:"+baidu+"\n搜狗:"+sougou+"\n360:" + m360+"\n谷歌:"+ google,0);
		return;
		} catch(e) {
			sendm(qun, "@"+name+"\n错误: " + e,0);
		}
	}
	return;
}