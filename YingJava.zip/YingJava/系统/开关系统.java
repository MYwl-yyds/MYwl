public static void 开关系统(Object data) {
	String wxid = data.sendTalker;
	String qun = data.talker;
	String content = data.content;
	if(mWxid.equals(wxid)) {
		if(content.startsWith("开启")) {
		    String text = content.substring(2);
		    if(text.equals("群聊系统")||text.equals("智能系统")||text.equals("娱乐系统")||text.equals("音乐系统")||text.equals("整点报时")||text.equals("查询功能")||text.equals("站长工具")||text.equals("图片功能")||text.equals("短剧功能")||text.equals("接口功能")) {
		        if(!"1".equals(读("Groups/"+qun,"开关",text,"0"))) {
		            写("Groups/"+qun,"开关",text,"1");
		            sendm(qun,text+" 已开启",0);
		            return;
		        }
		        sendm(qun,text+" 已经开启了",0);
		    }
		}
		if(content.startsWith("关闭")) {
		    String text = content.substring(2);
		    if(text.equals("群聊系统")||text.equals("智能系统")||text.equals("娱乐系统")||text.equals("音乐系统")||text.equals("整点报时")||text.equals("查询功能")||text.equals("站长工具")||text.equals("图片功能")||text.equals("短剧功能")||text.equals("接口功能")) {
		        if(!"1".equals(读("Groups/"+qun,"开关",text,"0"))) {
		            sendm(qun,text+" 已经关闭了",0);
		            return;
		        }
		        删("Groups/"+qun,"开关",text);
		        sendm(qun,text+" 已关闭",0);
		    }
		}
    }
}