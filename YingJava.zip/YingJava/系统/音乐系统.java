HashMap MusicMap = new HashMap();
public void 音乐系统(Object data) {
	String content = data.content;
	String qun = data.talker;
	String wxid = data.sendTalker;
	String name = getName(wxid);
	String 随机音乐URL = "http://api.mrgnb.cn/API/netease.php?type=random";
	String QQ点歌URL = "https://xiaoapi.cn/API/yy.php?type=qq&msg=[歌曲名称]";
	String QQ点歌数据 = "https://xiaoapi.cn/API/yy.php?type=qq&msg=[歌曲名称]&n=[序号]";
	String 酷狗点歌URL = "https://xiaoapi.cn/API/yy.php?type=kg&msg=[歌曲名称]";
	String 酷狗点歌数据 = "https://xiaoapi.cn/API/yy.php?type=kg&msg=[歌曲名称]&n=[序号]";
	String 网易点歌URL = "https://xiaoapi.cn/API/yy.php?type=wy&msg=[歌曲名称]";
	String 网易点歌数据 = "https://xiaoapi.cn/API/yy.php?type=wy&msg=[歌曲名称]&n=[序号]";
	if(content.equals("音乐系统")) {
	    String text = "[e]随机歌曲\n" + 
	    "[e]点歌+歌名\n" + 
	    "[e]QQ点歌+歌名\n" + 
	    "[e]酷狗点歌+歌名\n" + 
	    "[e]网易点歌+歌名";
	    sendm(qun,text,0);
	}
	if(content.equals("随机歌曲")) {
	    if(网站状态.Get(随机音乐URL)==true) {
	        String 随机音乐 = sendGet(随机音乐URL);
	        String data = 数据处理.JSON(随机音乐,"data");
	        String 封面 = 数据处理.JSON(data,"image_url");
	        String 音源 = 数据处理.JSON(data,"song_url");
	        sendc(0,qun,"随机音乐","网易云热歌榜",封面,音源,null);
	    }else{
	        sendm(qun,"@"+name+"\n音乐接口调用失败",0);
	    }
	}
	if(content.startsWith("点歌")) {
	    String 点歌 = content.substring(2).trim();
	    if(点歌.equals("")||点歌==null) {
	        return;
	    }
	    if(网站状态.Get("http://api.mrgnb.cn/")==true) {
	        JSONObject 点歌list = new JSONObject(sendGet("http://api.mrgnb.cn/API/kgmusic.php?msg=" +点歌));
	        CheckMusic TempFlag = new CheckMusic();
		    String text = "当前搜索到的歌曲如下:\n";
		    String RawXmlCard = "";
		    for(int i = 0; i < 6; i++) {
			    try {
				    TempFlag.MusicMid[i] = 点歌list.getJSONArray("data").getJSONObject(i).getString("hash");
				text = text + (i+1) + "." + 点歌list.getJSONArray("data").getJSONObject(i).getString("name") +"\n";
			    } catch(e) {
				    break;
			    }
		    }
		    TempFlag.MusicName = 点歌;
		    TempFlag.time = data.createTime;
		    TempFlag.MusicType = 1;
		    MusicMap.put(wxid, TempFlag);
		    text = text + "\n发送序号点歌";
		    sendm(qun, text,0);
		    return;
	    }else{
	        sendm(qun,"@"+name+"\n音乐接口调用失败",0);
	    }
	}
	if(content.startsWith("QQ点歌")) {
        String QQ点歌 = content.substring(4).trim();
        CheckMusic TempFlag = new CheckMusic();
        if(QQ点歌.equals("")||QQ点歌==null) {
            return;
        }
        if(网站状态.Get(QQ点歌URL)==true) {
            String Q点歌 = QQ点歌URL.replace("[歌曲名称]", QQ点歌);
            Q点歌 = sendGet(Q点歌);
            Q点歌 = Q点歌.replace("、", ".");
            TempFlag.MusicName = QQ点歌;
		    TempFlag.time = data.createTime;
		    TempFlag.MusicType = 2;
		    MusicMap.put(wxid, TempFlag);
            sendm(qun,Q点歌+"\n发送序号点歌",0);
        }
    }
    if(content.startsWith("酷狗点歌")) {
        String 酷狗点歌 = content.substring(4).trim();
        CheckMusic TempFlag = new CheckMusic();
        if(酷狗点歌.equals("")||酷狗点歌==null) {
            return;
        }
        if(网站状态.Get(酷狗点歌URL)==true) {
            String 酷点歌 = 酷狗点歌URL.replace("[歌曲名称]", 酷狗点歌);
            酷点歌 = sendGet(酷点歌);
            酷点歌 = 酷点歌.replace("、", ".");
            TempFlag.MusicName = 酷狗点歌;
		    TempFlag.time = data.createTime;
		    TempFlag.MusicType = 3;
		    MusicMap.put(wxid, TempFlag);
            sendm(qun,酷点歌+"\n发送序号点歌",0);
        }
    }
    if(content.startsWith("网易点歌")) {
        String 网易点歌 = content.substring(4).trim();
        CheckMusic TempFlag = new CheckMusic();
        if(网易点歌.equals("")||网易点歌==null) {
            return;
        }
        if(网站状态.Get(网易点歌URL)==true) {
            String 网点歌 = 网易点歌URL.replace("[歌曲名称]", 网易点歌);
            网点歌 = sendGet(网点歌);
            网点歌 = 网点歌.replace("、", ".");
            TempFlag.MusicName = 网易点歌;
		    TempFlag.time = data.createTime;
		    TempFlag.MusicType = 3;
		    MusicMap.put(wxid, TempFlag);
            sendm(qun,网点歌+"\n发送序号点歌",0);
        }
    }
	if(content.matches("^\\d+$")) {
	    if(!MusicMap.containsKey(wxid)) {
			return;
		}
		String 序号 = content;
		CheckMusic MusicInfo = MusicMap.get(wxid);
		if(data.createTime - MusicInfo.time > 60000) {
			return;
		}
		if(MusicInfo.MusicType == 1) {
		    if(content.length()!= 1) {
		        return;
		    }
		    int 点歌序号 = Integer.parseInt(content)-1;
		    if(网站状态.Get("http://api.mrgnb.cn/")==true) {
		        String 点歌 = sendGet("http://api.mrgnb.cn/API/kgmusic.php?n="+点歌序号+"&msg=" + MusicInfo.MusicName);
                String dgname = 数据处理.JSON(数据处理.JSON(点歌,"data"),"name");
                dgname = 截取.末尾(dgname,"- ");
                String singername = 数据处理.JSON(数据处理.JSON(点歌,"data"),"singername");
                String song_url = 数据处理.JSON(数据处理.JSON(点歌,"data"),"song_url");
                song_url = u解(song_url);
                if(song_url.equals("付费歌曲暂时无法获取歌曲下载链接")) {
                    sendm(qun,"@"+name+"\n《"+dgname+"》- "+singername+"\n该歌曲为付费歌曲，暂时无法播放",0);
                    return;
                }
                String album_img = 数据处理.JSON(数据处理.JSON(点歌,"data"),"album_img");
                sendc(0,qun,dgname,singername,album_img,song_url,null);
            }else{
                sendm(qun,"@"+name+"\n音乐接口调用失败",0);
            }
		}
		if(MusicInfo.MusicType == 2) {
		    if(content.length()!= 1&&content.length() != 2) {
		        return;
		    }
		    if(网站状态.Get(QQ点歌数据)==true) {
		        String QQ点歌 = QQ点歌数据.replace("[歌曲名称]", MusicInfo.MusicName);
		        QQ点歌 = QQ点歌.replace("[序号]", 序号);
		        String Q点歌 = sendGet(QQ点歌);
                String dgname = 截取.取中间(Q点歌,"歌名：","\n歌手");
                String singername = 截取.取中间(Q点歌,"歌手：","\n播放链接");
                String album_img = 截取.取中间(Q点歌,"图片：","\n歌名");
                String song_url = 截取.末尾(Q点歌,"播放链接：");
                sendc(0,qun,dgname,singername,album_img,song_url,null);
            }else{
                sendm(qun,"@"+name+"\n音乐接口调用失败",0);
            }
		}
		if(MusicInfo.MusicType == 3) {
		    if(content.length()!= 1&&content.length() != 2) {
		        return;
		    }
		    if(网站状态.Get(酷狗点歌数据)==true) {
		        String 酷狗点歌 = 酷狗点歌数据.replace("[歌曲名称]", MusicInfo.MusicName);
		        酷狗点歌 = 酷狗点歌.replace("[序号]", 序号);
		        String 酷点歌 = sendGet(酷狗点歌);
                String dgname = 截取.取中间(酷点歌,"歌名：","\n歌手");
                String singername = 截取.取中间(酷点歌,"歌手：","\n播放链接");
                String album_img = 截取.取中间(酷点歌,"图片：","\n歌名");
                String song_url = 截取.末尾(酷点歌,"播放链接：");
                sendc(0,qun,dgname,singername,album_img,song_url,null);
            }else{
                sendm(qun,"@"+name+"\n音乐接口调用失败",0);
            }
		}
		if(MusicInfo.MusicType == 4) {
		    if(content.length()!= 1&&content.length() != 2) {
		        return;
		    }
		    if(网站状态.Get(网易点歌数据)==true) {
		        String 网易点歌 = 网易点歌数据.replace("[歌曲名称]", MusicInfo.MusicName);
		        网易点歌 = 网易点歌.replace("[序号]", 序号);
		        String 网点歌 = sendGet(网易点歌);
                String dgname = 截取.取中间(网点歌,"歌名：","\n歌手");
                String singername = 截取.取中间(网点歌,"歌手：","\n播放链接");
                String album_img = 截取.取中间(网点歌,"图片：","\n歌名");
                String song_url = 截取.末尾(网点歌,"播放链接：");
                sendc(0,qun,dgname,singername,album_img,song_url,null);
            }else{
                sendm(qun,"@"+name+"\n音乐接口调用失败",0);
            }
		}
	}
}
public class CheckMusic
{
	String MusicName;
	String[] MusicMid = new String[10];
	long time;
	int MusicType;
}