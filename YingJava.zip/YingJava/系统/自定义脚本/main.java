long 自定义脚本加载=System.currentTimeMillis();
Thread 自定义脚本=new Thread(new Runnable() {
    public void run() {
    }
});
自定义脚本.start();
try {
    自定义脚本.join();
} catch (InterruptedException e) {
    Thread.currentThread().interrupt();
}
long 自定义脚本加载结束=System.currentTimeMillis();
double 自定义脚本加载耗时=(自定义脚本加载结束-自定义脚本加载)/1000.0;
Toast("["+脚本名称+"]自定义脚本加载成功,耗时:"+自定义脚本加载耗时+"秒");