public static void 测试(Object data) {
    String content = data.content;
    String qun = data.talker;
    String wxid = data.sendTalker;
    if(content.equals("hhhmy")) {
    sendm(qun,"hhh",0);
}
    return;
}