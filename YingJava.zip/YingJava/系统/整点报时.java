int Hours = -1;
public void My____(Calendar NowTime){
    if (NowTime.get(Calendar.MINUTE) == 0 && NowTime.get(Calendar.SECOND) >= 0 && Hours != NowTime.get(Calendar.HOUR_OF_DAY)) {
        Hours = NowTime.get(Calendar.HOUR_OF_DAY);
        File directory = new File(JavaPath+"/data/Groups");
        if(directory.exists()) {
            File[] listFiles = directory.listFiles();
            if (listFiles != null) {
                for (File file : listFiles) {
                    if(file.isDirectory()) {
                        String qun = file.getName();
                        if(读整("Groups/"+qun,"开关","整点报时")==1) {
                            if (读整("Groups/"+qun,"整点报时", "type")==0) {
                                sendm(qun,读(qun,"整点报时", "报时内容","整点报时\n现在是北京时间[h]点整"),2);
                            }
                            if(读整("Groups/"+qun,"整点报时", "type") == 2) {
                                if(读("Groups/"+qun,"整点报时", "音乐报时内容",null)!=null) {
		                            sendm(qun,读("Groups/"+qun,"整点报时", "音乐报时内容",null),2);
		                        }
                                if(网站状态.Get("http://api.mrgnb.cn/API/netease.php?type=random")==true) {
                                    String 随机音乐 = sendGet("http://api.mrgnb.cn/API/netease.php?type=random");
                                    String data = 数据处理.JSON(随机音乐,"data");
                                    String 封面 = 数据处理.JSON(data,"image_url");
                                    String 音源 = 数据处理.JSON(data,"song_url");
                                    sendc(0,qun,"整点报时","现在是北京时间"+GetHour()+"点整",封面,音源,null);
                                }else{
                    sendm(qun,"@"+name+"\n整点报时音乐接口调用失败",0);
                                }
                            }
                        }else{
                            continue;
                        }
                    }
                }
            }
        }
    }
}
//-------------分发定时任务-----
public void TimeDispatch() {
	Calendar NowTime = Calendar.getInstance();
	My____(NowTime);
	MessageDispatch(NowTime);
}
public class ThreadTimer {
    private volatile boolean EndFlag = false;
    private final Thread MyThread = new Thread(new Runnable() {
        public void run() {
            while (!EndFlag && !Thread.currentThread().isInterrupted()) {
                try {
                    TimeDispatch();
                    Thread.sleep(1000);
                } catch (Throwable e) {
                    Toast(""+e);
                }
            }
        }
    });
    public void StartThread() {
        MyThread.start();
    }
    public void EndThread() {
        this.EndFlag = true;
        MyThread.interrupt();
    }
}
public void onUnload() {
    MyNewThreadTimer.EndThread();
    saveThreadThread.stop();
    Thread.sleep(3000);
}
ThreadTimer MyNewThreadTimer = new ThreadTimer();
MyNewThreadTimer.StartThread();
public void 整点报时(Object data) {
	String content = data.content;
	String qun = data.talker;
	String wxid=data.sendTalker;
	String name = getName(wxid);
	String 报时内容 = 读("Groups/"+qun,"整点报时", "报时内容","整点报时\n现在是北京时间[h]点整");
	String 音乐报时内容 = 读("Groups/"+qun,"整点报时", "音乐报时内容",null);
	String 随机音乐URL = "http://api.mrgnb.cn/API/netease.php?type=random";
if(mWxid.equals(wxid)){
    if(content.equals("整点报时")) {
        String text = "[e]设置报时类型文字/音乐\n[e]设置报时内容+文本\n[e]设置音乐报时内容+文本\n[e]查看报时内容\n[e]查看音乐报时内容\n(支持变量[Y][M][D][h][m][s][wd][yy])\n(年/月/日/小时/分钟/秒/星期几/一言)\n没有设置音乐报时内容则只发音乐";
        sendm(qun,text,0);
    }
	if(content.equals("查看报时内容")) {
		sendm(qun,"@"+name+"\n"+报时内容,0);
	}
	if(content.equals("查看音乐报时内容")) {
		sendm(qun, "@"+name+"\n"+音乐报时内容,0);
	}
	if(content.startsWith("设置报时内容")) {
		String text = content.substring(6);
		写("Groups/"+qun,"整点报时", "报时内容", text);
		写("Groups/"+qun,"整点报时", "type", 0);
		sendm(qun, "@"+name+"\n报时文本已设定",0);
	}
		if(content.startsWith("设置音乐报时内容")) {
		String text = content.substring(8);
		写("Groups/"+qun,"整点报时", "音乐报时内容", text);
		写("Groups/"+qun,"整点报时", "type", 2);
		sendm(qun, "@"+name+"\n音乐报时文本已设定",0);
	}
	if(content.equals("设置报时类型文字")) {
		写("Groups/"+qun,"整点报时", "type", 0);
		sendm(qun, "@"+name+"\n报时已设定为文本",0);
	}
	if(content.equals("设置报时类型音乐")) {
		写("Groups/"+qun,"整点报时", "type", 2);
		sendm(qun, "@"+name+"\n报时已设定为音乐",0);
	}
	if(content.equals("报时测试")) {
		if(读整("Groups/"+qun,"整点报时", "type") == 0) {
			sendm(qun,报时内容,2);
			return;
		}
		if(读整("Groups/"+qun,"整点报时", "type") == 2) {
			if(音乐报时内容!=null) {
		        sendm(qun,音乐报时内容,2);
		    }
            if(网站状态.Get(随机音乐URL)==true) {
                String 随机音乐 = sendGet(随机音乐URL);
                String data = 数据处理.JSON(随机音乐,"data");
                String 封面 = 数据处理.JSON(data,"image_url");
                String 音源 = 数据处理.JSON(data,"song_url");
                sendc(0,qun,"整点报时","现在是北京时间"+GetHour()+"点整",封面,音源,null);
            }else{
                sendm(qun,"@"+name+"\n整点报时音乐接口调用失败",0);
            }
            return;
		}
	}
}
	return;
}