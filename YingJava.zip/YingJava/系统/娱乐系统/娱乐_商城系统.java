public void 娱乐系统_商城系统(Object data) {
    String content = data.content;
    String qun = data.talker;
    String wxid = data.sendTalker;
    String name = getName(wxid);
    int 点券 = 读整("Groups/"+qun+"/Users",wxid+"_user","点券");
    int 体力 = 读整("Groups/"+qun+"/Users",wxid+"_user","体力");
    int 体力购买限制次数 = 读整("Groups/"+qun+"/Users",wxid+"_user","体力购买限制次数");
    String 体力购买限制时间 = 读("Groups/"+qun+"/Users",wxid+"_user","体力购买限制时间",GetTime(4));
    if(content.equals("装备商城")) {
        String text = "装备商城\n" + 
        "匕首   3千💴\n" + 
        "电棍   3万💴\n" + 
        "手枪   10万💴\n" + 
        "激光剑   500万💴\n" + 
        "火箭筒   5千万💴\n" + 
        "导弹   1亿💴\n" + 
        "核弹   2亿💴\n" + 
        "可发送\"购买装备+名字\"进行购买\n" + 
        "发送\"使用装备+名字\"使用装备";
        sendm(qun,text,0);
    }
    if(content.equals("体力商城")) {
        String text = "体力商城\n" + 
        "1⚡   200💴\n" + 
        "10⚡   1千💴\n" + 
        "50⚡   8千💴\n" + 
        "100⚡   1万💴\n" + 
        "可发送\"购买体力+数额(不带⚡)\"进行购买\n" + 
        "例:购买体力50\n" + 
        "PS:每人每日最多可购买3次";
        sendm(qun,text,0);
    }
    if(content.startsWith("购买装备")) {
        String 购买装备 = content.substring(4);
        int 装备 = 读整("Groups/"+qun+"/Users",wxid+"_user",购买装备);
        String 价格 = 购买装备.replace("匕首", "3000");
        价格 = 价格.replace("电棍","30000");
        价格 = 价格.replace("手枪","100000");
        价格 = 价格.replace("激光剑","5000000");
        价格 = 价格.replace("火箭筒","50000000");
        价格 = 价格.replace("导弹","100000000");
        价格 = 价格.replace("核弹","200000000");
        int 装备价格 = Integer.parseInt(价格);
        if(购买装备.equals("匕首")||购买装备.equals("电棍")||购买装备.equals("手枪")||购买装备.equals("激光剑")||购买装备.equals("火箭筒")||购买装备.equals("导弹")||购买装备.equals("核弹")) {
            if(装备==1) {
                String text = "@"+name+"\n你已经拥有"+购买装备+"，不能再购买了";
                sendm(qun,text,0);
                return;
            }
            if(点券>=装备价格) {
                写("Groups/"+qun+"/Users",wxid+"_user","点券",点券-装备价格);
                写("Groups/"+qun+"/Users",wxid+"_user",购买装备,1);
                String text = "@"+name+"\n购买成功!\n" + 
                "你花费 "+装备价格+"💴购买了 "+购买装备+"\n\n失去\n💴"+装备价格;
                sendm(qun,text,0);
            }else{
                sendm(qun,"@"+name+"\n你太穷了，还买不起 "+购买装备,0);
            }
        }
    }
    if(content.startsWith("使用装备")) {
        String 使用装备 = content.substring(4);
        int 装备 = 读整("Groups/"+qun+"/Users",wxid+"_user",使用装备);
        String 代号 = 使用装备.replace("匕首", "1");
        代号 = 代号.replace("电棍","2");
        代号 = 代号.replace("手枪","3");
        代号 = 代号.replace("激光剑","4");
        代号 = 代号.replace("火箭筒","5");
        代号 = 代号.replace("导弹","6");
        代号 = 代号.replace("核弹","7");
        int 装备代号 = Integer.parseInt(代号);
        String 伤害 = 使用装备.replace("匕首", "1");
        伤害 = 伤害.replace("电棍","2");
        伤害 = 伤害.replace("手枪","5");
        伤害 = 伤害.replace("激光剑","10");
        伤害 = 伤害.replace("火箭筒","20");
        伤害 = 伤害.replace("导弹","50");
        伤害 = 伤害.replace("核弹","100");
        int 装备伤害 = Integer.parseInt(伤害);
        if(使用装备.equals("匕首")||使用装备.equals("电棍")||使用装备.equals("手枪")||使用装备.equals("激光剑")||使用装备.equals("火箭筒")||使用装备.equals("导弹")||使用装备.equals("核弹")) {
            if(装备==1) {
                写("Groups/"+qun+"/Users",  wxid+"_user", "装备数据", 装备伤害);
		        写("Groups/"+qun+"/Users",  wxid+"_user", "当前装备", 装备代号);
		        sendm(qun,"@"+name+"\n已成功使用 "+使用装备+" ，快去打劫别人试试",0);
            }else{
                sendm(qun,"@"+name+"\n你未拥有 "+使用装备+" ，前往\"装备商城\"购买后再试",0);
            }
        }
    }
    if(content.startsWith("购买体力")) {
        String 购买体力2 = content.substring(4);
        int 购买体力 = Integer.parseInt(购买体力2);
        int 体力价格 = 0;
        if(购买体力==1) {
            体力价格 = 200;
        }else if(购买体力==10) {
            体力价格 = 1000;
        }else if(购买体力==50) {
            体力价格 = 8000;
        }else if(购买体力==100) {
            体力价格 = 10000;
        }
        if(购买体力==1||购买体力==10||购买体力==50||购买体力==100) {
            if(时间间隔.天数(体力购买限制时间)<1&&体力购买限制次数>3) {
                写("Groups/"+qun+"/Users",wxid+"_user","体力购买限制时间",GetTime(4));
                sendm(qun,"@"+name+"\n今日体力购买已上限，明日再来",0);
                return;
            }
            if(时间间隔.天数(体力购买限制时间)<1) {
                if(点券>=体力价格) {
                    写("Groups/"+qun+"/Users",wxid+"_user","点券",点券-体力价格);
                    if(体力+购买体力>=100) {
                        写("Groups/"+qun+"/Users",wxid+"_user","体力",100);
                    }else{
                        写("Groups/"+qun+"/Users",wxid+"_user","体力",体力+购买体力);
                    }
                    写("Groups/"+qun+"/Users",wxid+"_user","体力购买限制次数",体力购买限制次数+1);
                    String text = "@"+name+"\n购买成功!\n" + 
                    "你花费 "+体力价格+"💴购买了 "+购买体力+"⚡\n\n获得\n⚡"+购买体力+"\n失去\n💴"+体力价格;
                    sendm(qun,text,0);
                    return;
                }else{
                    sendm(qun,"@"+name+"\n你太穷了，还买不起 "+购买体力+"⚡",0);
                    return;
                }
            }
            if(时间间隔.天数(体力购买限制时间)>=1) {
                if(点券>=体力价格) {
                    写("Groups/"+qun+"/Users",wxid+"_user","点券",点券-体力价格);
                    if(体力+购买体力>=100) {
                        写("Groups/"+qun+"/Users",wxid+"_user","体力",100);
                    }else{
                        写("Groups/"+qun+"/Users",wxid+"_user","体力",体力+购买体力);
                    }
                    写("Groups/"+qun+"/Users",wxid+"_user","体力购买限制次数",1);
                    写("Groups/"+qun+"/Users",wxid+"_user","体力购买限制时间",GetTime(4));
                    String text = "@"+name+"\n购买成功!\n" + 
                    "你花费 "+体力价格+"💴购买了 "+购买体力+"⚡\n\n获得\n⚡"+购买体力+"\n失去\n💴"+价格;
                    sendm(qun,text,0);
                    return;
                }else{
                    sendm(qun,"@"+name+"\n你太穷了，还买不起 "+购买体力+"⚡",0);
                    return;
                }
            }
        }
    }
}