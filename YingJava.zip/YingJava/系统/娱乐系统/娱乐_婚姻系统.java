public void 娱乐系统_婚姻系统(Object data) {
	String content = data.content;
	String qun = data.talker;
	String wxid = data.sendTalker;
	String name = getName(wxid);
    String 表白 = 读("Groups/"+qun+"/Users",wxid+"_user","表白","空");
    String 被表白 = 读("Groups/"+qun+"/Users",wxid+"_user","被表白","空");
    String 求婚 = 读("Groups/"+qun+"/Users",wxid+"_user","求婚","空");
    String 被求婚 = 读("Groups/"+qun+"/Users",wxid+"_user","被求婚","空");
    String 婚姻状态 = 读("Groups/"+qun+"/Users",wxid+"_user","婚姻状态","未婚");
	if(data.isReply()) {
		String wxid2 = getElementContent(data.content, "chatusr");
		String content2 = getElementContent(data.content, "title");
		String name2 = getName(wxid2);
        String 表白2 = 读("Groups/"+qun+"/Users",wxid2+"_user","表白","空");
        String 被表白2 = 读("Groups/"+qun+"/Users",wxid2+"_user","被表白","空");
        String 求婚2 = 读("Groups/"+qun+"/Users",wxid2+"_user","求婚","空");
        String 被求婚2 = 读("Groups/"+qun+"/Users",wxid2+"_user","被求婚","空");
        String 婚姻状态2 = 读("Groups/"+qun+"/Users",wxid2+"_user","婚姻状态","未婚");
        if(content2.startsWith("表白")) {
            String textStr = content2.substring(2);
            if(wxid2.equals(wxid)) {
                return;
            }
            String 婚姻 = 截取.末尾(婚姻状态,"]");
            if(!婚姻状态.equals("未婚")&&!婚姻.equals(wxid2)) {
                sendm(qun,"@"+name+"\n你已心有所属，无法向其他人表白",0);
                return;
            }
            if(textStr==null||textStr.equals("")) {
                textStr = "[对方没有发出任何表白话语]";
            }
            写("Groups/"+qun+"/Users",wxid+"_user","表白",wxid2);
            写("Groups/"+qun+"/Users",wxid2+"_user","被表白",wxid);
            String text = "@"+name2+"\n["+name+" 向你表白❤️]\n"+textStr+"\n\n💞你可发送\"我愿意\"或\"我拒绝\"💕";
            sendm(qun,text,0);
        }
        if(content2.equals("结婚")) {
            if(wxid2.equals(wxid)) {
                return;
            }
            String 婚姻 = 截取.末尾(婚姻状态,"]");
            if(!婚姻状态.equals("未婚")&&!婚姻.equals(wxid2)) {
                sendm(qun,"@"+name+"\n你已心有所属，无法向其他人求婚",0);
                return;
            }
            if(!婚姻状态.contains("[男/女朋友]")) {
                sendm(qun,"@"+name+"\n饭要一口一口吃，事要一件一件办\n凡事总要有个过程，不能急于求成\n请先向你心爱对象表白哦💕");
                return;
            }
            写("Groups/"+qun+"/Users",wxid+"_user","求婚",wxid2);
            写("Groups/"+qun+"/Users",wxid2+"_user","被求婚",wxid);
            String text = "@"+name2+"\n"+name+" 向你求婚了！💖\n💞你可发送\"同意\"或\"拒绝\"💕";
            sendm(qun,text,0);
        }
    }
    if(content.equals("我愿意")) {
        if(被表白.equals("空")||被表白==null) {
            return;
        }
        String text = "@"+name+"\n💞你接受了 "+getName(被表白)+" 的表白💞\n你们现在是男/女朋友的关系喽~";
        写("Groups/"+qun+"/Users",wxid+"_user","婚姻状态","[男/女朋友]"+被表白);
        写("Groups/"+qun+"/Users",被表白+"_user","婚姻状态","[男/女朋友]"+wxid);
        删("Groups/"+qun+"/Users",被表白+"_user","表白");
        删("Groups/"+qun+"/Users",wxid+"_user","被表白");
        sendm(qun,text,0);
        sendm(qun,"@"+getName(被表白)+"\n💞恭喜你，表白成功啦！💞\n你们现在是男/女朋友的关系喽~");
    }
    if(content.equals("我拒绝")) {
        if(被表白.equals("空")||被表白==null) {
            return;
        }
        String text = "@"+name+"\n💔你拒绝了 "+getName(被表白)+" 的表白💔";
        删("Groups/"+qun+"/Users",被表白+"_user","表白");
        删("Groups/"+qun+"/Users",wxid+"_user","被表白");
        sendm(qun,text,0);
        sendm(qun,"@"+getName(被表白)+"\n💔很遗憾，对方拒绝了你的表白💔");
    }
    if(content.equals("同意")) {
        if(被求婚.equals("空")||被求婚==null) {
            return;
        }
        String text = "@"+name+"\n💖你同意了 "+getName(被求婚)+" 的求婚!💖\n你们现在是夫妻啦~";
        写("Groups/"+qun+"/Users",wxid+"_user","婚姻状态","[夫妻]"+被求婚);
        写("Groups/"+qun+"/Users",被求婚+"_user","婚姻状态","[夫妻]"+wxid);
        删("Groups/"+qun+"/Users",被求婚+"_user","求婚");
        删("Groups/"+qun+"/Users",wxid+"_user","被求婚");
        sendm(qun,text,0);
        sendm(qun,"@"+getName(被求婚)+"\n💖祝贺你！求婚成功拉！💖\n你们现在是夫妻啦~");
    }
    if(content.equals("拒绝")) {
        if(被求婚.equals("空")||被求婚==null) {
            return;
        }
        String text = "@"+name+"\n💔你拒绝了 "+getName(被求婚)+" 的求婚💔";
        删("Groups/"+qun+"/Users",被表白+"_user","求婚");
        删("Groups/"+qun+"/Users",wxid+"_user","被求婚");
        sendm(qun,text,0);
        sendm(qun,"@"+getName(被求婚)+"\n💔很遗憾，对方拒绝了你的求婚💔");
    }
}