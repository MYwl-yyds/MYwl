public void 娱乐系统_抽卡池(Object data) {
    String content = data.content;
    String qun = data.talker; 
    String wxid = data.sendTalker;
	String name = getName(wxid);
    int 点券 = 读整("Groups/"+qun+"/Users", wxid + "_user", "点券");
    int 体力 = 读整("Groups/"+qun+"/Users", wxid + "_user", "体力");
    int 打劫失败 = 读整("Groups/"+qun+"/Users",wxid+"_user","打劫失败");
    int 普通池次数 = 读整("Groups/"+qun+"/Users", wxid + "_user", "普通池次数");
    String 普通池时间 = 读("Groups/"+qun+"/Users", wxid + "_user", "普通池时间",GetTime(4));
    int 高级池次数 = 读整("Groups/"+qun+"/Users", wxid + "_user", "高级池次数");
    String 高级池时间 = 读("Groups/"+qun+"/Users", wxid + "_user", "高级池时间",GetTime(4));
    int 传奇池次数 = 读整("Groups/"+qun+"/Users", wxid + "_user", "传奇池次数");
    String 传奇池时间 = 读("Groups/"+qun+"/Users", wxid + "_user", "传奇池时间",GetTime(4));
    double 匕首概率 = 0;
    double 电棍概率 = 0;
    double 手枪概率 = 0;
    double 激光剑概率 = 0;
    double 火箭筒概率 = 0;
    double 导弹概率 = 0;
    double 核弹概率 = 0;
    double 点券概率 = 0;
    double 体力概率 = 0;
    double 空概率 = 0;
    double 监狱概率 = 0;
    double 医院概率 = 0;
    double 清点券概率 = 0;
    double 清体力概率 = 0;
    double 打劫概率 = 0;
    String 卡池类型 = "";
    String 卡池结果 = "";
    if(content.equals("抽普通池")||content.equals("抽高级池")||content.equals("抽传奇池")) {
        double 卡池概率 = Math.random();
        if(content.equals("抽普通池")) {
            if(时间间隔.天数(普通池时间)==0&&普通池次数>=30) {
                sendm(qun,"@"+name+"\n今日普通池抽取次数上限，明日再来",0);
                return;
            }
            匕首概率 = 0.1;
            电棍概率 = 0.06;
            点券概率 = 0.3;
            体力概率 = 0.5;
            空概率 = 0.7;
            监狱概率 = 0.8;
            医院概率 = 0.9;
            if(时间间隔.天数(普通池时间)>=1) {
                写("Groups/"+qun+"/Users", wxid + "_user", "普通池次数", 1);
                写("Groups/"+qun+"/Users", wxid + "_user", "普通池时间", GetTime(4));
            }else{
                写("Groups/"+qun+"/Users", wxid + "_user", "普通池次数", 普通池次数 + 1);
                写("Groups/"+qun+"/Users", wxid + "_user", "普通池时间", GetTime(4));
            }
            卡池类型 = "普通池";
            if(卡池概率<点券概率) {
                卡池结果 = "点券";
            }else if(卡池概率<体力概率) {
                卡池结果 = "体力";
            }else if(卡池概率<空概率) {
                卡池结果 = "空";
            }else if(卡池概率<医院概率) {
                卡池结果 = "医院";
            }else if(卡池概率<监狱概率) {
                卡池结果 = "监狱";
            }else if(卡池概率<匕首概率) {
                卡池结果 = "匕首";
            }else if(卡池概率<电棍概率) {
                卡池结果 = "电棍";
            }else{
                卡池结果 = "空";
            }
        }else if(content.equals("抽高级池")) {
            if(时间间隔.天数(高级池时间)==0&&高级池次数>=20) {
                sendm(qun,"@"+name+"\n今日高级池抽取次数上限，明日再来",0);
                return;
            }
            手枪概率 = 0.09;
            激光剑概率 = 0.04;
            点券概率 = 0.19;
            体力概率 = 0.29;
            空概率 = 0.39;
            监狱概率 = 0.5;
            医院概率 = 0.6;
            清点券概率 = 0.7;
            清体力概率 = 0.8;
            打劫概率 = 0.9;
            if(时间间隔.天数(高级池时间)>=1) {
                写("Groups/"+qun+"/Users", wxid + "_user", "高级池次数", 1);
                写("Groups/"+qun+"/Users", wxid + "_user", "高级池时间", GetTime(4));
            }else{
                写("Groups/"+qun+"/Users", wxid + "_user", "高级池次数", 高级池次数 + 1);
                写("Groups/"+qun+"/Users", wxid + "_user", "高级池时间", GetTime(4));
            }
            卡池类型 = "高级池";
            if(卡池概率<手枪概率) {
                卡池结果 = "手枪";
            }else if(卡池概率<激光剑概率) {
                卡池结果 = "激光剑";
            }else if(卡池概率<点券概率) {
                卡池结果 = "点券";
            }else if(卡池概率<体力概率) {
                卡池结果 = "体力";
            }else if(卡池概率<空概率) {
                卡池结果 = "空";
            }else if(卡池概率<监狱概率) {
                卡池结果 = "监狱";
            }else if(卡池概率<医院概率) {
                卡池结果 = "医院";
            }else if(卡池概率<清点券概率) {
                卡池结果 = "清点券";
            }else if(卡池概率<清体力概率) {
                卡池结果 = "清体力";
            }else if(卡池概率<打劫概率) {
                卡池结果 = "打劫";
            }else{
                卡池结果 = "空";
            }
        }else if(content.equals("抽传奇池")) {
            if(时间间隔.天数(传奇池时间)==0&&传奇池次数>=10) {
                sendm(qun,"@"+name+"\n今日传奇池抽取次数上限，明日再来",0);
                return;
            }
            火箭筒概率 = 0.06;
            导弹概率 = 0.04;
            核弹概率 = 0.01;
            点券概率 = 0.1;
            体力概率 = 0.2;
            空概率 = 0.3;
            监狱概率 = 0.4;
            医院概率 = 0.5;
            清点券概率 = 0.7;
            清体力概率 = 0.75;
            打劫概率 = 0.9;
            if(时间间隔.天数(传奇池时间)>=1) {
                写("Groups/"+qun+"/Users", wxid + "_user", "传奇池次数", 1);
                写("Groups/"+qun+"/Users", wxid + "_user", "传奇池时间", GetTime(4));
            }else{
                写("Groups/"+qun+"/Users", wxid + "_user", "传奇池次数", 传奇池次数 + 1);
                写("Groups/"+qun+"/Users", wxid + "_user", "传奇池时间", GetTime(4));
            }
            卡池类型 = "传奇池";
            if(卡池概率<手枪概率) {
                卡池结果 = "手枪";
            }else if(卡池概率<激光剑概率) {
                卡池结果 = "激光剑";
            }else if(卡池概率<点券概率) {
                卡池结果 = "点券";
            }else if(卡池概率<体力概率) {
                卡池结果 = "体力";
            }else if(卡池概率<空概率) {
                卡池结果 = "空";
            }else if(卡池概率<监狱概率) {
                卡池结果 = "监狱";
            }else if(卡池概率<医院概率) {
                卡池结果 = "医院";
            }else if(卡池概率<清点券概率) {
                卡池结果 = "清点券";
            }else if(卡池概率<清体力概率) {
                卡池结果 = "清体力";
            }else if(卡池概率<打劫概率) {
                卡池结果 = "打劫";
            }else{
                卡池结果 = "无";
            }
        }
        if(卡池结果.equals("匕首")) {
            sendm(qun, "@"+ name + "\n" + "你抽的是 "+卡池类型+"\n抽到了:装备-匕首\n\n获得\n🔪匕首\n失去\n💴100",0);
            写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券-100);
            写("Groups/"+qun+"/Users", wxid+"_user", "匕首", 1);
            return;
        }else if(卡池结果.equals("电棍")) {
            sendm(qun, "@"+ name + "\n" + "你抽的是 "+卡池类型+"\n抽到了:装备-电棍\n\n获得\n🔪电棍\n失去\n💴100",0);
            写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券-100);
            写("Groups/"+qun+"/Users", wxid+"_user", "电棍", 1);
            return;
        }else if(卡池结果.equals("手枪")) {
            sendm(qun, "@"+ name + "\n" + "你抽的是 "+卡池类型+"\n抽到了:装备-手枪\n\n获得\n🔪手枪\n失去\n💴100",0);
            写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券-100);
            写("Groups/"+qun+"/Users", wxid+"_user", "手枪", 1);
            return;
        }else if(卡池结果.equals("激光剑")) {
            sendm(qun, "@"+ name + "\n" + "你抽的是 "+卡池类型+"\n抽到了:装备-激光剑\n\n获得\n🔪激光剑\n失去\n💴100",0);
            写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券-100);
            写("Groups/"+qun+"/Users", wxid+"_user", "激光剑", 1);
            return;
        }else if(卡池结果.equals("火箭筒")) {
            sendm(qun, "@"+ name + "\n" + "你抽的是 "+卡池类型+"\n抽到了:装备-火箭筒\n\n获得\n🔪火箭筒\n失去\n💴100",0);
            写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券-100);
            写("Groups/"+qun+"/Users", wxid+"_user", "火箭筒", 1);
            return;
        }else if(卡池结果.equals("导弹")) {
            sendm(qun, "@"+ name + "\n" + "你抽的是 "+卡池类型+"\n抽到了:装备-导弹\n\n获得\n🔪导弹\n失去\n💴100",0);
            写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券-100);
            写("Groups/"+qun+"/Users", wxid+"_user", "导弹", 1);
            return;
        }else if(卡池结果.equals("核弹")) {
            sendm(qun, "@"+ name + "\n" + "你抽的是 "+卡池类型+"\n抽到了:装备-核弹\n\n获得\n🔪核弹\n失去\n💴100",0);
            写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券-100);
            写("Groups/"+qun+"/Users", wxid+"_user", "核弹", 1);
            return;
        }else if(卡池结果.equals("点券")) {
            int dq = 50 + (int)(Math.random() * 4951);
            sendm(qun, "@"+ name + "\n" + "你抽的是 "+卡池类型+"\n抽到了:随机点券\n\n获得\n💴"+dq+"\n失去\n💴100",0);
            写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券+dq-100);
            return;
        }else if(卡池结果.equals("体力")) {
            int tl = 5 + (int)(Math.random() * 46);
            sendm(qun, "@"+ name + "\n" + "你抽的是 "+卡池类型+"\n抽到了:随机体力\n\n获得\n⚡"+tl+"\n失去\n💴100",0);
            if(体力+tl>=100) {
                写("Groups/"+qun+"/Users", wxid + "_user", "体力", 100);
            }else{
                写("Groups/"+qun+"/Users", wxid + "_user", "体力", 体力+tl);
            }
            写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券-100);
            return;
        }else if(卡池结果.equals("空")) {
            sendm(qun, "@"+ name + "\n" + "你抽的是 "+卡池类型+"\n很遗憾，你什么都没有抽到\n\n失去\n💴100",0);
            写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券-100);
            return;
        }else if(卡池结果.equals("监狱")) {
            int randomExtraTime = (int) (Math.random() * 600000);
            sendm(qun, "@"+ name + "\n" + "你抽的是 "+卡池类型+"\n嗯哼？你无缘无故就被监禁了" + secondToTime(randomExtraTime / 1000) + "\n\n状态\n🕋"+secondToTime(randomExtraTime / 1000)+"\n失去\n💴100",0);
            写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券-100);
            写("Groups/"+qun+"/Users", wxid+"_user","监狱", data.createTime+randomExtraTime);
            return;
        }else if(卡池结果.equals("医院")) {
            sendm(qun, "@"+ name + "\n" + "你抽的是 "+卡池类型+"\n嗯哼？你无缘无故受了伤，住进医院2分钟\n\n状态\n🏥2分钟\n失去\n💴100",0);
            写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券-100);
            写("Groups/"+qun+"/Users", wxid+"_user","住院", data.createTime+120000);
            return;
        }else if(卡池结果.equals("清点券")) {
            int rnd = 1000 + (int)(Math.random() * 2001);
            rnd += 100;
            sendm(qun, "@"+ name + "\n" + "你抽的是 "+卡池类型+"\n你的点券正在流失！\n\n失去\n💴" + rnd,0);
            写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券-rnd);
            return;
        }else if(卡池结果.equals("清体力")) {
            int rnd = 5 + (int)(Math.random() * 46);
            sendm(qun, "@"+ name + "\n" + "你抽的是 "+卡池类型+"\n你突然感到全身乏力！\n\n失去\n💴100  ⚡" + rnd,0);
            写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券-100);
            if(体力-rnd<=0) {
                写("Groups/"+qun+"/Users", wxid + "_user", "体力", 0);
            }else{
                写("Groups/"+qun+"/Users", wxid + "_user", "体力", 体力-rnd);
            }
            return;
        }else if(卡池结果.equals("打劫")) {
            String[] LName = {"拳头", "匕首", "电棍", "手枪", "激光剑", "火箭筒", "导弹", "核弹"};
			String text = "@" + name + "\n";
			text += "你抽的是 "+卡池类型+"\n触发打劫并被强制失败\n打劫失败\n";
			int coin = (int)(Math.random() * 3000);
			coin += 100;
			text += "你使用的是:" + LName[读整("Groups/"+qun+"/Users",  wxid+"_user", "当前装备")];
			text += "\n对方使用的是:[系统-无敌]";
			text += "\n你被对方反杀了";
			text += "\n\n失去\n💴" + coin;
			写("Groups/"+qun+"/Users",  wxid+"_user", "点券", 点券 - coin);
			if(网站状态.Get("http://gchat.qpic.cn/gchatpic_new/184757891/582544273-2234018960-097C0892617D810C50BCBD67F1AE132D/0?term=2")==true) {
			    sendPic(qun, "http://gchat.qpic.cn/gchatpic_new/184757891/582544273-2234018960-097C0892617D810C50BCBD67F1AE132D/0?term=2");
			}else{
			    sendPic(qun, JavaPath+"/YingJava/附属/Resources/IMG/JPG/娱乐_打劫3.jpg");
			}
			sendm(qun,text,0);
			写("Groups/"+qun+"/Users",  wxid+"_user", "打劫失败", 打劫失败 + 1);
            return;
        }else{
            sendm(qun,"@"+name+"\n抽卡池出现异常\n\n检查信息\n卡池类型["+卡池类型+"]\n抽取结果["+卡池结果+"]\n\nPS:小概率会出现此情况，可尝试重新抽卡池",0);
        }
    }
}