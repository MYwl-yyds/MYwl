Map groupGameState = new HashMap();
HashMap groupCy = new HashMap();
HashMap startTime = new HashMap();
HashMap timers = new HashMap();
public void 娱乐系统_游戏(Object data) {
    String content = data.content;
    String qun = data.talker; 
    String wxid = data.sendTalker;
    String name = getName(wxid);
    Timer timer = new Timer();
    boolean gameStarted = startTime.containsKey(qun);
    int 点券 = 读整("Groups/"+qun+"/Users",wxid+"_user","点券");
    int 体力 = 读整("Groups/"+qun+"/Users",wxid+"_user","体力");
    int 猜谜胜 = 读整("Groups/"+qun+"/Users",wxid+"_user","猜谜胜");
    int 猜谜败 = 读整("Groups/"+qun+"/Users",wxid+"_user","猜谜败");
    int 猜数胜 = 读整("Groups/"+qun+"/Users",wxid+"_user","猜数胜");
    int 猜数败 = 读整("Groups/"+qun+"/Users",wxid+"_user","猜数败");
    int 猜歌胜 = 读整("Groups/"+qun+"/Users",wxid+"_user","猜歌胜");
    int 猜歌败 = 读整("Groups/"+qun+"/Users",wxid+"_user","猜歌败");
    int 接龙胜 = 读整("Groups/"+qun+"/Users",wxid+"_user","接龙胜");
    if(content.startsWith("开始")) {
        String text = content.substring(2);
        if(text.equals("猜谜语")) {
            if(groupGameState.containsKey(qun+"猜谜语")) {
			        String text = "@"+name+" \n" + 
                "当前群聊有人正在游玩中，请等待其游玩结束后开始";
                sendm(qun,text,0);
			    return;
		    }
            if(体力>= 1) {
		        JSONObject json = new JSONObject(sendGet("https://api.tangdouz.com/czm.php"));
                String zm = json.getString("zm"); 
                String key = json.getString("key"); 
		        Map state = new HashMap();
                state.put("正确谜", key);
                state.put("发起者", wxid);
                TimerTask timerTask = new TimerTask() {
                    public void run() {
                        if(体力-1< 0) {
                            写("Groups/"+qun+"/Users",wxid+"_user","体力",0);
                        }else{
                            写("Groups/"+qun+"/Users",wxid+"_user","体力",体力-1);
                        }
                        写("Groups/"+qun+"/Users",wxid+"_user","点券",点券-1000);
                        写("Groups/"+qun+"/Users",wxid+"_user","猜谜败",猜谜败+1);
                        String text = "@"+name+" \n" + 
                        "时间到，游戏结束!\n" + 
                        "正确数字: "+key+"\n\n" + 
                        "失去\n💴1000  ⚡1";
                        sendm(qun,text,0);
                        groupGameState.remove(qun+"猜谜语");
                    }
                };
                timer.schedule(timerTask, 300000);
                state.put("timerTask", timerTask);
                groupGameState.put(qun+"猜谜语", state);
                String text = "@"+name+" \n" + 
                "猜谜语已开始!\n\n" + 
                "谜: "+zm+"\n答一字\n\n" + 
                "发送\"猜谜+内容\"可进行游戏\n" + 
                "⏰限时5分钟";
		        sendm(qun,text,0);
            }else{
                sendm(qun,"@"+name+" \n体力不足1⚡",0);
                return;
            }
        }
        if(text.equals("猜数字")) {
            if(groupGameState.containsKey(qun+"猜数字")) {
                String text = "@"+name+" \n" + 
                "当前群聊有人正在游玩中，请等待其游玩结束后开始";
                sendm(qun,text,0);
			    return;
		    }
		    if(体力>=1) {
		        int NowInt = Math.random()*99+1;
		        Map state = new HashMap();
                state.put("次数", 5);
                state.put("正确数字", NowInt);
                state.put("发起者", wxid);
                TimerTask timerTask = new TimerTask() {
                    public void run() {
                        写("Groups/"+qun+"/Users", wxid+"_user", "点券", 点券-1000);
                        写("Groups/"+qun+"/Users", wxid+"_user", "猜数败", 猜数败+1);
                        if(体力-1 < 0) {
                            写("Groups/"+qun+"/Users", wxid+"_user", "体力", 0);
                        }else{
                            写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力-1);
                        }
                        String text = "@"+name+" \n" + 
                        "时间到，游戏结束!\n" + 
                        "正确数字: "+NowInt+"\n" + 
                        "\n失去\n"+"💴1000  ⚡1";
                        sendm(qun,text,0);
                        groupGameState.remove(qun+"猜数字");
                    }
                };
                timer.schedule(timerTask, 300000);
                state.put("timerTask", timerTask);
                groupGameState.put(qun+"猜数字", state);
                String text = "@"+name+" \n" + 
                "猜数字已开始!\n" + 
                "发送\"猜数+数字\"可进行游戏\n" + 
                "数字大小范围为1-99\n" + 
                "⏰限时5分钟\n" + 
                "🎲限制5次机会";
		        sendm(qun,text,0);
		    }else{
                sendm(qun,"@"+name+" \n体力不足1⚡",0);
                return;
            }
        }
        if(text.equals("猜歌名")) {
            if(groupGameState.containsKey(qun+"猜歌名")) {
			    String text = "@"+name+" \n" + 
                "当前群聊有人正在游玩中，请等待其游玩结束后开始";
                sendm(qun,text,0);
			    return;
		    }
		    if(体力>=1) {
		        if(网站状态.Get("https://v.api.aa1.cn/api/caigequ/?type=json")==false) {
		            String text = "@"+name+" \n" + 
		            "音乐API调用失败，请稍后重试";
		            sendm(qun,text,0);
		            return;
		        }
		        JSONObject json = new JSONObject(sendGet("https://v.api.aa1.cn/api/caigequ/?type=json"));
                if (json == null || json.isNull("author") || json.isNull("SongTitle") || json.isNull("mp3")) {
                    String text = "@"+name+" \n" + 
		            "音乐API调用失败，请稍后重试";
		            sendm(qun,text,0);
		            return;
                }
                String author = json.getString("author");
                String SongTitle = json.getString("SongTitle");
                String mp3 = json.getString("mp3");
                JSONObject musicData = new JSONObject();
                musicData.put("musicDataUrl", "https:" + mp3);
                musicData.put("title", "猜歌名(" + author + ")");
                musicData.put("description", "发送\"猜歌+歌名\"可进行游戏\n⏰限时5分钟");
                TimerTask timerTask = new TimerTask() {
                    public void run() {
                        String text = "@"+name+" \n" + 
                        "时间到，游戏结束!\n" + 
                        "正确答案: "+SongTitle+"\n" + 
                        "\n失去\n"+"💴1000  ⚡1";
                        sendm(qun,text,0);
                        if(体力 - 1 < 0)
                        {
                            写("Groups/"+qun+"/Users", wxid+"_user", "体力", 0);
                        }else{
                            写("Groups/"+qun+"/Users", wxid+"_user", "体力",体力 - 1);
                        }
                        写("Groups/"+qun+"/Users", wxid+"_user", "点券", 点券 - 1000);
                        写("Groups/"+qun+"/Users", wxid+"_user", "猜歌败", 猜歌败 + 1);
                        groupGameState.remove(qun+"猜歌名");
                    }
                };
                timer.schedule(timerTask, 300000);
                Map state = new HashMap();
                state.put("正确名", SongTitle);
                state.put("发起者", wxid);
                state.put("timerTask", timerTask);
                groupGameState.put(qun+"猜歌名", state);
                sendMusicCard(qun, musicData);
		    }else{
		        sendm(qun,"@"+name+" \n体力不足1⚡",0);
                return;
		    }
	    }
	    if(text.equals("井字棋")) {
            startNewGame(qun, wxid);
        }
        if(text.equals("成语接龙")) {
            if (gameStarted) {
                sendm(qun, "@"+name+"\n正在进行\n" + groupCy.get(qun),0);
                return;
            }
            String NewCy = sendGet("https://xiaoapi.cn/API/cyjl.php?id=" + qun + "&msg=开始成语接龙");
            String retText = NewCy + "\n发送 我接+你的成语来进行游戏\n请在80秒内接龙，否则游戏结束";
            sendm(qun, retText,0);
            groupCy.put(qun, NewCy); // 存储当前成语
            startTime.put(qun, data.createTime); // 记录游戏开始时间
            // 创建计时器
            Timer timer = new Timer();
            timers.put(qun, timer);
            timer.schedule(new TimerTask() {
            //@Override
                public void run() {
                    // 如果60秒内没有接龙，游戏结束
                    groupCy.remove(qun);
                    startTime.remove(qun);
                    sendm(qun, "游戏超时，接龙失败。发送“开始成语接龙”重新开始游戏",0);
                }
            }, TimeUnit.SECONDS.toMillis(80));
        }
    }
    if(content.startsWith("猜谜")) {
        if(!groupGameState.containsKey(qun+"猜谜语")) return;
        Map state = groupGameState.get(qun+"猜谜语");
        String 正确迷 = (String) state.get("正确谜");
        String starterWxid = (String) state.get("发起者");
        if (!wxid.equals(starterWxid)) {
            String text = "@"+name+" \n" + 
            "当前游戏由@"+getName(starterWxid)+" 发起\n" + 
            "请等待其游玩结束后再开始新游戏";
            sendm(qun,text,0);
            return;
        }
        try {
            String guess = content.substring(2);
            if (正确迷.equals(guess)) {
                if(体力-1<0)
                {
                    写("Groups/"+qun+"/Users",wxid+"_user","体力",0);
                }else{
                    写("Groups/"+qun+"/Users",wxid+"_user","体力",体力-1);
                }
                写("Groups/"+qun+"/Users",wxid+"_user","点券",点券+1000);
                写("Groups/"+qun+"/Users",wxid+"_user","猜谜胜",猜谜胜+1);
                String text = "@"+name+" \n" + 
                "恭喜你猜出正确谜语!\n\n" + 
                "获得\n"+"💴1000\n" + 
                "失去\n"+"⚡1";
                sendm(qun,text,0);
                groupGameState.remove(qun+"猜谜语");
                TimerTask timerTask = (TimerTask) state.get("timerTask");
                timerTask.cancel();
            } else {
                String text = "@"+name+" \n" + 
                "猜错了，再想想";
                sendm(qun,text,0);
            }
        } catch (Exception e) {
            String text = "@"+name+" \n" + 
            "你的输入有误";
            sendm(qun,text,0);
        }
    }
    if(content.startsWith("猜数")) {
        if(!groupGameState.containsKey(qun+"猜数字")) return;
        Map state = groupGameState.get(qun+"猜数字");
        int GNumber = (int) state.get("正确数字");
        int guessCount = (int) state.get("次数");
        String starterWxid = (String) state.get("发起者");
        if (!wxid.equals(starterWxid)) {
            String text = "@"+name+" \n" + 
            "当前游戏由@"+getName(starterWxid)+" 发起\n" + 
            "请等待其游玩结束后再开始新游戏";
            sendm(qun,text,0);
            return;
        }
        try {
            int tNumber = Integer.parseInt(content.substring(2));
            if(tNumber == GNumber) {
                写("Groups/"+qun+"/Users", wxid+"_user", "点券", 点券+1000);
                写("Groups/"+qun+"/Users", wxid+"_user", "猜数胜", 猜数胜+1);
                if(体力- 1 < 0) {
                    写("Groups/"+qun+"/Users", wxid+"_user", "体力", 0);
                }else{
                    写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力-1);
                }
                String text = "@"+name+" \n" + 
                "恭喜你猜出正确数字!\n" + 
                "你就是天选之子!\n" + 
                "\n获得\n"+"💴1000\n" + 
                "失去\n"+"⚡1";
                sendm(qun,text,0);
                groupGameState.remove(qun+"猜数字");
                TimerTask timerTask = (TimerTask) state.get("timerTask");
                timerTask.cancel();
                return;
            }else{
                if (guessCount - 1 == 0) {
                    if(体力-1 < 0) {
                        写("Groups/"+qun+"/Users", wxid+"_user", "体力", 0);
                    }else{
                        写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力-1);
                    }
                    写("Groups/"+qun+"/Users", wxid+"_user", "点券", 点券-1000);
                    写("Groups/"+qun+"/Users", wxid+"_user", "猜数败", 猜数败 + 1);
                    String text = "@"+name+" \n" + 
                    "游戏结束，你没有猜对!\n" + 
                    "正确数字: "+GNumber+"\n" + 
                    "\n失去\n💴1000  ⚡1";
                    sendm(qun,text,0);
                    groupGameState.remove(qun+"猜数字");
                    TimerTask timerTask = (TimerTask) state.get("timerTask");
                    timerTask.cancel();
                    return;
                }
                String feedback = getFeedback(tNumber, GNumber);
                String text = "@"+name+" \n" + 
                feedback+"\n" + 
                "剩余次数: "+(guessCount - 1);
                sendm(qun,text,0);
                state.put("次数", guessCount-1);
            }
        } catch (Exception e) {
            String text = "@"+name+" \n" + 
            "你的输入有误";
            sendm(qun,text,0);
        }
    }
    if(content.startsWith("猜歌")) {
        if(!groupGameState.containsKey(qun+"猜歌名")) return;
        Map state = groupGameState.get(qun+"猜歌名");
        String 正确名 = (String) state.get("正确名");
        正确名 = 正确名.trim();
        正确名 = 正确名.replace(" ", "");
        String starterWxid = (String) state.get("发起者");
        if(!wxid.equals(starterWxid)) {
            String text = "@"+name+" \n" + 
            "当前游戏由@"+getName(starterWxid)+" 发起\n" + 
            "请等待其游玩结束后再开始新游戏";
            sendm(qun,text,0);
            return;
        }
        try {
            String guess = content.substring(2);
            guess = guess.trim();
            guess = guess.replace(" ", "");
            guess = guess.replace("（", "(");
            guess = guess.replace("）", ")");
            if (正确名.equals(guess)) {
                String text = "@"+name+" \n" + 
                "恭喜你猜出正确歌名《"+正确名+"》!\n" + 
                "\n获得\n"+"💴1000\n" + 
                "失去\n"+"⚡1";
                sendm(qun,text,0);
                if(体力 - 1 < 0) {
                    写("Groups/"+qun+"/Users", wxid+"_user", "体力", 0);
                }else{
                    写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力 - 1);
                }
                写("Groups/"+qun+"/Users", wxid+"_user", "点券", 点券 + 1000);
                写("Groups/"+qun+"/Users", wxid+"_user", "猜歌胜", 猜歌胜 + 1);
                groupGameState.remove(qun+"猜歌名");
                TimerTask timerTask = (TimerTask) state.get("timerTask");
                timerTask.cancel();
            }else{
                String text = "@"+name+" \n" + 
                "猜错了，再想想";
                sendm(qun,text,0);
            }
        } catch (Exception e) {
            String text = "@"+name+" \n" + 
            "你的输入有误";
            sendm(qun,text,0);
        }
    }
    if(content.startsWith("#参加游戏")) {
        joinGame(qun, wxid);
    } else if (content.startsWith("下棋 ")) {
        makePlayerMove(qun, wxid, content.substring(3));
    }
    if(content.startsWith("我接")) {
        if(体力 >= 1)
        {
            if (!gameStarted) {
                sendm(qun, "@"+name+"\n当前游戏尚未开始，请等待游戏开始后再进行接龙",0);
                return;
            }
            String Mycy = content.substring(2);
            String currentCy = groupCy.get(qun);
            String result = sendGet("https://xiaoapi.cn/API/cyjl.php?id=" + qun + "&msg=我接" + Mycy);
            if (result.contains("接龙成功")) {
                // 取消之前的计时器
                Timer timer = timers.get(qun);
                if (timer != null) {
                    timer.cancel();
                }
                写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力 - 1);
                // 重置计时器
                timer = new Timer();
                timers.put(qun, timer);
                timer.schedule(new TimerTask() {
                    //@Override
                    public void run() {
                    groupCy.remove(qun);
                    startTime.remove(qun);
                    sendm(qun, "游戏超时，接龙失败。发送“开始成语接龙”重新开始游戏。");
                    }
                }, TimeUnit.SECONDS.toMillis(80));
            }
            if (result.contains("抱歉，本妞略胜一筹，我赢了哦！")) {
            Timer timer = timers.get(qun);
            timer.cancel();
            groupCy.remove(qun);
            startTime.remove(qun);
            timers.remove(qun);
            写("Groups/"+qun+"/Users", wxid+"_user", "接龙胜", 接龙胜 + 1);
            写("Groups/"+qun+"/Users", wxid+"_user", "点券", 点券 - 2000);
            写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力 - 1);
            }
            if (result.contains("难倒我了，好吧，你赢了！")) {
            Timer timer = timers.get(qun);
            timer.cancel();
            groupCy.remove(qun);
            startTime.remove(qun);
            timers.remove(qun);
            写("Groups/"+qun+"/Users", wxid+"_user", "接龙胜", 接龙胜 + 1);
            写("Groups/"+qun+"/Users", wxid+"_user", "点券", 点券 + 2000);
            写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力 - 1);
            }
            sendm(qun, result.replace("难倒我了，好吧，你赢了！","@"+name+"\n难倒我了，好吧，你赢了！\n\n获得\n💴2000\n失去\n⚡1").replace("抱歉，本妞略胜一筹，我赢了哦！","@"+name+"\n抱歉，本妞略胜一筹，我赢了哦！\n\n失去\n💴2000  ⚡1"),0);
        }else{
            sendm(qun, "@"+name+"\n体力不足1⚡");
            return;
        }
    }
}
private String getFeedback(int tNumber, int GNumber) {
    if (tNumber - GNumber > 50) {
        return "你输入的数字太大了";
    } else if (tNumber - GNumber > 20) {
        return "你输入的数字大了";
    } else if (tNumber - GNumber > 5) {
        return "你输入的数字稍大";
    } else if (tNumber - GNumber > 0) {
        return "很接近了,再小一些就好了";
    } else if (tNumber - GNumber < -50) {
        return "你输入的数字太小了";
    } else if (tNumber - GNumber < -20) {
        return "你输入的数字小了";
    } else if (tNumber - GNumber < -5) {
        return "你输入的数字稍小了";
    } else if (tNumber - GNumber < 0) {
        return "很接近了,再大一些就好了";
    } else {
        return "";
    }
}