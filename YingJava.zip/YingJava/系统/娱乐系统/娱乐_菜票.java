public void 娱乐系统_菜票(Object data) {
    String content = data.content;
    String qun = data.talker; 
    String wxid = data.sendTalker;
	String name = getName(wxid);
    int 点券 = 读整("Groups/"+qun+"/Users", wxid + "_user", "点券");
    int lt0 = (int) (Math.random() * 90) + 10;
    int lt1 = (int) (Math.random() * 90) + 10;
    int lt2 = (int) (Math.random() * 90) + 10;
    int lt3 = (int) (Math.random() * 90) + 10;
    int lt4 = (int) (Math.random() * 90) + 10;
    int lt5 = (int) (Math.random() * 90) + 10;
    int lt6 = (int) (Math.random() * 90) + 10;
    int lt7 = (int) (Math.random() * 90) + 10;
    int lt8 = (int) (Math.random() * 90) + 10;
    int lt9 = (int) (Math.random() * 90) + 10;
    int lt10 = (int) (Math.random() * 90) + 10;
    int lt11 = (int) (Math.random() * 90) + 10;
    int lt12 = (int) (Math.random() * 90) + 10;
    int lt13 = (int) (Math.random() * 90) + 10;
    int lt14 = (int) (Math.random() * 90) + 10;
    int lt15 = (int) (Math.random() * 90) + 10;
    int lt16 = (int) (Math.random() * 90) + 10;
    int lt17 = (int) (Math.random() * 90) + 10;
    int lt18 = (int) (Math.random() * 90) + 10;
    int lt19 = (int) (Math.random() * 90) + 10;
    int lt20 = (int) (Math.random() * 90) + 10;
    if(content.equals("买菜票")) {
        if(点券<20) {
            sendm(qun,"@"+name+"\n你的点券不足20",0);
            return;
        }
        int dq = (int) (Math.random() * 1600) + 500;
        String menu = "中奖号：" + lt0 +
        "\n◈" + " | " + lt1 + " | " + lt2 + " | " + lt3 + " | " + lt4 + " | " + lt5 +
        "\n◈" + " | " + lt6 + " | " + lt7 + " | " + lt8 + " | " + lt9 + " | " + lt10 +
        "\n◈" + " | " + lt11 + " | " + lt12 + " | " + lt13 + " | " + lt14 + " | " + lt15 +
        "\n◈" + " | " + lt16 + " | " + lt17 + " | " + lt18 + " | " + lt19 + " | " + lt20;
        if(lt0 == lt1 || lt0 == lt2 || lt0 == lt3 || lt0 == lt4 || lt0 == lt5 || lt0 == lt6 || lt0 == lt7 || lt0 == lt8 || lt0 == lt9 || lt0 == lt10 || lt0 == lt11 || lt0 == lt12 || lt0 == lt13 || lt0 == lt14 || lt0 == lt15 || lt0 == lt16 || lt0 == lt17 || lt0 == lt18 || lt0 == lt19 || lt0 == lt20) {
            String 中奖 = "赌go，你中了";
            String text = "@" + name + "\n" + menu + "\n中奖结果：" +中奖+"\n\n获得\n"+dq+"💴\n失去\n20💴\n\nPS:该功能为[九寒包]制作，仅供娱乐";
            写("Groups/"+qun+"/Users",  wxid+"_user", "点券",点券 + dq - 20);
            sendm(qun,text,0);
        }else{
            String 中奖 = "赌go，你没中，亏了";
            String text = "@" + name + "\n" + menu + "\n中奖结果：" +中奖+"\n\n失去\n20💴\n\nPS:该功能为[九寒包]制作，仅供娱乐";
            写("Groups/"+qun+"/Users",  wxid+"_user", "点券",点券 - 20);
            sendm(qun,text,0);
        }
    }
}