public void 娱乐系统(Object data) {
    String content = data.content;
    String qun = data.talker;
    String wxid=data.sendTalker;
    String name= getName(wxid);
    娱乐系统_排行榜(data);
    娱乐系统_抽卡池(data);
    娱乐系统_菜票(data);
    娱乐系统_游戏(data);
    娱乐系统_礼包(data);
    娱乐系统_签到(data);
    娱乐系统_个人信息(data);
    娱乐系统_银行系统(data);
    娱乐系统_打劫系统(data);
    娱乐系统_婚姻系统(data);
    娱乐系统_奴隶系统(data);
    娱乐系统_商城系统(data);
    if(content.equals("娱乐系统")) {
        String text = "[e]排行榜[e]\n" + 
        "◈游戏──\n" + 
        "[e]猜谜语[e2]猜数字[e]\n" + 
        "[e]猜歌名[e2]井字棋[e]\n" + 
        "[e]成语接龙[e2]翻塔罗牌[e]\n" + 
        "◈娱乐──\n" + 
        "[e]礼包[e2]签到[e]\n" + 
        "[e]抽卡池[e2]买菜票[e]\n" + 
        "[e]个人信息[e2]银行系统[e]\n" + 
        "[e]打劫系统[e2]奴隶系统[e]\n" + 
        "[e]婚姻系统[e2]商城系统[e]";
        sendm(qun,text,0);
    }
    if(content.equals("排行榜")) {
        String text = "[e]点券排行榜\n" + 
        "[e]签到排行榜\n" + 
        "[e]打劫排行榜\n" + 
        "PS:仅显示前十名";
        sendm(qun,text,0);
    }
    if(content.equals("抽卡池")) {
        String text = "[e]抽普通池\n" + 
        "[e]抽高级池\n" + 
        "[e]抽传奇池";
        sendm(qun,text,0);
    }
    if(content.equals("猜谜语")) {
        String text = "发送\"开始猜谜语\"开始游戏\n" + 
        "发送\"猜谜+内容\"进行游戏";
        sendm(qun,text,0);
    }
    if(content.equals("猜数字")) {
        String text = "发送\"开始猜数字\"开始游戏\n" + 
        "发送\"猜数+数字\"进行游戏";
        sendm(qun,text,0);
    }
    if(content.equals("猜歌名")) {
        String text = "发送\"开始猜歌名\"开始游戏\n" + 
        "发送\"猜歌+内容\"进行游戏";
        sendm(qun,text,0);
    }
    if(content.equals("井字棋")) {
        String text = "发送\"开始井字棋\"开始游戏\n" + 
        "发送\"#参加游戏\"加入游戏\n" + 
        "发送\"下棋 行,列\"进行游戏";
        sendm(qun,text,0);
    }
    if(content.equals("成语接龙")) {
        String text = "发送\"开始成语接龙\"开始游戏\n" + 
        "发送\"我接+成语\"进行游戏";
        sendm(qun,text,0);
    }
    if(content.equals("翻塔罗牌")) {
        if(网站状态.Get("https://api.tangdouz.com/tarot.php?return=json")) {
            String tlp = sendGet("https://api.tangdouz.com/tarot.php?return=json");
            String fw = 数据处理.JSON(tlp,"position");
            String tlpname = 数据处理.JSON(tlp,"name");
            String tlpnamen = 数据处理.JSON(tlp,"namen");
            String tlpnr = 数据处理.JSON(tlp,"content");
            String img = 数据处理.JSON(tlp,"img");
            if(fw==null||tlpname==null||tlpnamen==null||tlpnr==null) {
                snedm(qun,"@"+name+"\n塔罗牌获取异常",0);
            }else{
                sendPic(qun,img);
                sendm(qun,"@"+name+"\n你翻开了["+fw+"]的"+tlpname+"("+tlpnamen+")\n其释义为:\n\""+tlpnr+"\"",0);
            }
        }else{
            sendm(qun,"@"+name+"\n塔罗牌接口失效",0);
        }
    }
    if(content.equals("银行系统")) {
        String text = "[e]存款+数量\n" + 
        "[e]取款+数量\n" + 
        "[e]转账+数量\n" + 
        "PS:银行获利率 2%/月";
        sendm(qun,text,0);
    }
    if(content.equals("打劫系统")) {
        String text = "[e]打劫*\n" + 
        "[e]打劫群主\n" + 
        "[e]打劫银行\n" + 
        "PS:带\"*\"标识需引用消息发送";
        sendm(qun,text,0);
    }
    if(content.equals("奴隶系统")) {
        String text = "[e]买下[买奴隶]*\n" + 
        "[e]放走[放奴隶]*\n" + 
        "[e]卖奴隶+金额*\n" + 
        "[e]奴隶打工\n" + 
        "[e]我要赎身\n" + 
        "PS:带\"*\"标识需引用消息发送\n" + 
        "带\"[]\"标识为其他触发词";
        sendm(qun,text,0);
    }
    if(content.equals("婚姻系统")) {
        String text = "[e]表白+内容\n" + 
        "[e]结婚\n" + 
        "PS:需引用消息发送";
        sendm(qun,text,0);
    }
    if(content.equals("商城系统")) {
        String text = "[e]装备商城\n" + 
        "[e]体力商城";
        sendm(qun,text,0);
    }
}