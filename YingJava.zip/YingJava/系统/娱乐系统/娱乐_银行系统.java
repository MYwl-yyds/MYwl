public void 娱乐系统_银行系统(Object data) {
    String content = data.content;
    String qun = data.talker; 
    String wxid = data.sendTalker;
    String name = getName(wxid);
    int 点券 = 读整("Groups/"+qun+"/Users",wxid+"_user","点券");
    int 存款 = 读整("全局/银行系统",wxid,"存款");
    String 存款时间 = 读("全局/银行系统",wxid,"存款时间","无");
    if(data.isReply()) {
        String wxid2 = getElementContent(data.content, "chatusr");
        String content2 = getElementContent(data.content, "title");
        String name2 = getName(wxid2);
        int 点券2 = 读整("Groups/"+qun+"/Users",wxid+"_user","点券");
        int 存款2 = 读整("全局/银行系统",wxid2+"_user","存款");
        if(content2.startsWith("转账")) {
            if(wxid.equals(wxid2)){
                sendm(qun, "@"+name+"\n不能给自己转账",0);
                return;
            }
            String amountStr = content2.substring(2);
            try {
                int amount = Integer.parseInt(amountStr);
			    if(amount < 0) {
				    sendm(qun, "@" + name + " \n不能为负数",0);
				    return;
			    }
			    if(amount == 0) {
				    sendm(qun, "@" + name + " \n你转了个寂寞",0);
				    return;
			    }
                if(存款 >= amount) {
                    写("全局/银行系统", wxid2, "存款", 存款2 + amount);
                    写("全局/银行系统", wxid, "存款", 存款 - amount);
                    String text = "@"+name + 
                    "\n转账成功！\n已将点券" + amount + "💴转给" + name2 + 
                    "\n\n失去\n"+"💴"+amount;
                    sendm(qun, text,0);
                    return;
                } else {
                    sendm(qun, "@"+name+"\n存款不足" + amount + "💴",0);
                    return;
                }
            } catch (NumberFormatException e) {
                sendm(qun, "@"+name+"\n输入有误",0);
                return;
            }
        }
    }
    if(content.startsWith("存款")) {
        String ckStr = content.substring(2);
        try {
            int ck = Integer.parseInt(ckStr);
			if(ck < 0) {
				sendm(qun, "@" + name + " \n不能存负数",0);
				return;
			}
			if(ck == 0||ck == 100) {
				sendm(qun, "@" + name + " \n你存了个寂寞",0);
				return;
			}
			if(ck < 100) {
				sendm(qun, "@" + name + " \n要存100以上的点券",0);
				return;
			}
            if (点券 >= ck) {
                写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券 - ck);
                ck -= 100;
                写("全局/银行系统", wxid, "存款", 存款 + ck);
                写("全局/银行系统", wxid, "存款时间", GetTime(4));
                String text = "@" + name + " \n存款成功！\n扣除100点券服务费\n实存点券" + ck + "💴\n\n失去\n💴"+(ck+100);
                sendm(qun, text,0);
                return;
            } else {
                sendm(qun, "@"+name+"\n点券不足" + ck + "💴",0);
                return;
            }
        } catch (NumberFormatException e) {
            sendm(qun, "@"+name+"\n输入有误",0);
            return;
        }
    }
    if (content.startsWith("取款")) {
		String amountStr = content.substring(2);
        try {
            int qk = Integer.parseInt(amountStr);
			if(qk < 0) {
				sendm(qun, "@" + name + " \n不能去负数",0);
				return;
			}
			if(qk == 0) {
				sendm(qun, "@" + name + " \n你取了个寂寞",0);
				return;
			}
            if (存款 >= qk) {
                写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券 + qk);
                String text = "@" + name + " \n取款成功！\n已成功取出点券" + qk + "💴";
			    if(时间间隔.月数(存款时间)>=1) {
			        int yue = 时间间隔.月数(存款时间);
				    double lx1 = yue * 读整("全局/银行系统", wxid, "存款");
				    int lx = (int) (lx1 * 0.002);
				    写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券 + lx);
				    text = text + "\n获取利息" + lx + "点券💴";
				    text = text + "\n\n获得\n"+"💴"+(qk+lx);
				    if(存款==0) {
				        删("全局/银行系统", wxid, "存款时间");
				    }
			    }
			    写("全局/银行系统", wxid, "存款", 存款 - qk);
                sendm(qun, text,0);
                return;
            } else {
                sendm(qun, "@"+name+"\n存款不足" + qk + "💴",0);
                return;
            }
        } catch (NumberFormatException e) { 
            sendm(qun, "@"+name+"\n输入有误",0);
            return;
        }
	}
}
