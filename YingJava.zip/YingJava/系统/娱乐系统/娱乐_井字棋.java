private Map groupGameState = new HashMap();
private void startNewGame(String qun, String wxid) {
    String name = getName(wxid);
    int 点券 = 读整("Groups/"+qun+"/Users",wxid+"_user","点券");
    int 体力 = 读整("Groups/"+qun+"/Users",wxid+"_user","体力");
    if(体力 >= 1) {
        if(groupGameState.containsKey(qun)) {
            String text = "@"+name+" \n" + 
            "当前群聊有人正在游玩中，请等待其游玩结束后开始";
            sendm(qun,text,0);
	        return;
        }
        Map state = new HashMap();
        state.put("board", initBoard());
        state.put("currentPlayerWxid", wxid);
        state.put("winner", null);
        List players = new ArrayList();
        players.add(wxid);
        state.put("players", players);
        groupGameState.put(qun, state);
        String text = "@"+name+" \n" + 
        "井字棋已开始，等待其他玩家加入...\n" + 
        "发送\"#参加游戏\"可加入游戏";
        sendm(qun,text,0);
    }else{
        sendm(qun, "@"+name+" \n体力不足1⚡",0);
        return;
    }
}
private void joinGame(String qun, String wxid) {
    String name = getName(wxid);
    int 点券 = 读整("Groups/"+qun+"/Users",wxid+"_user","点券");
    int 体力 = 读整("Groups/"+qun+"/Users",wxid+"_user","体力");
    if(体力 >= 1)
    {
        Map state = groupGameState.get(qun);
        if(state == null) {
            String text = "@"+name+" \n" + 
            "当前群聊没有进行井字棋游戏";
            sendm(qun,text,0);
	        return;
        }
        List players = (List) state.get("players");
        if (players == null || players.size() >= 2) {
            String text = "@"+name+" \n" + 
            "游戏已满人，无法加入";
            sendm(qun,text,0);
            return;
        }
        if(!players.contains(wxid)) {
            players.add(wxid);
            state.put("players", players);
            //sendm(qun, "新玩家 " + wxid + " 已加入游戏。");
            if (players.size() == 2) {
                startGame(qun, state);
            }
        }else{
            sendm(qun, "@"+name+"\n你已在游戏中",0);
        }
    }else{
        sendm(qun, "@"+name+"体力不足1⚡",0);
        return;
    }
}
private void startGame(String qun, Map state) {
    int 点券 = 读整("Groups/"+qun+"/Users",wxid+"_user","点券");
    int 体力 = 读整("Groups/"+qun+"/Users",wxid+"_user","体力");
    sendm(qun, "游戏开始！\n玩家 " + getName(state.get("currentPlayerWxid")) + " 先走",0);
    displayBoard(qun, state);
}
private void displayBoard(String qun, Map state) {
    char[][] board = (char[][]) state.get("board");
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (board[i][j] == '□') {
                sb.append("□   ");
            } else if (board[i][j] == '▲') {
                sb.append("▲   ");
            } else if (board[i][j] == '●') {
                sb.append("●   ");
            }
        }
        sb.append("\n");
    }
    sb.append("---------\n");
    sendm(qun, sb.toString(),0);
}
private char[][] initBoard() {
    return new char[][] {
        {'□', '□', '□'},
        {'□', '□', '□'},
        {'□', '□', '□'}
    };
}
private void makePlayerMove(String qun, String wxid, String moveStr) {
    String name = getName(wxid);
    int 点券 = 读整("Groups/"+qun+"/Users",wxid+"_user","点券");
    int 体力 = 读整("Groups/"+qun+"/Users",wxid+"_user","体力");
    Map state = groupGameState.get(qun);
    if (state == null) {
        String text = "@"+name+" \n" + 
        "当前群聊没有进行井字棋游戏";
        sendm(qun,text,0);
        return;
    }
    List players = (List) state.get("players");
    if (players == null || !players.contains(wxid)) {
        sendm(qun, "@"+name+"\n你不在游戏中",0);
        return;
    }
    String currentPlayerWxid = (String) state.get("currentPlayerWxid");
    if (!wxid.equals(currentPlayerWxid)) {
        sendm(qun, "@"+name+"\n当前不是你的回合",0);
        return;
    }
    String[] parts = moveStr.split(",");
    if (parts.length != 2) {
        sendm(qun, "@"+name+"\n无效的移动格式，请使用 #下棋 行,列",0);
        return;
    }
    int row, col;
    try {
        row = Integer.parseInt(parts[0]);
        col = Integer.parseInt(parts[1]);
    } catch (NumberFormatException e) {
        sendm(qun, "@"+name+"\n无效的移动坐标，请输入有效的整数行和列",0);
        return;
    }
    if (row < 0 || row >= 3 || col < 0 || col >= 3) {
        sendm(qun, "@"+name+"\n无效的移动坐标，请输入0到2之间的整数",0);
        return;
    }
    char[][] board = (char[][]) state.get("board");
    if (board[row][col] != '□') {
        sendm(qun, "@"+name+"该位置已被占用，请选择其他位置",0);
        return;
    }
    // 使用玩家的微信ID代替 "X" 和 "O"
    board[row][col] = wxid.equals(players.get(0)) ? '▲' : '●';
    displayBoard(qun, state);
    checkWinner(qun,state); // 检查是否有胜者
    changePlayer(state); // 切换玩家
}
private void changePlayer(Map state) {
        List players = (List) state.get("players");
        state.put("currentPlayerWxid", state.get("currentPlayerWxid").equals(players.get(0)) ? players.get(1) : players.get(0));
}
private void checkWinner(String qun,Map state) {
    char[][] board = (char[][]) state.get("board");
    List players = (List) state.get("players");
    String[] lines = {
        "" + board[0][0] + board[0][1] + board[0][2],
        "" + board[1][0] + board[1][1] + board[1][2],
        "" + board[2][0] + board[2][1] + board[2][2],
        "" + board[0][0] + board[1][0] + board[2][0],
        "" + board[0][1] + board[1][1] + board[2][1],
        "" + board[0][2] + board[1][2] + board[2][2],
        "" + board[0][0] + board[1][1] + board[2][2],
        "" + board[2][0] + board[1][1] + board[0][2]
    };
    for (String line : lines) {
        if ("▲▲▲".equals(line)) {
            state.put("winner", players.get(0));
            String text = "@"+getName(players.get(0))+" \n" + 
            "恭喜你获胜!\n" + 
            "\n获得\n"+"💴1500\n" + 
            "失去\n"+"⚡1";
            sendm(qun,text,0);
            写("Groups/"+qun+"/Users", players.get(0) + "_user", "点券", 读整("Groups/"+qun+"/Users", players.get(0) + "_user", "点券") + 1500);
            写("Groups/"+qun+"/Users", players.get(0) + "_user", "体力", 读整("Groups/"+qun+"/Users", players.get(0) + "_user", "体力") - 1);
            sendm(qun, "@" + getName(players.get(1)) + " \n很遗憾你输了！\n\n失去\n💴1500  ⚡1",0);
            写("Groups/"+qun+"/Users", players.get(0) + "_user", "点券", 读整("Groups/"+qun+"/Users", players.get(0) + "_user", "点券") - 1500);
            写("Groups/"+qun+"/Users", players.get(0) + "_user", "体力", 读整("Groups/"+qun+"/Users", players.get(0) + "_user", "体力") - 1);
            resetGame(qun);
            return;
        }
        if ("●●●".equals(line)) {
            state.put("winner", players.get(1));
            String text = "@"+getName(players.get(0))+" \n" + 
            "很遗憾你输了!\n" + 
            "\n失去\n"+"💴1500 ⚡1";
            sendm(qun,text,0);
            写("Groups/"+qun+"/Users", players.get(0) + "_user", "点券", 读整("Groups/"+qun+"/Users", players.get(0) + "_user", "点券") - 1500);
            写("Groups/"+qun+"/Users", players.get(0) + "_user", "体力", 读整("Groups/"+qun+"/Users", players.get(0) + "_user", "体力") - 1);
            sendm(qun, "@" + getName(players.get(1)) + " \n恭喜你获胜！\n\n获得\n💴1500\n失去\n⚡1",0);
            写("Groups/"+qun+"/Users", players.get(0) + "_user", "点券", 读整("Groups/"+qun+"/Users", players.get(0) + "_user", "点券") + 1500);
            写("Groups/"+qun+"/Users", players.get(0) + "_user", "体力", 读整("Groups/"+qun+"/Users", players.get(0) + "_user", "体力") - 1);
            resetGame(qun);
            return;
        }
    }
    if (isBoardFull(board)) {
        state.put("winner", "平局");
        sendm(qun, "游戏平局！",0);
        resetGame(qun);
    }
}
private boolean isBoardFull(char[][] board) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j] == '□') {
                    return false; // 如果找到空格，则棋盘未满
                }
            }
        }
        return true; // 如果没有找到空格，则棋盘已满
}
private void resetGame(String qun) {
        groupGameState.remove(qun);
        //sendm(qun, "游戏已结束，可以开始新的游戏。");
}
