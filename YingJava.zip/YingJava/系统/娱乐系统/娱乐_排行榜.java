public class Mylist {
	String Uin;
	long cMark;
	long a1;
	long a2;
}
public void 娱乐系统_排行榜(Object data) {
    String content = data.content;
    String qun = data.talker;
    String wxid = data.sendTalker;
    if(content.equals("点券排行榜")) {
        ArrayList MMList = new ArrayList();
		List fs = Arrays.asList(new File(JavaPath+"/data/Groups/"+qun+"/Users").listFiles());
		for(File ff: fs) {
			if(!ff.isFile()) continue;
			String UinN = ff.getName();
			String MUin = UinN.split("_user.")[0];
			long Mark = 读整("Groups/"+qun+"/Users", MUin+"_user", "点券");
			if(Mark == 0) continue;
			Mylist MCodeList = new Mylist();
			MCodeList.Uin = MUin;
			MCodeList.cMark = Mark;
			MMList.add(MCodeList);
		}
		MMList = MySort(MMList);
		String text = "─点券排行榜─";
		if(MMList.size() < 10) {
			for(int i = 0; i < MMList.size(); i++) {
				Mylist MCodeList = MMList.get(i);
				text = text + "\nTOP"+(i+1);
				text = text + "\n[昵称]" +getName(MCodeList.Uin);
				text = text + "\n[点券]" + MCodeList.cMark + "💴\n";
			}
		}
		else
		{
			for(int i = 0; i < 10; i++)
			{
				Mylist MCodeList = MMList.get(i);
				text = text + "\nTOP"+(i+1);
				text = text + "\n[昵称]" + getName(MCodeList.Uin);
				text = text + "\n[点券]" + MCodeList.cMark + "💴\n";
			}
		}
		if(text.equals("─点券排行榜─")) {
		    text = "─点券排行榜─\n\n暂无排行\n";
		}
		sendm(qun,text,1);
    }
    if(content.equals("签到排行榜")) {
        ArrayList MMList = new ArrayList();
	    List fs = Arrays.asList(new File(JavaPath+"/data/Groups/"+qun+"/Users").listFiles());
		for(File ff: fs) {
			if(!ff.isFile()) continue;
			String UinN = ff.getName();
			String MUin = UinN.split("\\_user.")[0];
			long Mark = 读整("Groups/"+qun+"/Users", MUin+"_user", "累签");
			if(Mark == 0) continue;
			Mylist MCodeList = new Mylist();
			MCodeList.Uin = MUin;
			MCodeList.cMark = Mark;
			MMList.add(MCodeList);
		}
		MMList = MySort(MMList);
		String text = "─签到排行榜─";
		if(MMList.size() < 10) {
			for(int i = 0; i < MMList.size(); i++) {
				Mylist MCodeList = MMList.get(i);
				text = text + "\nTOP"+(i+1);
				text = text + "\n[昵称]" +getName(MCodeList.Uin);
				text = text + "\n[累签]" + MCodeList.cMark + "天\n";
			}
		}
		else
		{
			for(int i = 0; i < 10; i++)
			{
				Mylist MCodeList = MMList.get(i);
				text = text + "\nTOP"+(i+1);
				text = text + "\n[昵称]" + getName(MCodeList.Uin);
				text = text + "\n[累签]" + MCodeList.cMark + "天\n";
			}
		}
		if(text.equals("─签到排行榜─")) {
		    text = "─签到排行榜─\n\n暂无排行\n";
		}
		sendm(qun,text,1);
    }
    if(content.equals("打劫排行榜")) {
        ArrayList MMList = new ArrayList();
	    List fs = Arrays.asList(new File(JavaPath+"/data/Groups/"+qun+"/Users").listFiles());
		for(File ff: fs) {
			if(!ff.isFile()) continue;
			String UinN = ff.getName();
			String MUin = UinN.split("\\_user.")[0];
			long a1 = 读整("Groups/"+qun+"/Users", MUin+"_user", "打劫成功");
			long a2 = 读整("Groups/"+qun+"/Users", MUin+"_user", "打劫失败");
			long Mark = a1+a2;
			if(Mark == 0) continue;
			Mylist MCodeList = new Mylist();
			MCodeList.Uin = MUin;
			MCodeList.cMark = Mark;
			MMList.add(MCodeList);
		}
		MMList = MySort(MMList);
		String text = "─打劫排行榜─";
		if(MMList.size() < 10) {
			for(int i = 0; i < MMList.size(); i++) {
				Mylist MCodeList = MMList.get(i);
				text = text + "\nTOP" + (i+1);
				text = text + "\n[昵称]" + getName(MCodeList.Uin);
				text = text + "\n[打劫次数]" + MCodeList.cMark +"次\n(成功:"+MCodeList.a1+"次,失败:"+MCodeList.a2+ "次)\n";
			}
		}
		else
		{
			for(int i = 0; i < 10; i++)
			{
				Mylist MCodeList = MMList.get(i);
				text = text + "\nTOP" +(i+1);
				text = text + "\n[昵称]" + getName(MCodeList.Uin);
				text = text + "\n[打劫次数]" + MCodeList.cMark +"次\n(成功:"+MCodeList.a1+"次,失败:"+MCodeList.a2+ "次)\n";
			}
		}
		if(text.equals("─打劫排行榜─")) {
		    text = "─打劫排行榜─\n\n暂无排行\n";
		}
		sendm(qun,text,1);
    }
}
public ArrayList MySort(ArrayList obj) {
	for(int i = 0; i < obj.size(); i++) {
		for(int i2 = 0; i2 < obj.size() - 1; i2++) {
			Mylist MCodeList = null;
			if(obj.get(i2).cMark < obj.get(i2 + 1).cMark) {
				MCodeList = obj.get(i2);
				obj.set(i2, obj.get(i2 + 1));
				obj.set(i2 + 1, MCodeList);
			}
		}
	}
	return obj;
}