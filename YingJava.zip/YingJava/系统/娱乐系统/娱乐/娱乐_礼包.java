public void 娱乐系统_礼包(Object data) {
	String content = data.content;
	String qun = data.talker;
	String wxid=data.sendTalker;
	String name = getName(wxid);
	int 点券 = 读整("Groups/"+qun+"/Users",wxid+"_user","点券");
	int 体力 = 读整("Groups/"+qun+"/Users",wxid+"_user","体力");
	String 每日礼包 = 读("Groups/"+qun+"/Users",wxid+"_user","每日礼包","无");
	String 每月礼包 = 读("Groups/"+qun+"/Users",wxid+"_user","每月礼包","无");
	String 每年礼包 = 读("Groups/"+qun+"/Users",wxid+"_user","每年礼包","无");
	int 新人礼包 = 读整("Groups/"+qun+"/Users",wxid+"_user","新人礼包");
    if(content.equals("礼包")) {
        String text = "[e]领取新人礼包\n" +
        "[e]领取每日礼包\n" +
        "[e]领取每月礼包\n" +
        "[e]领取每年礼包";
        sendm(qun,text,0);
    }
	if(content.equals("领取每日礼包")) {
	    if(每日礼包.equals("无")) {
	        写("Groups/"+qun+"/Users",wxid+"_user","每日礼包",GetTime(4));
	        写("Groups/"+qun+"/Users",wxid+"_user","点券",点券+500);
	        if(体力+20>=100) {
	            写("Groups/"+qun+"/Users",wxid+"_user","体力",100);
	        }else{
	            写("Groups/"+qun+"/Users",wxid+"_user","体力",体力+20);
	        }
	        String text = "@"+name+" \n" + 
	        "领取成功!\n" + 
	        "获得\n💴500  ⚡20";
	        sendm(qun,text,0);
	    }else{
	        int day = 时间间隔.天数(每日礼包);
	        if(day>=1) {
	            写("Groups/"+qun+"/Users",wxid+"_user","每日礼包",GetTime(4));
	            写("Groups/"+qun+"/Users",wxid+"_user","点券",点券+500);
	            if(体力+20>=100) {
	                写("Groups/"+qun+"/Users",wxid+"_user","体力",100);
	            }else{
	                写("Groups/"+qun+"/Users",wxid+"_user","体力",体力+20);
	            }
	            String text = "@"+name+" \n" + 
	            "领取成功!\n" + 
	            "获得\n💴500  ⚡20";
	            sendm(qun,text,0);
	        }else{
	            String text = "@"+name+" \n" + 
	            "你今日已领取，明日再来";
	            sendm(qun,text,0);
	        }
	    }
	}
	if(content.equals("领取每月礼包")) {
	    if(每月礼包.equals("无")) {
	        写("Groups/"+qun+"/Users",wxid+"_user","每月礼包",GetTime(4));
	        写("Groups/"+qun+"/Users",wxid+"_user","点券",点券+3000);
	        if(体力+50>=100) {
	            写("Groups/"+qun+"/Users",wxid+"_user","体力",100);
	        }else{
	            写("Groups/"+qun+"/Users",wxid+"_user","体力",体力+50);
	        }
	        String text = "@"+name+" \n" + 
	        "领取成功!\n" + 
	        "获得\n💴3000  ⚡50";
	        sendm(qun,text,0);
	    }else{
	        int day = 时间间隔.天数(每日礼包);
	        if(day>=1) {
	            写("Groups/"+qun+"/Users",wxid+"_user","每月礼包",GetTime(4));
	            写("Groups/"+qun+"/Users",wxid+"_user","点券",点券+3000);
	            if(体力+50>=100) {
	                写("Groups/"+qun+"/Users",wxid+"_user","体力",100);
	            }else{
	                写("Groups/"+qun+"/Users",wxid+"_user","体力",体力+50);
	            }
	            String text = "@"+name+" \n" + 
	            "领取成功!\n" + 
	            "获得\n💴3000  ⚡50";
	            sendm(qun,text,0);
	        }else{
	            String text = "@"+name+" \n" + 
	            "你本月已领取，下月再来";
	            sendm(qun,text,0);
	        }
	    }
	}
	if(content.equals("领取每年礼包")) {
	    if(每年礼包.equals("无")) {
	        写("Groups/"+qun+"/Users",wxid+"_user","每年礼包",GetTime(4));
	        写("Groups/"+qun+"/Users",wxid+"_user","点券",点券+40000);
	        if(体力+90>=100) {
	            写("Groups/"+qun+"/Users",wxid+"_user","体力",100);
	        }else{
	            写("Groups/"+qun+"/Users",wxid+"_user","体力",体力+90);
	        }
	        String text = "@"+name+" \n" + 
	        "领取成功!\n" + 
	        "获得\n💴40000  ⚡90";
	        sendm(qun,text,0);
	    }else{
	        int day = 时间间隔.天数(每日礼包);
	        if(day>=1) {
	            写("Groups/"+qun+"/Users",wxid+"_user","每年礼包",GetTime(4));
	            写("Groups/"+qun+"/Users",wxid+"_user","点券",点券+40000);
	            if(体力+90>=100) {
	                写("Groups/"+qun+"/Users",wxid+"_user","体力",100);
	            }else{
	                写("Groups/"+qun+"/Users",wxid+"_user","体力",体力+90);
	            }
	            String text = "@"+name+" \n" + 
	            "领取成功!\n" + 
	            "获得\n💴40000  ⚡90";
	            sendm(qun,text,0);
	        }else{
	            String text = "@"+name+" \n" + 
	            "你今年已领取，明年再来";
	            sendm(qun,text,0);
	        }
	    }
	}
	if(content.equals("领取新人礼包")) {
	    if(新人礼包==0) {
	        写("Groups/"+qun+"/Users",wxid+"_user","新人礼包",1);
	        写("Groups/"+qun+"/Users",wxid+"_user","点券",点券+30000);
            写("Groups/"+qun+"/Users",wxid+"_user","体力",100);
	        String text = "@"+name+" \n" + 
	        "领取成功!\n" + 
	        "获得\n💴30000  ⚡100";
	        sendm(qun,text,0);
	    }else{
            String text = "@"+name+" \n" + 
            "你已领取，不可重复领取";
            sendm(qun,text,0);
	    }
	}
}