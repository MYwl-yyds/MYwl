public void 娱乐系统_个人信息(Object data) {
    String content = data.content;
    String qun = data.talker; 
    String wxid = data.sendTalker;
    String name = getName(wxid);
    int 点券 = 读整("Groups/"+qun+"/Users",wxid+"_user","点券");
    int 签到 = 读整("Groups/"+qun+"/Users",wxid+"_user","累签");
    int 体力 = 读整("Groups/"+qun+"/Users",wxid+"_user","体力");
    int 存款 = 读整("全局/银行系统",wxid,"存款");
    String 婚姻状态 = 读("Groups/"+qun+"/Users",wxid+"_user","婚姻状态","未婚");
    String 关系 = 截取.取中间(婚姻状态,"[","]");
    String 爱人 =  getName(截取.末尾(婚姻状态,"["+关系+"]"));
    String 奴隶主 = getName(读("Groups/"+qun+"/Users",wxid+"_user","奴隶主","无"));
    String 奴隶 = getName(读("Groups/"+qun+"/Users",wxid+"_user","奴隶","无"));
    int 赎身 = 读整("Groups/"+qun+"/Users",wxid+"_user","赎身价格");
    int 猜数胜 = 读整("Groups/"+qun+"/Users",wxid+"_user","猜数胜");
    int 猜数败 = 读整("Groups/"+qun+"/Users",wxid+"_user","猜数败");
    int 猜谜胜 = 读整("Groups/"+qun+"/Users",wxid+"_user","猜谜胜");
    int 猜谜败 = 读整("Groups/"+qun+"/Users",wxid+"_user","猜谜败");
    int 猜歌胜 = 读整("Groups/"+qun+"/Users",wxid+"_user","猜歌胜");
    int 猜歌败 = 读整("Groups/"+qun+"/Users",wxid+"_user","猜歌败");
    int 接龙 = 读整("Groups/"+qun+"/Users",wxid+"_user","接龙胜");
    if(data.isReply()) {
        String wxid2 = getElementContent(data.content,"chatusr");
        String content2 = getElementContent(data.content,"title");
        String name2 = getName(wxid2);
        int 对方点券 = 读整("Groups/"+qun+"/Users",wxid2+"_user","点券");
        int 对方签到 = 读整("Groups/"+qun+"/Users",wxid2+"_user","累签");
        int 对方体力 = 读整("Groups/"+qun+"/Users",wxid2+"_user","体力");
        int 对方存款 = 读整("全局/银行系统",wxid2,"存款");
        String 对方婚姻 = 读("Groups/"+qun+"/Users",wxid2+"_user","婚姻状态","未婚");
        String 对方关系 = 截取.取中间(对方婚姻,"[","]");
        String 对方爱人 =  getName(截取.末尾(对方婚姻,"["+对方关系+"]"));
        String 对方奴隶主 = getName(读("Groups/"+qun+"/Users",wxid2+"_user","奴隶主","无"));
        String 对方奴隶 = getName(读("Groups/"+qun+"/Users",wxid2+"_user","奴隶","无"));
        int 对方赎身 = 读整("Groups/"+qun+"/Users",wxid2+"_user","赎身价格");
        int 对方猜数胜 = 读整("Groups/"+qun+"/Users",wxid2+"_user","猜数胜利");
        int 对方猜数败 = 读整("Groups/"+qun+"/Users",wxid2+"_user","猜数失败");
        int 对方猜谜胜 = 读整("Groups/"+qun+"/Users",wxid2+"_user","猜谜胜利");
        int 对方猜谜败 = 读整("Groups/"+qun+"/Users",wxid2+"_user","猜谜失败");
        int 对方猜歌胜 = 读整("Groups/"+qun+"/Users",wxid2+"_user","猜歌胜利");
        int 对方猜歌败 = 读整("Groups/"+qun+"/Users",wxid2+"_user","猜歌失败");
        int 对方接龙 = 读整("Groups/"+qun+"/Users",wxid2+"_user","接龙胜利");
        if(content2.equals("信息")) {
            if(wxid.equals(wxid2)) {
                String text = "@"+name+" \n" + 
                "你的基本信息\n" + 
                "[累签] "+签到+" 天\n" + 
                "[体力] "+体力+"/100⚡\n" + 
                "◈财富──\n" + 
                "[点券] "+点券+" 💴\n" + 
                "[存款] "+存款+" 💴\n" + 
                "◈婚姻──\n";
                if(婚姻状态.equals("未婚")) {
                    text += "[状态]"+婚姻状态+"\n";
                }else{
                    text += "[关系]"+关系+"\n" + 
                    "[爱人]"+爱人+"\n";
                }
                text += "◈奴隶──\n" + 
                "[奴隶主]"+奴隶主+"\n" + 
                "[奴隶]"+奴隶+"\n" + 
                "[赎身价格] "+赎身+" 💴\n" + 
                "◈游戏──\n" + 
                "[猜数胜] "+猜数胜+" 次\n" + 
                "[猜数败] "+猜数败+" 次\n" + 
                "[猜谜胜] "+猜谜胜+" 次\n" + 
                "[猜谜败] "+猜谜败+" 次\n" + 
                "[猜歌胜] "+猜歌胜+" 次\n" + 
                "[猜歌败] "+猜歌败+" 次\n" + 
                "[接龙胜] "+接龙+" 次";
                text = text.replace("-", "欠");
                text = text.replace("null", "无");
                text = text.replace("void", "获取异常");
                sendm(qun,text,0);
                return;
            }
            if(wxid.equals(Mwxid)) {
                String text = "@"+name+" \n" + 
                name2+" 的信息\n" + 
                "[对方累签] "+对方签到+" 天\n" + 
                "[对方体力] "+对方体力+"/100⚡\n" + 
                "◈财富──\n" + 
                "[对方点券] "+对方点券+" 💴\n" + 
                "[对方存款] "+对方存款+" 💴\n" + 
                "◈婚姻──\n";
                if(婚姻状态.equals("未婚")) {
                    text += "[对方状态]"+对方婚姻+"\n";
                }else{
                    text += "[对方关系]"+对方关系+"\n" + 
                    "[对方爱人]"+对方爱人+"\n";
                }
                text += "◈奴隶──\n" + 
                "[对方奴隶主]\n"+对方奴隶主+"\n" + 
                "[对方奴隶]"+对方奴隶+"\n" + 
                "[对方赎身价格]\n"+对方赎身+" 💴\n" + 
                "◈游戏──\n" + 
                "[对方猜数胜] "+对方猜数胜+" 次\n" + 
                "[对方猜数败] "+对方猜数败+" 次\n" + 
                "[对方猜谜胜] "+对方猜谜胜+" 次\n" + 
                "[对方猜谜败] "+对方猜谜败+" 次\n" + 
                "[对方猜歌胜] "+对方猜歌胜+" 次\n" + 
                "[对方猜歌败] "+对方猜歌败+" 次\n" + 
                "[对方接龙胜] "+对方接龙+" 次";
                text = text.replace("-", "欠");
                text = text.replace("null", "无");
                text = text.replace("void", "获取异常");
                sendm(qun,text,0);
                return;
            }
            if(wxid.equals(对方奴隶主)) {
                String text = "@"+name+" \n" + 
                name2+" 的信息\n" + 
                "[对方累签] "+对方签到+" 天\n" + 
                "[对方体力] "+对方体力+"/100⚡\n" + 
                "◈财富──\n" + 
                "[对方点券] "+对方点券+" 💴\n" + 
                "[对方存款] "+对方存款+" 💴\n" + 
                "◈婚姻──\n";
                if(婚姻状态.equals("未婚")) {
                    text += "[对方状态]"+对方婚姻+"\n";
                }else{
                    text += "[对方关系]"+对方关系;
                }
                text += "◈奴隶──\n" + 
                "[对方奴隶主] 你\n" + 
                "[对方奴隶]"+对方奴隶+"\n" + 
                "[对方赎身价格]\n"+对方赎身+" 💴\n" + 
                "◈游戏──\n" + 
                "[对方猜数胜] "+对方猜数胜+" 次\n" + 
                "[对方猜数败] "+对方猜数败+" 次\n" + 
                "[对方猜谜胜] "+对方猜谜胜+" 次\n" + 
                "[对方猜谜败] "+对方猜谜败+" 次\n" + 
                "[对方猜歌胜] "+对方猜歌胜+" 次\n" + 
                "[对方猜歌败] "+对方猜歌败+" 次\n" + 
                "[对方接龙胜] "+对方接龙+" 次";
                text = text.replace("-", "欠");
                text = text.replace("null", "无");
                text = text.replace("void", "获取异常");
                sendm(qun,text,0);
                return;
            }
            if(wxid.equals(对方奴隶)) {
                String text = "@"+name+" \n" + 
                name2+" 的信息\n" + 
                "◈奴隶──\n" + 
                "[对方奴隶] 你\n" + 
                "◈游戏──\n" + 
                "[对方猜数胜] "+对方猜数胜+" 次\n" + 
                "[对方猜谜胜] "+对方猜谜胜+" 次\n" + 
                "[对方猜歌胜] "+对方猜歌胜+" 次\n" + 
                "[对方接龙胜] "+对方接龙+" 次";
                text = text.replace("-", "欠");
                text = text.replace("null", "无");
                text = text.replace("void", "获取异常");
                sendm(qun,text,0);
                return;
            }
            String text = "@"+name+" \n" + 
            name2+" 的信息\n" + 
            "◈财富──\n" + 
            "[对方点券] "+对方点券+" 💴\n" + 
            "◈奴隶──\n" + 
            "[对方奴隶主]\n"+对方奴隶主+"\n" + 
            "[对方奴隶]"+对方奴隶+"\n" + 
            "◈游戏──\n" + 
            "[对方猜数胜] "+对方猜数胜+" 次\n" + 
            "[对方猜数败] "+对方猜数败+" 次\n" + 
            "[对方猜谜胜] "+对方猜谜胜+" 次\n" + 
            "[对方猜谜败] "+对方猜谜败+" 次\n" + 
            "[对方猜歌胜] "+对方猜歌胜+" 次\n" + 
            "[对方猜歌败] "+对方猜歌败+" 次\n" + 
            "[对方接龙胜] "+对方接龙+" 次";
            text = text.replace("-", "欠");
            text = text.replace("null", "无");
            text = text.replace("void", "获取异常");
            sendm(qun,text,0);
            return;
        }
    }
    if(content.equals("个人信息")||content.equals("信息")) {
        String text = "@"+name+" \n" + 
        "你的基本信息\n" + 
        "[累签] "+签到+" 天\n" + 
        "[体力] "+体力+"/100⚡\n" + 
        "◈财富──\n" + 
        "[点券] "+点券+" 💴\n" + 
        "[存款] "+存款+" 💴\n" + 
        "◈婚姻──\n";
        if(婚姻状态.equals("未婚")) {
            text += "[状态]"+婚姻状态+"\n";
        }else{
            text += "[关系]"+关系+"\n" + 
            "[爱人]"+爱人+"\n";
        }
        text += "◈奴隶──\n" + 
        "[奴隶主]"+奴隶主+"\n" + 
        "[奴隶]"+奴隶+"\n" + 
        "[赎身价格] "+赎身+" 💴\n" + 
        "◈游戏──\n" + 
        "[猜数胜] "+猜数胜+" 次\n" + 
        "[猜数败] "+猜数败+" 次\n" + 
        "[猜谜胜] "+猜谜胜+" 次\n" + 
        "[猜谜败] "+猜谜败+" 次\n" + 
        "[猜歌胜] "+猜歌胜+" 次\n" + 
        "[猜歌败] "+猜歌败+" 次\n" + 
        "[接龙胜] "+接龙+" 次";
        text = text.replace("-", "欠");
        text = text.replace("null", "无");
        text = text.replace("void", "获取异常");
        sendm(qun,text,0);
        return;
    }
}