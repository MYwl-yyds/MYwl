public void 娱乐系统_签到(Object data) {
	String content = data.content;
	String qun = data.talker;
	String wxid=data.sendTalker;
	String name = getName(wxid);
	int 签到 = 读整("Groups/"+qun+"/Users",wxid+"_user","累签");
	int 点券 = 读整("Groups/"+qun+"/Users",wxid+"_user","点券");
	int 体力 = 读整("Groups/"+qun+"/Users",wxid+"_user","体力");
	String 签到时间 = 读("Groups/"+qun+"/Users",wxid+"_user","签到时间","无");
	String 奴隶主 = 读("Groups/"+qun+"/Users",wxid+"_user","奴隶主","无");
	int 奴隶主点券 = 读整("Groups/"+qun+"/Users",奴隶主+"_user","点券");
	int 随机点券 = 100 + (int)(Math.random() * 901);
    int 随机体力 = 5 + (int)(Math.random() * 26);
	if(content.equals("签到")) {
	    if(签到时间.equals("无")) {
	        if(奴隶主.equals("无")) {
	            写("Groups/"+qun+"/Users",wxid+"_user","签到时间",GetTime(4));
	            写("Groups/"+qun+"/Users",wxid+"_user","累签",签到+1);
	            写("Groups/"+qun+"/Users",wxid+"_user","点券",点券+随机点券);
	            if(点券+随机点券>=100) {
	                写("Groups/"+qun+"/Users",wxid+"_user","体力",100);
	            }else{
	                写("Groups/"+qun+"/Users",wxid+"_user","体力",体力+随机体力);
	            }
	            String text = "@"+name+" \n" + 
	            "签到成功!\n"+ 
	            "获得\n💴"+随机点券+"  ⚡"+随机体力+"\n" + 
	            "发送\"个人信息\"可查自身信息\n" + 
	            "引用发送\"信息\"可查对方信息";
	            sendm(qun,text,0);
	        }else{
	            写("Groups/"+qun+"/Users",wxid+"_user","签到时间",GetTime(4));
	            写("Groups/"+qun+"/Users",wxid+"_user","累签",签到+1);
	            int 随机点券真实 = 随机点券/2;
	            写("Groups/"+qun+"/Users",wxid+"_user","点券",点券+随机点券真实);
	            写("Groups/"+qun+"/Users",奴隶主+"_user","点券",奴隶主点券+随机点券真实);
	            if(点券+随机点券>=100) {
	                写("Groups/"+qun+"/Users",wxid+"_user","体力",100);
	            }else{
	                写("Groups/"+qun+"/Users",wxid+"_user","体力",体力+随机体力);
	            }
	            String text = "@"+name+" \n" + 
	            "签到成功!\n"+ 
	            "获得\n💴"+随机点券+"  ⚡"+随机体力+"\n" + 
	            "失去\n💴"+随机点券真实+"\n" + 
	            "你的奴隶主\""+getName(奴隶主)+"\"收取"+随机点券真实+"💴" + 
	            "发送\"个人信息\"可查自身信息\n" + 
	            "引用发送\"信息\"可查对方信息";
	            sendm(qun,text,0);
	        }
	    }else{
	        if(时间间隔.天数(签到时间)>=1) {
	            if(奴隶主.equals("无")) {
	                写("Groups/"+qun+"/Users",wxid+"_user","签到时间",GetTime(4));
	                写("Groups/"+qun+"/Users",wxid+"_user","累签",签到+1);
	                写("Groups/"+qun+"/Users",wxid+"_user","点券",点券+随机点券);
	                if(点券+随机点券>=100) {
	                    写("Groups/"+qun+"/Users",wxid+"_user","体力",100);
	                }else{
	                    写("Groups/"+qun+"/Users",wxid+"_user","体力",体力+随机体力);
	                }
	                String text = "@"+name+" \n" + 
	                "签到成功!\n"+ 
	                "获得\n💴"+随机点券+"  ⚡"+随机体力+"\n" + 
	                "发送\"个人信息\"可查自身信息\n" + 
	                "引用发送\"信息\"可查对方信息";
	                sendm(qun,text,0);
	            }else{
	                写("Groups/"+qun+"/Users",wxid+"_user","签到时间",GetTime(4));
	                写("Groups/"+qun+"/Users",wxid+"_user","累签",签到+1);
	                int 随机点券真实 = 随机点券/2;
	                写("Groups/"+qun+"/Users",wxid+"_user","点券",点券+随机点券真实);
	                写("Groups/"+qun+"/Users",奴隶主+"_user","点券",奴隶主点券+随机点券真实);
	                if(点券+随机点券>=100) {
	                写("Groups/"+qun+"/Users",wxid+"_user","体力",100);
	                }else{
	                    写("Groups/"+qun+"/Users",wxid+"_user","体力",体力+随机体力);
	                }
	                String text = "@"+name+" \n" + 
	                "签到成功!\n"+ 
	                "获得\n💴"+随机点券+"  ⚡"+随机体力+"\n" + 
	                "失去\n💴"+随机点券真实+"\n" + 
	                "你的奴隶主\""+getName(奴隶主)+"\"收取"+随机点券真实+"💴" + 
	                "发送\"个人信息\"可查自身信息\n" + 
	                "引用发送\"信息\"可查对方信息";
	                sendm(qun,text,0);
	            }
	        }else{
	            String text = "@"+name+" \n" + 
	            "你今日已签到，明日再来";
	            sendm(qun,text,0);
	        }
	    }
	}
}