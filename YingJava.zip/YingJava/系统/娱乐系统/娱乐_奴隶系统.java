Map groupGameState = new HashMap();
public void 娱乐系统_奴隶系统(Object data) {
	String content = data.content;
	String qun = data.talker;
	String wxid = data.sendTalker;
	String name = getName(wxid);
	int 点券 = 读整("Groups/"+qun+"/Users",wxid+"_user","点券");
	int 体力 = 读整("Groups/"+qun+"/Users",wxid+"_user","体力");
	String 奴隶主 = 读("Groups/"+qun+"/Users",wxid+"_user","奴隶主","无");
	String 奴隶 = 读("Groups/"+qun+"/Users",wxid+"_user","奴隶","无");
	if(data.isReply()) {
		String wxid2 = getElementContent(data.content, "chatusr");
		String content2 = getElementContent(data.content, "title");
		String name2 = getName(wxid2);
		int 点券2 = 读整("Groups/"+qun+"/Users",wxid2+"_user","点券");
	    int 体力2 = 读整("Groups/"+qun+"/Users",wxid2+"_user","体力");
	    String 奴隶系统保护机制 = 读("Groups/"+qun+"/Users",wxid2+"_user","奴隶系统保护机制",GetTime(4));
	    String 奴隶主2 = 读("Groups/"+qun+"/Users",wxid2+"_user","奴隶主","无");
	    String 奴隶2 = 读("Groups/"+qun+"/Users",wxid2+"_user","奴隶","无");
		if(content2.equals("买下")||content2.equals("买奴隶")) {
			if(wxid.equals(wxid2)) {
				sendm(qun, "@"+name+"\n不能购买自己",0);
				return;
			}
			if(奴隶主.equals(wxid2)) {
				sendm(qun, "@"+name+"\n不能购买你的奴隶主",0);
				return;
			}
			if(时间间隔.天数(奴隶系统保护机制)<3) {
			    if(时间间隔.天数(奴隶系统保护机制)==0) {
			        写("Groups/"+qun+"/Users",wxid2+"_user","奴隶系统保护机制",GetTime(4));
		        }
			    sendm(qun,"@"+name+"\n对方处于保护中，保护机制"+(3-时间间隔.天数(奴隶系统保护机制))+"天后失效，请"+(3-时间间隔.天数(奴隶系统保护机制))+"天后重新尝试",0);
			    return;
			}
			if(奴隶主2.equals("无")) {
				if(奴隶.equals("无")) {
					if(点券 >= 点券2) {
						写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券 - 点券2);
						写("Groups/"+qun+"/Users", wxid2 + "_user", "奴隶主", wxid);
						写("Groups/"+qun+"/Users", wxid + "_user", "奴隶", wxid2);
						写("Groups/"+qun+"/Users", wxid2 + "_user", "赎身价格", 点券2*2+50000);
						写("Groups/"+qun+"/Users", wxid2 + "_user", "买下时间", GetTime(4));
						写("Groups/"+qun+"/Users",wxid2+"_user","奴隶打工限制",GetTime(4));
						sendm(qun, "@" + name + " \n购买成功!\n你成功将 " + name2 + " 买下，成为自己的奴隶",0);
						return;
					}else{
						sendm(qun, "@" + name + "\n购买失败!\n你没有足够的经济能力买下对方",0);
						return;
					}
				}else{
					sendm(qun, "@" + name + "\n你已经有奴隶了",0);
					return;
				}
			}else{
				sendm(qun, "@" + name + " \n购买失败！\n对方已有奴隶主",0);
				return;
			}
		}
		if(content2.equals("放走")||content2.equals("放奴隶")) {
			if(奴隶主2.equals(wxid)) {
			    写("Groups/"+qun+"/Users",wxid2+"_user","奴隶系统保护机制",GetTime(4));
			    删("Groups/"+qun+"/Users", wxid2 + "_user", "买下时间");
			    删("Groups/"+qun+"/Users",wxid2+"_user","奴隶打工限制");
				删("Groups/"+qun+"/Users", wxid2 + "_user", "奴隶主");
				删("Groups/"+qun+"/Users", wxid + "_user", "奴隶");
				删("Groups/"+qun+"/Users", wxid2 + "_user", "赎身价格");
				sendm(qun, "@" + name + " \n你成功还给 " + name2 + " 自由",0);
				return;
			}
		}
		if(content2.startsWith("卖奴隶")) {
			String mnlStr = content2.substring(3);
			try {
				int mnl = Integer.parseInt(mnlStr);
				String 卖奴隶 = 读("Groups/"+qun+"/Users", wxid + "_user", "卖奴隶","无");
				int 卖奴隶价格 = 读整("Groups/"+qun+"/Users", wxid + "_user", "卖奴隶价格");
				if(卖奴隶.equals("无")||卖奴隶价格==0) {
					if(奴隶.equals(wxid2)) {
						return;
					}
					if(wxid.equals(wxid2)) {
					    return;
					}
					if(奴隶.equals("无")) {
						sendm(qun, "@" + name + " \n你还没有奴隶",0);
						return;
				    }else{
					    写("Groups/"+qun+"/Users", wxid + "_user", "卖奴隶", wxid2);
						写("Groups/"+qun+"/Users", wxid + "_user", "卖奴隶价格", mnl);
						写("Groups/"+qun+"/Users", wxid2 + "_user", "买奴隶", wxid);
						sendm(qun, "@" + name2 + "\n" + name +" 将自己的奴隶以 " + mnl + " 点券💴的价格卖给你,你是否购买?\n发送\"购买\"或\"拒绝\"",0);
						sendm(qun, "@" + name + " \n你成功对 " + name2 + " 发起售卖\n等待对方回应\n发送\"取消交易\"可关闭交易");
						return;
				    }
				}else{
					sendm(qun, "@" + name + " \n你当前的交易未完成，无法创建新的交易\n等待交易对方回应或发送\"取消交易\"来关闭交易",0);
					return;
				}
			}catch(NumberFormatException e) {
				return;
			}
		}
	}
	String 买奴隶 = 读("Groups/"+qun+"/Users", wxid + "_user", "买奴隶","无");
	String 卖奴隶 = 读("Groups/"+qun+"/Users", 买奴隶 + "_user", "卖奴隶","无");
	int 卖奴隶价格 = 读整("Groups/"+qun+"/Users", 买奴隶 + "_user", "卖奴隶价格");
	String 奴隶3 = 读("Groups/"+qun+"/Users", 买奴隶 + "_user", "奴隶","无");
	int 点券3 = 读整("Groups/"+qun+"/Users", 买奴隶 + "_user", "点券");
	String name3 = getName(买奴隶);
	String name4 = getName(奴隶3);
	if(data.type==1) {
		if(content.equals("购买")) {
			if(买奴隶.equals("无")||卖奴隶.equals("无")||卖奴隶价格==0) {
				return;
			}
			if(奴隶.equals("无")) {
				sendm(qun, "@" + name + " \n购买成功!\n" + name4 + " 已被你购为奴隶\n\n失去\n💴"+卖奴隶价格,0);
				sendm(qun, "@" + name3 + " \n出售成功!\n" + name4 + " 被你以 "+ 卖奴隶价格 +" 点券💴的价格出售\n\n获取\n💴"+卖奴隶价格,0);
				sendm(qun, "@" + name4 + " \n你的奴隶主更换为 " + name,0);
				写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券 - 卖奴隶价格);
				写("Groups/"+qun+"/Users", 买奴隶 + "_user", "点券", 点券3 + 卖奴隶价格);
				写("Groups/"+qun+"/Users", wxid + "_user", "奴隶", 奴隶3);
				写("Groups/"+qun+"/Users", 奴隶3 + "_user", "奴隶主", wxid);
				写("Groups/"+qun+"/Users", 奴隶3 + "_user", "赎身价格", 卖奴隶价格*2 + 50000);
				写("Groups/"+qun+"/Users", 奴隶3 + "_user", "买下时间", GetTime(4));
				写("Groups/"+qun+"/Users",奴隶3+"_user","奴隶打工限制",GetTime(4));
				删("Groups/"+qun+"/Users", 买奴隶 + "_user", "奴隶");
				删("Groups/"+qun+"/Users", 买奴隶 + "_user", "卖奴隶");
				删("Groups/"+qun+"/Users", 买奴隶 + "_user", "卖奴隶价格");
				删("Groups/"+qun+"/Users", wxid + "_user", "买奴隶");
				return;
			}else{
			    sendm(qun, "@" + name + " \n你已经有奴隶了,不能再购买奴隶了\n已自动拒绝购买",0);
				sendm(qun, "@" + name3 + "\n" + name + " 已拒绝购买");
				删("Groups/"+qun+"/Users", 买奴隶 + "_user", "卖奴隶");
				删("Groups/"+qun+"/Users", 买奴隶 + "_user", "卖奴隶价格");
				删("Groups/"+qun+"/Users", wxid + "_user", "买奴隶");
				return;
			}
		}
		if(content.equals("拒绝")) {
			if(买奴隶.equals("无")||卖奴隶.equals("无")||卖奴隶价格==0) {
				return;
			}
			sendm(qun, "@" + name + " \n已拒绝购买",0);
			sendm(qun, "@" + name3 + "\n" + name + " 已拒绝购买",0);
			删("Groups/"+qun+"/Users", 买奴隶 + "_user", "卖奴隶");
			删("Groups/"+qun+"/Users", 买奴隶 + "_user", "卖奴隶价格");
			删("Groups/"+qun+"/Users", wxid + "_user", "买奴隶");
			return;
		}
		if(content.equals("取消交易")) {
			if(买奴隶.equals("无")||卖奴隶.equals("无")||卖奴隶价格==0) {
				return;
			}
			sendm(qun, "@"+name+"\n你成功取消当前交易",0);
			删("Groups/"+qun+"/Users", 买奴隶 + "_user", "卖奴隶");
			删("Groups/"+qun+"/Users", 买奴隶 + "_user", "卖奴隶价格");
			删("Groups/"+qun+"/Users", wxid + "_user", "买奴隶");
			return;
		}
		if(content.equals("我要赎身")) {
		    String 买下时间 = 读("Groups/"+qun+"/Users", wxid + "_user", "买下时间", "无");
			int 赎身价格 = 读整("Groups/"+qun+"/Users", wxid + "_user", "赎身价格");
			if(奴隶主.equals("无")) {
				return;
			}else{
				if(时间间隔.天数(买下时间)>=3) {
					if(点券 >= 赎身价格) {
						sendm(qun, "@" + name + " \n你已成功赎回自己\n\n失去\n💴" + 赎身价格,0);
					    写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券-赎身价格);
					    删("Groups/"+qun+"/Users",wxid+"_user","奴隶打工限制");
					    删("Groups/"+qun+"/Users", 奴隶主 + "_user", "奴隶");
						删("Groups/"+qun+"/Users", wxid + "_user", "奴隶主");
						删("Groups/"+qun+"/Users", wxid + "_user", "赎身价格");
						删("Groups/"+qun+"/Users", wxid + "_user", "买下时间");
					    return;
					}else{
						sendm(qun, "@" + name + " \n你没有足够的经济能力为自己赎身",0);
						return;
					}
				}else{
					sendm(qun, "@" + name + " \n从被买下起到现在还不足3天，请等待3天后再试",0);
					return;
				}
			}
		}
		Timer timer = new Timer();
		if(content.equals("奴隶打工")) {
			String dg = qun+wxid+奴隶+"奴隶打工";
			String nlname = getName(奴隶);
			String 奴隶打工限制 = 读("Groups/"+qun+"/Users",奴隶+"_user","奴隶打工限制","无");
			if(奴隶.equals("无")) {
				sendm(qun, "@" + name + " \n你没有奴隶",0);
				return;
			}
			if(时间间隔.天数(奴隶打工限制)<1||奴隶打工限制.equals("无")) {
			    if(奴隶打工限制.equals("无")) {
			        sendm(qun,"@"+name+"\n奴隶系统出现异常",0);
			        return;
			    }
			    sendm(qun,"@"+name+"\n今日奴隶已打过工了或者今日刚购买了奴隶，明日再来",0);
			    return;
			}
			if(groupGameState.containsKey(dg))
			{
				sendm(qun, "@" + name + " \n你的奴隶正在打工，请耐心等待",0);
				return;
			} 
			Map state = new HashMap();
			TimerTask timerTask = new TimerTask() {
				public void run() {
					int rnd = 读整("Groups/"+qun+"/Users", 奴隶 + "_user", "奴隶打工");
					sendm(qun, "@"+ name + " \n你的奴隶 " + nlname + " 打工完成\n\n获取\n💴" + rnd,0);
					写("Groups/"+qun+"/Users",奴隶+"_user","奴隶打工限制",GetTime(4));
					写("Groups/"+qun+"/Users", wxid + "_user", "点券", 点券 + rnd);
					删("Groups/"+qun+"/Users", 奴隶 + "_user", "奴隶打工");
					groupGameState.remove(dg);
				}
			};
			timer.schedule(timerTask, 300000);
			state.put("timerTask", timerTask);
			groupGameState.put(dg, state);
			int nltl = 读整("Groups/"+qun+"/Users", 奴隶 + "_user", "体力");
			if(nltl<=10) {
				sendm(qun, "@" + name + " \n你的奴隶已经虚脱，已开始超负荷打工，5分钟后结束，打工为你赚取点券将大幅下降",0);
				int rnd = (int)(Math.random() * 450 + 50);
				写("Groups/"+qun+"/Users", 奴隶 + "_user", "奴隶打工", rnd);
				写("Groups/"+qun+"/Users", 奴隶 + "_user", "体力", 0);
			}else if(nltl>10&&nltl<=40) {
				sendm(qun, "@" + name +" \n你的奴隶已开始打工，5分钟后结束，你的奴隶非常劳累，打工为你赚取点券将明显减少",0);
				int rnd = (int)(Math.random() * 1500 + 500);
				写("Groups/"+qun+"/Users", 奴隶 + "_user", "奴隶打工", rnd);
				写("Groups/"+qun+"/Users", 奴隶 + "_user", "体力", nltl - 10);
			}else if(nltl>40&&nltl<=70) {
				sendm(qun, "@" + name + " \n你的奴隶已开始打工，5分钟后结束，奴隶有些疲劳，打工为你赚取点券将有些许减少",0);
				int rnd = (int)(Math.random() * 3000 + 2000);
				写("Groups/"+qun+"/Users", 奴隶 + "_user", "奴隶打工", rnd);
				写("Groups/"+qun+"/Users", 奴隶 + "_user", "体力", nltl - 10);
			}else{
				sendm(qun, "@" + name + " \n你的奴隶已开始打工，5分钟后结束，奴隶元气满满，打工为你赚取点券将有所增加",0);
				int rnd = (int)(Math.random() * 4000 + 5000);
				写("Groups/"+qun+"/Users", 奴隶 + "_user", "奴隶打工", rnd);
				写("Groups/"+qun+"/Users", 奴隶 + "_user", "体力", nltl - 10);
			}
		}
    }
}
