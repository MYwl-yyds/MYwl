public void 娱乐系统_打劫系统(Object data) {
    String content = data.content;
    String qun = data.talker; 
    String wxid = data.sendTalker;
	String name = getName(wxid);
	int 点券 = 读整("Groups/"+qun+"/Users",wxid+"_user","点券");
    int 体力 = 读整("Groups/"+qun+"/Users",wxid+"_user","体力");
    int 打劫成功 = 读整("Groups/"+qun+"/Users",wxid+"_user","打劫成功");
    int 打劫失败 = 读整("Groups/"+qun+"/Users",wxid+"_user","打劫失败");
    int 装备数据 = 读整("Groups/"+qun+"/Users",wxid+"_user","装备数据");
    int 当前装备 = 读整("Groups/"+qun+"/Users",  wxid+"_user", "当前装备");
    int 住院 = 读整("Groups/"+qun+"/Users",wxid+"_user","住院");
    int 监狱 = 读整("Groups/"+qun+"/Users",wxid+"_user","监狱");
    String 奴隶主 = 读("Groups/"+qun+"/Users",wxid+"_user","奴隶主","无");
    int 奴隶主点券 = 读整("Groups/"+qun+"/Users",奴隶主+"_user","点券");
    String 奴隶 = 读("Groups/"+qun+"/Users",wxid+"_user","奴隶","无");
    if(data.isReply()) {
        String wxid2 = getElementContent(data.content,"chatusr");
        String content2 = getElementContent(data.content,"title");
        String name2 = getName(wxid2);
        int 点券2 = 读整("Groups/"+qun+"/Users",wxid2+"_user","点券");
        int 装备数据2 = 读整("Groups/"+qun+"/Users",wxid2+"_user","装备数据");
        int 当前装备2 = 读整("Groups/"+qun+"/Users",  wxid2+"_user", "当前装备");
        if(content2.equals("打劫")) {
            if(体力>=10) {
                if(住院-data.createTime > 0) {
                    long timeLeft = 住院 - data.createTime;
                    String text = "@" + name + "\n";
                    text += "你目前处于住院状态，无法参与打劫游戏\n";
                    text += "🏥出院还需 " + secondToTime(timeLeft / 1000);
                    sendm(qun,text,0);
                    return;
                }
                if(监狱-data.createTime > 0) {
                    long timeLeft = 监狱 - data.createTime;
                    String text = "@" + name + "\n";
                    text += "你目前还在监狱改造中，可选择\"越狱\"或\"保释\"\n";
                    text += "PS:越狱成功率由你的装备决定\n";
                    text += "🕋出狱还需 " + secondToTime(timeLeft / 1000);
                    sendm(qun,text,0);
                    return;
                }
                if(wxid2.equals(wxid)) {
				    String text = "@" + name + "\n";
				    text += "啊哈,你打劫了自己\n";
				    text += "什么都没得到，还受了伤\n";
				    text += "\n状态\n🏥2分钟\n";
				    text += "失去\n⚡1";
				    写("Groups/"+qun+"/Users", wxid+"_user","住院", data.createTime+120000);
				    写("Groups/"+qun+"/Users",  wxid+"_user", "打劫失败", 打劫失败 + 1);
				    写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力 - 5);
				    sendm(qun,text,0);
				    return;
			    }
			    if(wxid2.equals(奴隶主)) {
			        String text = "@"+name+"\n" + 
			        "你不能打劫自己的奴隶主";
			        sendm(qun,text,0);
			        return;
			    }
			    if(点券2 <= 0) {
				    String text = "@" + name + "\n";
				    text += "打劫失败\n";
				    text += name2+" 一分都没有，白跑一趟";
				    text += "\n\n失去\n⚡1";
				    写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力 - 1);
				    sendm(qun,text,0);
				    return;
			    }
			    if((Math.random() * 10) < 1) {
				    int randomExtraTime = (int) (Math.random() * 600000);
				    String text = "@" + getName(wxid) + "\n";
				    text += "啊哈，还没开始打劫你就被抓了，什么都没得到\n";
				    text += "\n状态\n🕋"+secondToTime(randomExtraTime / 1000);
				    text += "\n失去\n⚡5";
				    写("Groups/"+qun+"/Users", wxid+"_user","监狱", data.createTime+randomExtraTime);
				    写("Groups/"+qun+"/Users",  wxid+"_user", "打劫失败", 打劫失败 + 1);
				    写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力 - 5);
				    if(网站状态.Get("http://gchat.qpic.cn/gchatpic_new/184757891/582544273-2325868538-5509A4E5E9F0C8F25D740955F686B53D/0?term=2")==true) {
				        sendPic(qun, "http://gchat.qpic.cn/gchatpic_new/184757891/582544273-2325868538-5509A4E5E9F0C8F25D740955F686B53D/0?term=2");
				    }else{
				        sendPic(qun,JavaPath+"/YingJava/附属/Resources/IMG/JPG/娱乐_打劫1.jpg");
				    }
				    sendm(qun,text,0);
				    return;
			    }
			    int tRank = 装备数据 - 装备数据2;
			    if((Math.random()) > GetChanceByDistance(tRank)) {
				    String[] LName = {"拳头", "匕首", "电棍", "手枪", "激光剑", "火箭筒", "导弹", "核弹"};
				    String text = "@" + name + "\n";
				    text += "打劫成功\n";
				    int coin = 200 + (int)(Math.random() * 2801);
				    text += "你使用的是:" + LName[读整("Groups/"+qun+"/Users",  wxid+"_user", "当前装备")];
				    text += "\n对方使用的是:" + LName[读整("Groups/"+qun+"/Users",  wxid2+"_user", "当前装备")];
				    text += "\n你一下子就把对方打倒了";
				    text += "\n\n获得\n💴" + coin;
				    text += "\n失去\n⚡10";
				    if(奴隶主.equals("无")) {
					    写("Groups/"+qun+"/Users",  wxid+"_user", "点券", 点券 + coin);
					    写("Groups/"+qun+"/Users",  wxid2 +"_user", "点券", 点券2 - coin);
					    写("Groups/"+qun+"/Users",  wxid+"_user", "打劫成功", 打劫成功 + 1);
					    写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力 - 10);
					    if(网站状态.Get("http://gchat.qpic.cn/gchatpic_new/184757891/582544273-2378094304-CE3AE9551C9BFB630DA916EB3B16F271/0?term=2")==true) {
		                    sendPic(qun, "http://gchat.qpic.cn/gchatpic_new/184757891/582544273-2378094304-CE3AE9551C9BFB630DA916EB3B16F271/0?term=2");
					    }else{
					        sendPic(qun, JavaPath+"/YingJava/附属/Resources/IMG/JPG/娱乐_打劫2.jpg");
					    }
					    sendm(qun,text,0);
					    return;
				    }else{
					    coin = coin / 2;
					    text += "\n你的奴隶主收取 " + coin + " 点券💴";
					    写("Groups/"+qun+"/Users", 奴隶主 + "_user", "点券", 奴隶主点券 + coin);
					    写("Groups/"+qun+"/Users",  wxid+"_user", "点券",点券 + coin);
					    写("Groups/"+qun+"/Users",  wxid2 +"_user", "点券", 点券2 - coin);
					    写("Groups/"+qun+"/Users",  wxid+"_user", "打劫成功", 打劫成功 + 1);
					    写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力 - 10);
					    if(网站状态.Get("http://gchat.qpic.cn/gchatpic_new/184757891/582544273-2378094304-CE3AE9551C9BFB630DA916EB3B16F271/0?term=2")==true) {
		                    sendPic(qun, "http://gchat.qpic.cn/gchatpic_new/184757891/582544273-2378094304-CE3AE9551C9BFB630DA916EB3B16F271/0?term=2");
					    }else{
					        sendPic(qun, JavaPath+"/YingJava/附属/Resources/IMG/JPG/娱乐_打劫2.jpg");
					    }
					    sendm(qun,text,0);
					    return;
				    }
			    }else{
				    String[] LName = {"拳头", "匕首", "电棍", "手枪", "激光剑", "火箭筒", "导弹", "核弹"};
				    String text = "@" + name + "\n";
				    text += "打劫失败\n";
				    int coin = 200 + (int)(Math.random() * 2801);
				    text += "你使用的是:" + LName[读整("Groups/"+qun+"/Users",  wxid+"_user", "当前装备")];
				    text += "\n对方使用的是:" + LName[读整("Groups/"+qun+"/Users",  wxid2+"_user", "当前装备")];
				    text += "\n你被对方反杀了";
				    text += "\n\n失去\n💴" + coin + "  ⚡10";
				    写("Groups/"+qun+"/Users",  wxid+"_user", "点券", 点券 - coin);
				    写("Groups/"+qun+"/Users",  wxid2 +"_user", "点券",点券2 + coin);
				    写("Groups/"+qun+"/Users",  wxid+"_user", "打劫失败", 打劫失败 + 1);
				    写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力 - 10);
				    if(网站状态.Get("http://gchat.qpic.cn/gchatpic_new/184757891/582544273-2234018960-097C0892617D810C50BCBD67F1AE132D/0?term=2")==true) {
				        sendPic(qun, "http://gchat.qpic.cn/gchatpic_new/184757891/582544273-2234018960-097C0892617D810C50BCBD67F1AE132D/0?term=2");
				    }else{
				        sendPic(qun, JavaPath+"/YingJava/附属/Resources/IMG/JPG/娱乐_打劫3.jpg");
				    }
				    sendm(qun,text,0);
				    return;
			    }
            }else{
	            String text = "@" + name + "\n";
	            text += "体力不足10⚡，打劫失败";
	            sendm(qun,text,0);
	        }
        }
    }
    if(content.equals("打劫群主")) {
        if(住院-data.createTime > 0) {
            long timeLeft =住院 - data.createTime;
            String text = "@" + name + "\n";
            text += "你目前处于住院状态，无法参与打劫游戏\n";
            text += "🏥出院还需 " + secondToTime(timeLeft / 1000);
            sendm(qun,text,0);
            return;
        }
        if(监狱-data.createTime > 0) {
            long timeLeft = 监狱 - data.createTime;
            String text = "@" + name + "\n";
            text += "你目前还在监狱改造中，可选择\"越狱\"或\"保释\"\n";
            text += "PS:越狱成功率由你的装备决定\n";
            text += "🕋出狱还需 " + secondToTime(timeLeft / 1000);
            sendm(qun,text,0);
            return;
        }
        if(体力>=15) {
            int coin = 500 + (int)(Math.random() * 4501);
		    if((Math.random() * 5) < 1) {
                String[] texts = {"内衣抢走了", "内裤都扒走了", "全身搜光了"};
                Random random = new Random();
                int index = random.nextInt(texts.length);
                String djqz = texts[index];
			    String text = "@" + name + "\n你成功地打劫了群主\n把他"+djqz+"\n\n获得\n💴" + coin + "\n失去\n⚡15";
			    if(奴隶主.equals("无")) {
			        写("Groups/"+qun+"/Users",  wxid+"_user", "点券",点券 + coin);
			        写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力 - 15);
			        写("Groups/"+qun+"/Users",  wxid+"_user", "打劫成功",打劫成功 + 1);
			        sendm(qun,text,0);
			        return;
			    }else{
				    coin = coin / 2;
				    text += "\n你的奴隶主收取 " + coin + " 点券💴";
				    写("Groups/"+qun+"/Users", 奴隶主 + "_user", "点券", 奴隶主点券 + coin);
				    写("Groups/"+qun+"/Users",  wxid+"_user", "点券", 点券 + coin);
				    写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力 - 15);
				    写("Groups/"+qun+"/Users",  wxid+"_user", "打劫成功", 打劫成功 + 1);
				    sendm(qun,text,0);
				    return;
			    }
		    }else{
		        int randomExtraTime = (int) (Math.random() * 600000);
			    String text = "@" + name + "\n你打劫时候被群主反杀了\n\n状态\n🕋"+secondToTime(randomExtraTime / 1000)+"失去\n💴"+ coin + "  ⚡5";
			    写("Groups/"+qun+"/Users", wxid+"_user","监狱", data.createTime+randomExtraTime);
			    写("Groups/"+qun+"/Users",  wxid+"_user", "点券", 点券 - coin);
			    写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力 - 5);
			    写("Groups/"+qun+"/Users",  wxid+"_user", "打劫失败", 打劫失败 + 1);
			    sendm(qun,text,0);
			    return;
		    }
        }else{
	        sendm(qun,"@"+name+"\n体力不足15⚡");
	        return;
	    }
    }
    if(content.equals("打劫银行")) {
        if(住院-data.createTime > 0) {
            long timeLeft =住院 - data.createTime;
            String text = "@" + name + "\n";
            text += "你目前处于住院状态，无法参与打劫游戏\n";
            text += "🏥出院还需 " + secondToTime(timeLeft / 1000);
            sendm(qun,text,0);
            return;
        }
        if(监狱-data.createTime > 0) {
            long timeLeft = 监狱 - data.createTime;
            String text = "@" + name + "\n";
            text += "你目前还在监狱改造中，可选择\"越狱\"或\"保释\"\n";
            text += "PS:越狱成功率由你的装备决定\n";
            text += "🕋出狱还需 " + secondToTime(timeLeft / 1000);
            sendm(qun,text,0);
            return;
        }
        if(体力>=20) {
            if((Math.random() * 5) < 1) {
			    int coin = 100 + (int)(Math.random() * 401);
			    int randomExtraTime = (int) (Math.random() * 600000);
			    String text = "@" + name + "\n你打劫时候被警察抓到了\n\n状态\n🕋"+secondToTime(randomExtraTime / 1000)+"\n失去\n💴" + coin + "  ⚡10";
			    写("Groups/"+qun+"/Users", wxid+"_user","监狱", data.createTime+randomExtraTime);
			    写("Groups/"+qun+"/Users",  wxid+"_user", "点券", 点券 - coin);
			    写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力 - 10);
			    写("Groups/"+qun+"/Users",  wxid+"_user", "打劫失败", 打劫失败 + 1);
			    sendm(qun,text,0);
			    return;
		    }else if((Math.random() * 5) < 1) {
			    int coin = 100 + (int)(Math.random() * 401);
			    String text = "@" + name + "\n你打劫时候出了差错，站不稳滑倒了\n\n状态\n🏥3分钟\n失去\n💴" + coin + "  ⚡10";
			    写("Groups/"+qun+"/Users", wxid+"_user","住院", data.createTime+180000);
			    写("Groups/"+qun+"/Users",  wxid+"_user", "点券", 点券 - coin);
			    写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力 - 10);
			    写("Groups/"+qun+"/Users",  wxid+"_user", "打劫失败", 打劫失败 + 1);
			    sendm(qun,text,0);
			    return;
			}else{
			    int coin = 1000 + (int)(Math.random() * 9001);
			    String text = "@" + name + "\n你成功地打劫了银行，把里面的钱洗劫了\n\n获得\n💴" + coin + "\n失去\n⚡20";
			    if(奴隶主.equals("无")) {
			        写("Groups/"+qun+"/Users",  wxid+"_user", "点券", 点券 + coin);
			        写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力 - 20);
			        写("Groups/"+qun+"/Users",  wxid+"_user", "打劫成功", 打劫成功 + 1);
			        sendm(qun,text,0);
			        return;
			    }else{
				    coin = coin / 2;
				    text += "\n你的奴隶主收取" + coin + "点券💴";
				    写("Groups/"+qun+"/Users", 奴隶主 + "_user", "点券", 奴隶主点券 + coin);
				    写("Groups/"+qun+"/Users",  wxid+"_user", "点券", 点券 + coin);
				    写("Groups/"+qun+"/Users", wxid+"_user", "体力", 体力 - 20);
				    写("Groups/"+qun+"/Users",  wxid+"_user", "打劫成功",打劫成功 + 1);
				    sendm(qun,text,0);
				    return;
			    }
		    }
        }else{
	        sendm(qun,"@"+name+"\n体力不足20⚡",0);
	        return;
	    }
    }
    if(content.equals("越狱")) {
        long lastAttemptTime = 读整("Groups/"+qun+"/Users", wxid+"_user", "最后越狱尝试时间");
        long currentTime = data.createTime;
        long oneMinute = 60000;
        if(currentTime - lastAttemptTime < oneMinute) {
            long waitTime = oneMinute - (currentTime - lastAttemptTime);
            sendm(qun, "@" + name + "\n你需要等待" + secondToTime(waitTime / 1000) + "才能再次尝试越狱",0);
            return;
        }
        long jailTime = 读整("Groups/"+qun+"/Users", wxid+"_user", "监狱");
        if (jailTime - currentTime <= 0) {
            sendm(qun, "@" + name + "\n自由身，不要老是幻想越域",0);
            return;
        }
        if((Math.random() * 100) <= 装备数据) {
            删("Groups/"+qun+"/Users", wxid+"_user", "监狱");
            写("Groups/"+qun+"/Users", wxid+"_user", "最后越狱尝试时间", currentTime);
            sendm(qun, "@" + name + "\n你已成功越狱，现在可以继续游戏",0);
        }else{
            int randomExtraTime = (int) (Math.random() * 300000);
            写("Groups/"+qun+"/Users", wxid+"_user","监狱", jailTime + randomExtraTime);
            写("Groups/"+qun+"/Users", wxid+"_user", "最后越狱尝试时间", currentTime);
            sendm(qun, "@" + name + "\n越狱失败，你需要继续服刑" + secondToTime(((jailTime + randomExtraTime) - currentTime) / 1000),0);
        }
    }
    if(content.equals("保释")) {
        long jailTime = 读整("Groups/"+qun+"/Users", wxid+"_user", "监狱");
        if (jailTime <= 0) {
            sendm(qun, "@" + name + "\n你目前是自由身，不需要保释",0);
            return;
        }
        long currentTime = data.createTime;
        long timeServed = jailTime - currentTime;
        int bailCost = calculateBailCost(timeServed);
        if (点券 >= bailCost) {
            写("Groups/"+qun+"/Users", wxid+"_user", "点券", 点券 - bailCost);
            删("Groups/"+qun+"/Users", wxid+"_user", "监狱");
            sendm(qun, "@" + name + "\n你已成功保释\n\n失去\n💴" + bailCost,0);
        }else{
            sendm(qun, "@" + name + "\n你的点券不足，无法支付保释费"+bailCost,0);
        }
    }
    return;
}
int calculateBailCost(long timeServed) {
    int costPerSecond = 50;
    long secondsServed = timeServed / 1000;
    return (int) secondsServed*costPerSecond;
}