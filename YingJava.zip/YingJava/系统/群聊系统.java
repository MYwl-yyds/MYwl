public static void 群聊系统(Object data) {
    String wxid = data.sendTalker;
	String qun = data.talker;
	String content = data.content;
    String name = getName(wxid);
	String quname = getName(qun);
	String 艾特提示 = 读("全局/群聊系统","艾特提示","艾特提示","无");
	int 艾特提示kg = 读整("全局/群聊系统","艾特提示","开关");
	String 艾特回复 = 读("Groups/"+qun,"艾特回复","艾特回复","这是一个自动回复");
	int 艾特回复kg = 读整("Groups/"+qun,"艾特回复","开关");
	if(wxid.equals(mWxid)) {
	    if(content.startsWith("设置")) {
	        String text = content.substring(2);
	        if(text.contains("进群通知")) {
	            text = content.substring(4);
	            if(text==null||text=="") {
	                return;
	            }
	            写("Groups/"+qun, "进退群", "进群通知", text);
                sendm(qun, "进群通知已设置",0);
	        }
	        if(text.contains("退群通知")) {
	            text = content.substring(4);
	            if(text==null||text=="") {
	                return;
	            }
	            写("Groups/"+qun, "进退群", "退群通知", text);
                sendm(qun, "退群通知已设置",0);
	        }
	    }
	    if(content.equals("进群通知恢复默认")) {
	        删("Groups/"+qun, "进退群", "进群通知");
            sendm(qun,"进群通知已恢复默认", 0);
	    }
	    if(content.equals("退群通知恢复默认")) {
	        删("Groups/"+qun, "进退群", "退群通知");
            sendm(qun,"退群通知已恢复默认", 0);
	    }
	    if(content.equals("群聊系统")) {
	        String text = "[e]查看进退群通知\n" + 
	        "◈进群──\n" + 
	        "[e]设置进群通知+内容\n" + 
	        "[e]进群通知恢复默认\n" + 
	        "◈退群──\n" + 
	        "[e]设置退群通知+内容\n" + 
	        "[e]退群通知恢复默认\n" + 
			"◈艾特──\n" + 
			"[e][开启/关闭]艾特提示\n" + 
			"[e][开启/关闭]艾特回复\n" + 
			"[e]设置艾特回复+内容\n" + 
	        "PS:群聊系统功能大概率无效";
	        sendm(qun,text,0);
	    }
	    if(content.equals("查看进退群通知")) {
	        String text = "进群通知:"+读("Groups/"+qun, "进退群", "进群通知","[邀请名]邀请[被邀名]进群大家热烈欢迎！")+"\n退群通知:"+读("Groups/"+qun, "进退群", "退群通知", "[退群名]退出本群，请珍惜在本群的每一天！");
            sendm(qun, "@"+name+" \n本群进退群通知↓\n"+text, 0);
	    }
		if(content.equals("开启艾特提示")) {
			if(艾特提示kg==0) {
				String text = "@"+name+"\n全局艾特提示开启成功";
				写("全局/群聊系统","艾特提示","开关",1);
				sendm(qun,text,0);
			}else{
				String text = "@"+name+"\n全局艾特提示已开启，无需重复操作";
				sendm(qun,text,0);
			}
		}
		if(content.equals("关闭艾特提示")) {
			if(艾特提示kg==0) {
				String text = "@"+name+"\n全局艾特提示已关闭，无需重复操作";
				sendm(qun,text,0);
			}else{
				String text = "@"+name+"\n全局艾特提示关闭成功";
				删("全局/群聊系统","艾特提示","开关");
				sendm(qun,text,0);
			}
		}
		if(content.equals("开启艾特回复")) {
			if(艾特回复kg==0) {
				String text = "@"+name+"\n本群艾特回复开启成功";
				写("Groups/"+qun,"艾特回复","开关",1);
				sendm(qun,text,0);
			}else{
				String text = "@"+name+"\n本群艾特提示已开启，无需重复操作";
				sendm(qun,text,0);
			}
		}
		if(content.equals("关闭艾特回复")) {
			if(艾特回复kg==0) {
				String text = "@"+name+"\n本群艾特回复已关闭，无需重复操作";
				sendm(qun,text,0);
			}else{
				String text = "@"+name+"\n本群艾特回复关闭成功";
				删("Groups/"+qun,"艾特回复","开关");
				sendm(qun,text,0);
			}
		}
		if(content.startsWith("设置艾特回复")) {
			String hf = content.substring(6);
			if(hf==null||hf.equals("")) {
				return;
			}
			写("Groups/"+qun,"艾特回复","艾特回复",hf);
			sendm(qun,"@"+name+"\n艾特回复设置成功",0);
		}
	}
	String mname = "@"+getName(mWxid);
	if(content.startsWith(mname)) {
		if(data.isSend==0) {
			if(data.talkerType==1) {
				if(艾特提示kg==1) {
					Toast("["+脚本名称+"]群聊:"+quname+"\n成员:"+name+"\n内容:"+content);
				}
				if(艾特回复kg==1) {
					sendm(qun,艾特回复,0);
				}
			}
		}
		return;
	}
	if(data.type==570425393) {
	    if(content.contains("邀请")&&content.contains("你")) {
	        String names = 截取.取中间(content,"<link name=\"names\" type=\"link_profile\"><memberlist><member><username><![CDATA[","]]");
	        String text = 读("Groups/"+qun,"进退群","进群通知","[邀请名]邀请[被邀名]进群大家热烈欢迎！");
            text = text.replace("[邀请名]",getName(mWxid));
            text=text.replace("[被邀名]",getName(names));
            text=text.replace("[群名字]",quname);
            text=text.replace("[群人数]",(getChatMembers(qun)+1));
            sendm(qun,text,0);
	    }else if(content.contains("二维码")&&content.contains("你")) {
	        String names = 截取.取中间(content,"<link name=\"adder\" type=\"link_profile\"><memberlist><member><username><![CDATA[","]]");
	        String text = 读("Groups/"+qun,"进退群","进群通知","[邀请名]邀请[被邀名]进群大家热烈欢迎！");
            text = text.replace("[邀请名]",getName(mWxid));
            text=text.replace("[被邀名]",getName(names));
            text=text.replace("[群名字]",quname);
            text=text.replace("[群人数]",(getChatMembers(qun)+1));
            sendm(qun,text,0);
	    }else if(content.contains("邀请")) {
	        String username = 数据处理.xml(content,"username");
	        String names = 截取.取中间(text,"<link name=\"names\" type=\"link_profile\"><memberlist><member><username><![CDATA[","]]");
            String text = 读("Groups/"+qun,"进退群","进群通知","[邀请名]邀请[被邀名]进群大家热烈欢迎！");
            text = text.replace("[邀请名]",getName(username));
            text=text.replace("[被邀名]",getName(names));
            text=text.replace("[群名字]",quname);
            text=text.replace("[群人数]",(getChatMembers(qun)+1));
            sendm(qun,text,0);
	    }else if(content.contains("二维码")) {
	        String username = 截取.取中间(content,"</link><link name=\"from\" type=\"link_profile\"><memberlist><member><username><![CDATA[","]]");
	        String names = 截取.取中间(content,"<link name=\"adder\" type=\"link_profile\"><memberlist><member><username><![CDATA[","]]");
	        String text = 读("Groups/"+qun,"进退群","进群通知","[邀请名]邀请[被邀名]进群大家热烈欢迎！");
            text = text.replace("[邀请名]",getName(username));
            text=text.replace("[被邀名]",getName(names));
            text=text.replace("[群名字]",quname);
            text=text.replace("[群人数]",(getChatMembers(qun)+1));
            sendMsg(data.talker,text);
	    }
	    if(content.contains("移出")) {
	        String names = 截取.取中间(content,"<link name=\"kickoutname\" type=\"link_profile\"><memberlist><member><username><![CDATA[","]]");
            String text = 读("Groups/"+qun,"进退群","退群通知","[退群名]退出本群，请珍惜在本群的每一天！");
            text=text.replace("[退群名]",names);
            text=text.replace("[群名字]",quname);
            text=text.replace("[群人数]",(getChatMembers(qun)+1));
            sendm(qun,text,0);
	    }
	}
	if(data.type==10000) {
	    if(contant.contains("退出")) {
	        String tqname = 截取.开头(content, "退出");
            String text = 读("Groups/"+qun,"进退群","进群通知","[退群名]退出本群，请珍惜在本群的每一天！");
            text=text.replace("[退群名]",tqname);
            text=text.replace("[群名字]",quname);
            text=text.replace("[群人数]",(getChatMembers(qun)+1));
            sendMsg(data.talker,text);
	    }
	    if(content.contains("管理员")) {
	        sendm(qun,content,0);
	    }
	}
}