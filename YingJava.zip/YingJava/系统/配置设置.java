public static void 配置设置(Object data) {
    String wxid = data.sendTalker;
	String qun = data.talker;
	String content = data.content;
	String name = getName(wxid);
	String 标题 = 读("Groups/"+qun, "Msg", "标题", "无");
	String 全局标题 = 读("全局", "Msg", "标题", "───"+脚本名称+"───");
	String 尾巴 = 读("Groups/"+qun, "Msg", "尾巴", "无");
	String 全局尾巴 = 读("全局", "Msg", "尾巴", "🕓[time2]");
	String 表情 = 读("Groups/"+qun, "Msg", "表情", "无");
	String 全局表情 = 读("全局", "Msg", "表情", "🐮🐯🐶🐱🐭🐹🐷🐸🐣🐥🐙");
	String 表情2 = 读("Groups/"+qun, "Msg", "表情2", "无");
	String 全局表情2 = 读("全局", "Msg", "表情2", "🐸🐰🦊🐻🐼🐨🐯🦁🐮🐵");
	if(mWxid.equals(wxid)) {
	    if(content.equals("切换文字发送")) {
	        删("Groups/"+qun, "Msg", "发送模式");
	        sendm(qun,"已切换文字发送类型",0);
	    }
	    if(content.equals("切换图片发送")) {
	        写("Groups/"+qun, "Msg", "发送模式", "1");
	        sendm(qun,"已切换图片发送类型",0);
	    }
	    if(content.startsWith("设置")) {
	        String text = content.substring(2);
	        if(text.contains("标题")) {
	            text = text.substring(2);
	            if(text==null||text=="") {
	                return;
	            }
	            写("Groups/"+qun, "Msg", "标题", text);
	            sendm(qun,"设置标题成功",0);
	        }
	        if(text.contains("表情1")) {
	            text = text.substring(3);
	            if(text==null||text=="") {
	                return;
	            }
	            写("Groups/"+qun, "Msg", "表情", text);
	            sendm(qun,"设置表情1成功",0);
	        }
	        if(text.contains("表情2")) {
	            text = text.substring(3);
	            if(text==null||text=="") {
	                return;
	            }
	            写("Groups/"+qun, "Msg", "表情2", text);
	            sendm(qun,"设置表情2成功",0);
	        }
	        if(text.contains("尾巴")) {
	            text = text.substring(2);
	            if(text==null||text=="") {
	                return;
	            }
	            写("Groups/"+qun, "Msg", "尾巴", text);
	            sendm(qun,"设置尾巴成功",0);
	        }
	    }
	    if(content.startsWith("恢复默认")) {
	        String text = content.substring(4);
	        if(text.equals("标题")) {
	            删("Groups/"+qun, "Msg", "标题");
	            sendm(qun,"已恢复默认"+text,0);
	        }
	        if(text.equals("表情")) {
	            删("Groups/"+qun, "Msg", "表情");
	            删("Groups/"+qun, "Msg", "表情2");
	            sendm(qun,"已恢复默认"+text,0);
	        }
	        if(text.equals("尾巴")) {
	            删("Groups/"+qun, "Msg", "尾巴");
	            sendm(qun,"已恢复默认"+text,0);
	        }
	    }
	    if(content.startsWith("全局")) {
	        String text = content.substring(2);
	        if(text.contains("标题")) {
	            text = text.substring(2);
	            if(text==null||text=="") {
	                return;
	            }
	            写("全局", "Msg", "标题", text);
	            sendm(qun,"设置全局标题成功",0);
	        }
	        if(text.contains("表情1")) {
	            text = text.substring(3);
	            if(text==null||text=="") {
	                return;
	            }
	            写("全局", "Msg", "表情", text);
	            sendm(qun,"设置全局表情1成功",0);
	        }
	        if(text.contains("表情2")) {
	            text = text.substring(3);
	            if(text==null||text=="") {
	                return;
	            }
	            写("全局", "Msg", "表情2", text);
	            sendm(qun,"设置全局表情2成功",0);
	        }
	        if(text.contains("尾巴")) {
	            text = text.substring(2);
	            if(text==null||text=="") {
	                return;
	            }
	            写("全局", "Msg", "尾巴", text);
	            sendm(qun,"设置全局尾巴成功",0);
	        }
	        if(text.equals("恢复默认")) {
	            删("全局", "Msg", "标题");
	            删("全局", "Msg", "表情");
	            删("全局", "Msg", "表情2");
	            删("全局", "Msg", "尾巴");
	            sendm(qun,"全局已恢复默认",0);
	        }
	    }
	}
	if(content.equals("查看配置信息")) {
	    String text = "@" + name + " \n" + 
	    "全部配置信息↓\n" + 
	    "[本群标题]"+标题+"\n" + 
	    "[本群表情1]"+表情+"\n" + 
	    "[本群表情2]"+表情2+"\n" + 
	    "[本群尾巴]"+尾巴+"\n\n" + 
	    "[全局标题]"+全局标题+"\n" + 
	    "[全局表情1]"+全局表情+"\n" + 
	    "[全局表情2]"+全局表情2+"\n" + 
	    "[全局尾巴]"+全局尾巴;
	    sendm(qun,text,1);
	}
}