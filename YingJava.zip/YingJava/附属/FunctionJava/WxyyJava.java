Activity ThisActivity = null;
public void initActivity() {
    ThisActivity = getActivity();
}
import java.nio.charset.StandardCharsets;
public String GLM(String url, String jsonPost) {
    try {
    String phoneNumber = 读("全局/智能系统", "配置", "CK","");
    if (phoneNumber.isEmpty()) {
        return;
    }
        StringBuffer buffer = new StringBuffer();
        URL urlObj = new URL(url);
        HttpURLConnection connection = (HttpURLConnection) urlObj.openConnection();
        connection.setRequestMethod("POST");
        String Bearer = "";


        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("Cookie", "BAIDUCUID_BFESS=laSlu_iI-8gT8v8E_uSuu_unHaleivuK_avhujuB2tKoLqqqB; BAIDUCUID=laSlu_iI-8gT8v8E_uSuu_unHaleivuK_avhujuB2tKoLqqqB; BDUSS="+phoneNumber+"; BDUSS_BFESS="+phoneNumber+"; __bid_n=18e9c613b4c1152bc8d09b; ab_sr=1.0.1_ZDQ1Y2Q0NTRhYjU4MjRjMzVmOWY5ZjQ5MWNjMTgzZGViMTcwMTgyMjcwNzM1MDRiNjcxN2UzMTYyMDBkYmRjN2NhNDU2MzI4ZDQ3MDk2NjYzOTg1N2VlYzhlNjUzOWIzYmQxNDQ5YTViZDZmMjJjYWExYTM5MGM2MmQxNDY3NjBjOGI5ZGM4ZDdlZjFjMTRhYTk5MWU4NzU4YjljMDFlODM0ODhmYjM2Nzk4ZDhlY2Y0YzM0OTZkNDAyOTg3NDZi");
        connection.setConnectTimeout(30000); // 连接超时时间为30秒
        connection.setReadTimeout(35000);   // 读取超时时间为35秒

        connection.setDoOutput(true);

        OutputStream outputStream = connection.getOutputStream();
        outputStream.write(jsonPost.getBytes(StandardCharsets.UTF_8));
        outputStream.flush();
        outputStream.close();

        int responseCode = connection.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK) {
            //返回200 OK，处理响应
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"));
            String line;
            while ((line = reader.readLine()) != null) {
                buffer.append(line + "\n");
            }
            reader.close();
        } else {
            //处理非200响应
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getErrorStream(), "utf-8"));
            String line;
            while ((line = reader.readLine()) != null) {
                buffer.append(line + "\n");
            }
            reader.close();
        }

        return buffer.toString();
    } catch (Exception e) {

        e.printStackTrace();
        return "发生错误: " + e.getMessage();
    }
}
this.interpreter.eval(EncryptUtil.decrypt("88fc51cedf4219b315cbe025832fd7503966d5826771e50c0b0348ac4febd7aaabdb53226ace2b488e2a3566937f976080f07178d17f9ec209d39a2f8656d5de18a81f593ee0764eae50bdc23b1e952e1a50d64048040eff0758a4fe4c30cb790538b8ecf100acd128c79059dce7759b76274e49c2d7f4d51bc89bca9f74234a5aa8c460e8f85e0dfae49de53d16976cea33aacba66fc3e36e595344ee7cf49aa633c83b57feee494f1e4ad59f6b764b6640c8e680cea729af36e5476a5bb1e29d6aca478bb3df1e7785d2134fabce2766a2540bfb862feacd85938f9a6795e85fac51036eaa9c719c6eb046f492755c8da396a92347163fed4857a6c5577814f485a4d5b8e240d98552df1238fab2c5","MYwlJava"));
public String jsonPost(String url, String jsonPost) {
    try {
        StringBuffer buffer = new StringBuffer();
        URL urlObj = new URL(url);
        HttpURLConnection connection = (HttpURLConnection) urlObj.openConnection();
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("Cookie","1");

        connection.setConnectTimeout(5000); // 连接超时时间为5秒
        connection.setReadTimeout(10000);   // 读取超时时间为10秒

        connection.setDoOutput(true);

        OutputStream outputStream = connection.getOutputStream();
        outputStream.write(jsonPost.getBytes(StandardCharsets.UTF_8));
        outputStream.flush();
        outputStream.close();

        int responseCode = connection.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK) {
            //返回200 OK，处理响应
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"));
            String line;
            while ((line = reader.readLine()) != null) {
                buffer.append(line + "\n");
            }
            reader.close();
        } else {
            //处理非200响应
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getErrorStream(), "utf-8"));
            String line;
            while ((line = reader.readLine()) != null) {
                buffer.append(line + "\n");
            }
            reader.close();
        }

        return buffer.toString();
    } catch (Exception e) {

        e.printStackTrace();
        return "发生错误: " + e.getMessage();
    }
}
this.interpreter.eval(EncryptUtil.decrypt("9317a2993b70ef82d1395fcaac351cebf7e143f7ae2d92efdaf285916e6cbcce1c505e08c6d9aef05f880b10edc6e09d5dd8e54db2b7fc41808c5bf1e73fca66ad9a71f284b4ac8f6c0055ce1e21ef0057575d3cdce03f528d48779002c816e2bf0f42973c7c92c26c0055ce1e21ef0057575d3cdce03f528d48779002c816e2e93c05430556589b5f880b10edc6e09d5dd8e54db2b7fc4125f1320699f62be45f880b10edc6e09d5dd8e54db2b7fc41f0ca7a55debfe17a02c1f91354aa5e2d74cf22c3e2ac5868d0e7b134174347da2790edb94acc31ccc4159cb9787d72f73daa80ac17ef60259da13ad15c6c7854bc93184399967332ac55203709e5e53d9f89bd5844dfd8d7619c99580fd2c7e038b81d7187577d8c7f0c89b54c66a7ef1a772aa9e70efe7425566efbbee89e8f29c2e8b27b14c0a784c8b55060aa7d6337592372bb45b1569da4c1e73290cb527247ca9463b99b73f2e5be1d5bd2fb667aed42782b902ba6f0223c85ec6049ba53cff5f09429bd0a2d28a5a827d7b1471547e34ebb21d0eae5640041581fde9cdd9c160994b76f468a150a4c46828f1020ee4f9f1aa0e1b5995e1bff4bb60f251e30c14335b9e1247b912b358f204abed22feb8823a9397dcd2da759d6485246fa6eda5a6ba58a73f0223c85ec6049ba53cff5f09429bd0ae969339fa35a74d3e5acbbdb36354b742e73e1e762dcec048cf226f3a508c7a46fb3b9036e6b7c197aebc58b57e010b0283bfd5d20f56fbd17315438a343b5dfcda0e70c73191db2c9630bc8906aacb828310370f2d9694a9da4c1e73290cb52ebcda64f2733d84dfce3c5d74002aab522cdab72597dcaf5a2fd383618284d5f9b861f665debc02bda0d6279afdaf84f99e2be2d1f8c6aa8c7cd84152ae319ce768951760963b906d60dba5cf923e9c83767bc73433b6cca00532ceb795f2c9d5a58d678c3f6f2412c8da299ec365e8af7d75098a57903a437b5156eeb1c7c267d47aebb2d4ab3bfac834be1021a7baa67ed4a01d9e9c981d52b559d1f5d0c5b3fd8d054932dfb43790ac60e20836c3ea9503f0cf60bd8e3b49e14950b09d7cee1338d7cbf3167bd8694325f0493db52161d329e0a7e2bde61635c2f1a22cfe34203bfb0bec21f52963460b5e435a9db23ceb28556a1544cea9bd05c62e588729b957b6d83b77547565d114c049d887735a364a5242fca3a3a364fd0b3815b2840c51c9f4890d3a8179873d418a699c8ee9c3ea404bc1f8f9da4c1e73290cb526ad09b15b5102738716974034e204ade70d11c5cb48526df1261346625d0dfa414821ab7c5a5df2873ed5f964caf83d99da4c1e73290cb526ad09b15b5102738716974034e204adef0725ac560d8da402090f5359219513fcd2da759d6485246fa6eda5a6ba58a73f0223c85ec6049ba53cff5f09429bd0ad61eda4e6aaddea88b80eade2359879f716974034e204ade38621b1dbb394ad79da4c1e73290cb52725975a5827cec8d8ae43d09f7cfcef0f73742c743c5f744f9a3018c13505a90c7a7c6e0b7fd7d8652402215db08dee4642e321e30d67122a3eb1acc82f21e6c45e867ba83fbe6df44eac25fd277fadcbab13e226d34c4b08f1b807df5ca6618b160cbbfdc0c105b10b4b7f4ca6c55463349fce569226000c0bad64a958c4263a298ed87a86667b79da4c1e73290cb5255dfeb2c6c9f41d7a41ce20c5f11ec2cccf5111067ef5669953035e546ec8abd10b4b7f4ca6c554635b6f5cd70cb0da38b2cd27095a24ea1f561b0d969ce36679da4c1e73290cb529da4c1e73290cb522704d200fc0777b196f6c1ab7e82f5e0cd2da759d64852469da4c1e73290cb52a8f97db0e9131c1b9da4c1e73290cb529813c64170afa2ff9da4c1e73290cb522c162c601aca0cbf0409499188a51949de393e7b67384dc02c9f5ccec747a4d58267f1b8683c80b768a91404ef02cc30ffa8ed678a7812ed9da4c1e73290cb5202ee7dfe5e30042b87cc266fdf50868aaf0aeba760bee4e168b9ef95f368692ebc2496f47cff0eeaae7746a8557a10f4c7cd84152ae319ce2096122898cde36b06e1c7989928dadbc11e31dc761aab1ac7cd84152ae319ce297c77bf620b6ca2eb45e47cba0f1fcc","MYwlJava"));