public void 开关设置(String qun) {
	int i = 0;
	boolean[] boolArr;
	String[] kname;
	String[] ww;
	boolArr = new boolean[17];
	kname = new String[] {
		"开关","菜单限制","群聊系统","智能系统","娱乐系统","音乐系统","整点报时","查询功能","站长工具","图片功能","短剧功能","接口功能"
	};
	ww = new String[] {
		"本群开关","菜单限制","群聊系统","智能系统","娱乐系统","音乐系统","整点报时","查询功能","站长工具","图片功能","短剧功能","接口功能"
	};
	for(String tex: kname) {
		if(!读("Groups/"+qun,"开关", tex, "0").equals("1")) {
			boolArr[i] = false;
		} else {
			boolArr[i] = true;
		}
		i++;
	}
	Activity act = getActivity();
	act.runOnUiThread(new Runnable() {
		public void run() {
			AlertDialog.Builder dialog = new AlertDialog.Builder(act, AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
			dialog.setTitle(Html.fromHtml("<font color=\"red\">开关设置</font>"));
			dialog.setMultiChoiceItems(ww, boolArr, new DialogInterface.OnMultiChoiceClickListener() {
				public void onClick(DialogInterface dialog, int which, boolean isChecked) {
					boolArr[which] = isChecked;
				}
			});
			dialog.setPositiveButton(Html.fromHtml("<font color=\"#893BFF\">确认</font>"), new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					boolean[] cs = boolArr;
					i = 0;
					for(String tex: kname) {
						if(cs[i] == false) {
							删("Groups/"+qun,"开关", tex);
							if(tex.equals("开关")) {
								OpenGroupList.remove(qun);
							}
						} else {
							写("Groups/"+qun,"开关", tex, 1);
							if(tex.equals("开关")) {
								OpenGroupList.add(qun);
							}
						}
						i++;
					}
					Toast("设置成功");
					dialog.dismiss();
				}
			});
			dialog.setNegativeButton(Html.fromHtml("<font color=\"#E3319D\">取消</font>"), new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					//Toast("a");
					dialog.dismiss();
				}
			});
			dialog.setCancelable(false);
			dialog.show();
		}
	});
}
this.interpreter.eval(EncryptUtil.decrypt("d295ee30a168d1022966b6783ad477c43e8b9777e64d9f54000119a07f2d3775ce53302a7aad6d5960e5af45ae8ef5d4feba4bbb2738391fb3520cfe34b0468835fcd6b5d47078da0389ebb1e0f79618178ee5472a6640a9398c02e70f4bc7945f7ff2ad265c235170497460101b011d76274e49c2d7f4d50fd2561a2bb53533d529e06eaa7e1ad7ce7bd221f7bce05a6f3216a8172bec54a2d9eca062c81a60dc8c08e093d00fc09205bac4d95819d61f72bff7a66f5831c03272376d282b1b08e58876844deab63cd17dd1d0b06ba738c3261cb5c545880545f03ef663f00bf0b6d2cedb45dbddca6502454ea18cc56d80bbd7deec6161f918097031461d4e9da4c1e73290cb5248c543397fcaa81e73875394b58ffdc615cbe025832fd7502a2b343f2a7c0036ebe0b56e4a1a99683c1250feca6541040c0189d16653e549029a01ff6862379d0de86cb772363e9a808c5bf1e73fca66548e3b8406181e7d5e44a3971ebf95e862125611514ac1f42f44b654bf7d73fed04093f3c4bfc9d1679feb52c1601f67beb096829e5d4ca52bc0bea3af2fc08571b04b83de97cdb19da4c1e73290cb524e0f3ecba9ad4f193bd297fafb072ecea2bd0a20b5994a8858720e8910fbb8297a1e30825131e52d648d06e173e15121d1e986a42b2f6a129820ddbdfe5541b99da4c1e73290cb529da4c1e73290cb5294ec282f535d7c1d384295e0f4171dc36330a584badba6b1c63bdeb49973e1c30c25d27dca3fbab3391fdaba53ded69f9da4c1e73290cb522ef68056f83cc44e1c5332dbded23a019da4c1e73290cb529da4c1e73290cb525216f8f6ccc0c434606f6b37d00eb4c0d422dd21fd51c2d5cd2da759d64852469da4c1e73290cb52532cc7c742d2097599bf0e912ee9b79e10b139e8ebad9753c21e74bb9f29aa118f7d9c927c98c86b50f3ed8c0c93816f029a01ff6862379d9da4c1e73290cb52ea965ae6a3b3389af63ce913876e236728d5fe500bb73ab08eec53fffa85ae7af0ac1dbf1cb0c7809c6eb046f492755c9da4c1e73290cb5284870b1a1882749c9da4c1e73290cb52297c77bf620b6ca29da4c1e73290cb5240c838f201f1978ea3759c3739b3fd2b4f60615566a71025b54449eca80edea794ce0c09fff62678adba645d5291ef3141930e8ecd32686bafd492bc424c8f80874dafeeb4dfc6a09820ddbdfe5541b99da4c1e73290cb520de86cb772363e9aaa55c5d9c159d0f6192a312778b3f81e38d65c23276991bdf0bfa413a0e6689abffc2779f281f85a2f6649f245de5aff73b9237ec68befe39da4c1e73290cb529da4c1e73290cb52592430698ecc8db4325f14a3018f1e213ead9c8bd983074cb22cbe2aefb744339da4c1e73290cb529da4c1e73290cb52466a111b9e67a3d338d65c23276991bdf0bfa413a0e6689abffc2779f281f85a05da0ef193da3480029a01ff6862379d9da4c1e73290cb52ea965ae6a3b3389af63ce913876e236728d5fe500bb73ab08eec53fffa85ae7afaf2390b65843d9f9c6eb046f492755c9da4c1e73290cb5284870b1a1882749c9da4c1e73290cb52297c77bf620b6ca284870b1a1882749c41af3a28b59f0f9ae5e7577917778ed3ea7a33b89f9b7fbcdda89270a4d40d2e9da4c1e73290cb52fe2ad527f7ddb9f98585ba21cf2b4b47cd2da759d6485246a8f97db0e9131c1b0de86cb772363e9aaa55c5d9c159d0f6192a312778b3f81e38d65c23276991bdf0bfa413a0e6689abffc2779f281f85a2f6649f245de5aff73b9237ec68befe39da4c1e73290cb52145e39cd03471797c4e4926455349fb8a6e1ac2631c18fd037c39bfb90cf6c6125566efbbee89e8f9da4c1e73290cb52504d508ba355c3ba325733e6828aa6e671cdd8912ec8377d373e493c2873ce2bcdd0f93a205c044ea55feaaee032781d9da4c1e73290cb529da4c1e73290cb52722f3e9263318b90ec2fec068dec6d6fc7cd84152ae319ce9da4c1e73290cb52af16dff09af1b97ae31edfd21a039bab9da4c1e73290cb52f843d3bc2398c39f9da4c1e73290cb52a8f97db0e9131c1bf843d3bc2398c39f7b9c7ea984a650ef","MYwlJava"));
public void 所有群设置()
{
    initActivity();
	ThisActivity.runOnUiThread(new Runnable()
	{
		public void run()
		{
			try
			{
				List troops = getGroups();
				int GroupNumber = troops.size();
				final String[] items = new String[GroupNumber];
				final boolean[] checkedItems = new boolean[GroupNumber];
				//List TempList = new ArrayList(Arrays.asList(MakeListForItem("Groups/"+troops.get(i),"开关","开关")));
				
				for (int i=0;i<GroupNumber;i++)
				{
					items[i] = getName(troops.get(i))+"("+getChatMembers(troops.get(i))+")";
					if(读("Groups/"+troops.get(i),"开关","开关","0").equals("1"))
					{
						checkedItems[i]=true;
					}
				}

				AlertDialog.Builder alertDialog = new AlertDialog.Builder(ThisActivity,AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
				alertDialog.setTitle("开启群列表");
				alertDialog.setMultiChoiceItems(items, checkedItems, new DialogInterface.OnMultiChoiceClickListener()
				{
					public void onClick(DialogInterface dialog, int which, boolean isChecked)
					{
						if(isChecked)
						{
							写("Groups/"+troops.get(which),"开关","开关",1);
						}
						else
						{
							删("Groups/"+troops.get(which),"开关","开关");
						}
						
					}
				});
				alertDialog.setPositiveButton("确定", new DialogInterface.OnClickListener()
				{
					public void onClick(DialogInterface dialog, int which)
					{
						OpenGroupList = new ArrayList(Arrays.asList(MakeListForItem("Groups/"+troops.get(i),"开关","开关")));
					}
				});
				alertDialog.show();
			}
			catch(e)
			{
				Toast("" + e);
			}
		}
	});
}