public String GetTime(int gsh) {
    if(gsh==1) {
	    SimpleDateFormat df = new SimpleDateFormat("yyyy年MM月dd日HH点mm分ss秒");
	    Calendar calendar = Calendar.getInstance();
	    return df.format(calendar.getTime());
	}else if(gsh==2) {
	    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    Calendar calendar = Calendar.getInstance();
	    return df.format(calendar.getTime());
	}else if(gsh==3) {
	    SimpleDateFormat df = new SimpleDateFormat("yyyy年MM月dd日");
	    Calendar calendar = Calendar.getInstance();
	    return df.format(calendar.getTime());
	}else if(gsh==4) {
	    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	    Calendar calendar = Calendar.getInstance();
	    return df.format(calendar.getTime());
	}else if(gsh==5) {
	    SimpleDateFormat df = new SimpleDateFormat("HH点mm分ss秒");
	    Calendar calendar = Calendar.getInstance();
	    return df.format(calendar.getTime());
	}else if(gsh==6) {
	    SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss");
	    Calendar calendar = Calendar.getInstance();
	    return df.format(calendar.getTime());
	}else{
	    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd/HH:mm:ss");
	    Calendar calendar = Calendar.getInstance();
	    return df.format(calendar.getTime());
	}
}
public int GetYear() {
    Calendar calendar = Calendar.getInstance();
    return calendar.get(Calendar.YEAR);
}
public int GetMonth() {
	Calendar calendar = Calendar.getInstance();
	return calendar.get(Calendar.MONTH) + 1;
}
public int GetDay() {
	Calendar calendar = Calendar.getInstance();
	return calendar.get(Calendar.DAY_OF_MONTH);
}
public int GetHour() {
        Calendar calendar = Calendar.getInstance();
        return calendar.get(Calendar.HOUR_OF_DAY);
}
public int GetMinute() {
        Calendar calendar = Calendar.getInstance();
        return calendar.get(Calendar.MINUTE);
}
public int GetSecond() {
        Calendar calendar = Calendar.getInstance();
        return calendar.get(Calendar.SECOND);
}
public String GetWeek() {
    Calendar calendar = Calendar.getInstance();
    int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
    String dayStr = "";
    switch (dayOfWeek) {
        case Calendar.SUNDAY:
            dayStr = "星期日";
            break;
        case Calendar.MONDAY:
            dayStr = "星期一";
            break;
        case Calendar.TUESDAY:
            dayStr = "星期二";
            break;
        case Calendar.WEDNESDAY:
            dayStr = "星期三";
            break;
        case Calendar.THURSDAY:
            dayStr = "星期四";
            break;
        case Calendar.FRIDAY:
            dayStr = "星期五";
            break;
        case Calendar.SATURDAY:
            dayStr = "星期六";
            break;
    }
    return dayStr;
}
public static String formatTime(float time) {
    String suffix="豪秒";
    long seconds=(long)(time/1000);
    String tr=seconds/3600+"时"+(seconds%3600)/60+"分"+seconds%3600%60%60+"秒";
    tr=tr.replace("分0秒","分");
    tr=tr.replace("时0分","时");
    tr=tr.replace("0时","");
    return tr;
}
public class 时间间隔 {
    public static int 天数(String inputDateString) throws ParseException, IllegalArgumentException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date inputDate = formatter.parse(inputDateString);
        Date now = new Date();
        Calendar calendarInput = Calendar.getInstance();
        calendarInput.setTime(inputDate);
        Calendar calendarNow = Calendar.getInstance();
        calendarNow.setTime(now);
        if(calendarInput.after(calendarNow)) {
            throw new IllegalArgumentException("计算失败");
        }
        int days = (int) ((calendarNow.getTimeInMillis() - calendarInput.getTimeInMillis()) / (1000 * 60 * 60 * 24));
        return days;
    }
    public static int 月数(String inputDateString) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date inputDate = formatter.parse(inputDateString);
        Calendar calendarInput = Calendar.getInstance();
        calendarInput.setTime(inputDate);
        Calendar calendarNow = Calendar.getInstance();
        if(calendarInput.after(calendarNow)) {
            throw new IllegalArgumentException("计算失败");
        }
        int yearsDiff = calendarNow.get(Calendar.YEAR) - calendarInput.get(Calendar.YEAR);
        int monthsDiff = calendarNow.get(Calendar.MONTH) - calendarInput.get(Calendar.MONTH);
        if (monthsDiff < 0) {
            yearsDiff--;
            monthsDiff += 12;
        }
        return yearsDiff * 12 + monthsDiff;
    }
    public static int 年数(String inputDateString) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date inputDate = formatter.parse(inputDateString);
        Calendar calendarInput = Calendar.getInstance();
        calendarInput.setTime(inputDate);
        Calendar calendarNow = Calendar.getInstance();
        if(calendarInput.after(calendarNow)) {
            throw new IllegalArgumentException("计算失败");
        }
        int yearsDiff = calendarNow.get(Calendar.YEAR) - calendarInput.get(Calendar.YEAR);
        if (calendarNow.get(Calendar.MONTH) < calendarInput.get(Calendar.MONTH) ||
            (calendarNow.get(Calendar.MONTH) == calendarInput.get(Calendar.MONTH) &&
             calendarNow.get(Calendar.DAY_OF_MONTH) < calendarInput.get(Calendar.DAY_OF_MONTH))) {
            yearsDiff--;
        }
        return yearsDiff;
    }
}
public double GetChanceByDistance(int Distance) {
	int j = 0;
	for(int i = 0; i < 100; i++)
	{
		if(GetRandom(10, 10) < 11 - Distance)
		{
			j++;
		}
	}
	return(double) j / 100;
}
public class 网站状态 {
    public static boolean Get(String urlString) {
        try {
            URL url = new URL(urlString);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            connection.setInstanceFollowRedirects(false);
            int responseCode = connection.getResponseCode();
            return (200 <= responseCode && responseCode <= 299);
        } catch (IOException e) {
            return false;
        }
    }
    public static boolean Post(String urlString) {
        try {
            URL url = new URL(urlString);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setRequestProperty("Content-Length", "0");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            connection.setInstanceFollowRedirects(false);
            int responseCode = connection.getResponseCode();
            return (200 <= responseCode && responseCode <= 299);
        } catch (IOException e) {
            return false;
        }
    }
}
public class 数据处理{
    public static String JSON(String jsonString, String key) {
        JSONObject jsonObject = new JSONObject(jsonString);
        if (jsonObject.has(key)) {
            return jsonObject.getString(key);
        }
        return null;
    }
    public static String JSONlist(String jsonListString,String text1,String text2,String text3,int gs) {
        JSONArray jsonArray = new JSONArray(jsonListString);
        if(gs==1) {
            String jsonlist = "";
            for (int i = 0; i < jsonArray.length(); i++) {
                String text = "";
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                text += "序号="+(i+1)+"\n";
                if(text1!=null) {
                    String text1m = jsonObject.getString(text1);
                    text += text1+"="+text1m+"\n";
                }
                if(text2!=null) {
                    String text2m = jsonObject.getString(text2);
                    text += text2+"="+text2m;
                }
                if(text3!=null) {
                    String text3m = jsonObject.getString(text3);
                    text += "\n"+text3+"="+text3m;
                }
                jsonlist += "\n"+text;
            }
            return jsonlist;
        }else{
            String jsonlist = "";
            for (int i = 0; i < jsonArray.length(); i++) {
                String text = "";
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                if(text1!=null) {
                    String text1m = jsonObject.getString(text1);
                    text += text1+"="+text1m+"\n";
                }
                if(text2!=null) {
                    String text2m = jsonObject.getString(text2);
                    text += text2+"="+text2m;
                }
                if(text3!=null) {
                    String text3m = jsonObject.getString(text3);
                    text += "\n"+text3+"="+text3m;
                }
                jsonlist += "\n"+text;
            }
            return jsonlist;
        }
    }
    public static String xml(String xmlString, String tagName) throws Exception {
        InputStream is = new ByteArrayInputStream(xmlString.getBytes(StandardCharsets.UTF_8));
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(is);
        doc.getDocumentElement().normalize();
        NodeList nList = doc.getElementsByTagName(tagName);
        if (nList.getLength() > 0) {
            Element nNode = (Element) nList.item(0);
            return nNode.getTextContent();
        }
        return null;
    }
}
public int GetRandom(int MiddleInt, int Size) {
	Random rnd = new Random();
	return(int)(rnd.nextGaussian() * Math.sqrt(Size) + MiddleInt);
}
public String secondToTime(long second) {
	if(second == 0) return "0秒";
	long days = second / 86400;
	second = second % 86400;
	long hours = second / 3600;
	second = second % 3600;
	long minutes = second / 60;
	second = second % 60;
	return(days == 0 ? "" : days + "天") + (hours == 0 ? "" : hours + "小时") + (minutes == 0 ? "" : minutes + "分") + (second == 0 ? "" : second + "秒");
}