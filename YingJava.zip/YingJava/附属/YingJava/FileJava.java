Activity ThisActivity = null;
public void initActivity() {
    ThisActivity = getActivity();
}
HashMap FileMemCache = new HashMap();
public 写(QQUin, SetName, ItemName, data) {
    try
	{
        CreateDir(JavaPath + "/data/" + QQUin);
		String UserData = ReadFile(JavaPath + "/data/" + QQUin + "/" + SetName + ".txt");
		JSONObject UserDataJson = null;
		if(UserData.equals("")) {
			UserDataJson = new JSONObject("{}");
		}else{
			UserDataJson = new JSONObject(UserData);
		}
		UserDataJson.put(ItemName, data);
		WriteFile(JavaPath + "/data/" + QQUin + "/" + SetName + ".txt", UserDataJson.toString());
		return;
	}catch(Exception e) {
		return;
	}
}
public 删(QQUin, SetName, ItemName) {
	try
	{
		CreateDir(JavaPath + "/data/" + QQUin);
		String UserData = ReadFile(JavaPath + "/data/" + QQUin + "/" + SetName + ".txt");
		JSONObject UserDataJson = null;
		if(UserData.equals("")) {
			return;
		}else{
			UserDataJson = new JSONObject(UserData);
		}
		UserDataJson.remove(ItemName);
		WriteFile(JavaPath + "/data/" + QQUin + "/" + SetName + ".txt", UserDataJson.toString());
		return;
	}catch(Exception e) {
		return;
	}
}
public String[] MakeListForItem( QQUin, SetName) {
	try
	{
		String UserData = ReadFile(JavaPath + "/data/Groups/" + QQUin + "/" + SetName + ".txt");
		JSONObject UserDataJson = null;
		if(UserData.equals("")) {
			return new String[0];
		}else{
			UserDataJson = new JSONObject(UserData);
	    }
		Iterator it = UserDataJson.keys();
		ArrayList List = new ArrayList();
		while(it.hasNext()) {
			List.add(it.next());
		}
		String[] fintext = List.toArray(new String[0]);
		return fintext;
	}catch(Exception e) {
		return new String[0];
	}
}
public class 截取{
    public static String 取中间(String text, String startMarker, String endMarker) {  
        if (text == null || startMarker == null || endMarker == null) {  
            return null;  
        }
        int startIndex = text.indexOf(startMarker);
        if (startIndex == -1) {
            return null;
        }
        startIndex += startMarker.length();
        int endIndex = text.indexOf(endMarker, startIndex);
        if (endIndex == -1) {
            return null;
        }
        return text.substring(startIndex, endIndex);  
    }
    public static String 开头(String text, String endMarker) {
        if (text == null || endMarker == null) {
            return null;
        }
        int endIndex = text.indexOf(endMarker);
        if (endIndex == -1) {
            return null;
        }
        return text.substring(0, endIndex);
    }
    public static String 末尾(String text, String startMarker) {
        if (text == null || startMarker == null) {
            return null;
        }
        int startIndex = text.indexOf(startMarker);
        if (startIndex == -1) {
            return null;
        }
        return text.substring(startIndex + startMarker.length());
    }
}
public String[] MakeListForItem2(String GroupUin) {
	try
	{
		String UserData = ReadFile("/storage/emulated/0/Android/media/com.tencent.mm/HookVip/data/plugin/" + PluginID + "/" + GroupUin);
		JSONObject UserDataJson = null;
		if(UserData.equals("")) {
			return new String[0];
		}else{
			UserDataJson = new JSONObject(UserData);
	    }
	    Iterator it = UserDataJson.keys();
		ArrayList List = new ArrayList();
		while(it.hasNext()){
			List.add(it.next());
		}
		String[] fintext = List.toArray(new String[0]);
		return fintext;
	}catch(Exception e) {
		return new String[0];
	}
}
public String 读(QQUin, SetName, ItemName, text) {
    String text = text;
	try
	{
		String UserData = ReadFile(JavaPath + "/data/" + QQUin + "/" + SetName + ".txt");
		JSONObject UserDataJson = null;
		if(UserData.equals("")) {
			return text;
		}else{
			UserDataJson = new JSONObject(UserData);
		}
		if(!UserDataJson.has(ItemName)) return text;
		return UserDataJson.getString(ItemName);
	}catch(Exception e) {
		return text;
	}
}
public 写(QQUin, SetName, ItemName, long data) {
	try
	{
		CreateDir(JavaPath + "/data/" + QQUin);
		String UserData = ReadFile(JavaPath + "/data/" + QQUin + "/" + SetName + ".txt");
		JSONObject UserDataJson = null;
		if(UserData.equals("")) {
			UserDataJson = new JSONObject("{}");
		}else{
			UserDataJson = new JSONObject(UserData);
		}
		UserDataJson.put(ItemName, String.valueOf(data));
		WriteFile(JavaPath + "/data/" + QQUin + "/" + SetName + ".txt", UserDataJson.toString());
		return;
	}catch(Exception e) {
		Toast(e+"");
		return;
	}
}
public long 读整(QQUin, SetName, ItemName) {
	try
	{
		String UserData = ReadFile(JavaPath + "/data/" + QQUin + "/" + SetName + ".txt");
		JSONObject UserDataJson = null;
		if(UserData.equals("")) {
			return 0;
		}else{
		    UserDataJson = new JSONObject(UserData);
		}
		if(!UserDataJson.has(ItemName)) return 0;
		return Long.parseLong(UserDataJson.getString(ItemName));;
	}catch(Exception e) {
		return 0;
	}
}
public DeleteItemFile( QQUin, SetName) {
	DeleteFile(JavaPath + "/data/" + QQUin + "/" + SetName + ".txt");
}
public ReadFile(String FilePath) {
    try
	{
		if(FileMemCache.containsKey(FilePath)) {
			return FileMemCache.get(FilePath);
		}
		File file = new File(FilePath);
		if(!file.exists()) {
			file.createNewFile();
		}
		InputStreamReader inputReader = new InputStreamReader(new FileInputStream(file));
		BufferedReader bf = new BufferedReader(inputReader);
		String Text = "";
		while((str = bf.readLine()) != null) {
			Text = Text + "\n"+str;
		}
		if(Text.isEmpty()) {
			return "";
		}
		FileMemCache.put(FilePath,Text.substring(1));
		return Text.substring(1);
	}catch(IOException ioe) {
		return "";
	}
}
public WriteFile(String Path, WriteData) {
	try
	{
		FileMemCache.put(Path,WriteData);
		File file = new File(Path);
		FileOutputStream fos = new FileOutputStream(file);
		if(!file.exists()) {
			file.createNewFile();
		}
		byte[] bytesArray = WriteData.getBytes();
		fos.write(bytesArray);
		fos.flush();
	}catch(IOException ioe) {
		Toast("写入时发生错误,相关信息:\n" + Path + "\n" + ioe);
	}
}
public CreateDir(String Path) {
	File dir = null;
	try
	{
		dir = new File(Path);
		if(!dir.exists()) {
			dir.mkdirs();
		}
	}catch(Exception e) {
		Toast("创建文件夹时发生错误,相关信息:\n" + e);
	}
}
public DeleteFile(String Path) {
	File file = null;
	try
	{
		file = new File(Path);
		if(file.exists()) {
			file.delete();
			FileMemCache.remove(Path);
		}
	}catch(Exception e) {
		Toast("删除文件时发生错误,相关信息:\n" + e);
	}
}
public DeleteDir(String Path)
{
	File file = new File(Path);
	if(file.isFile()) {
		file.delete();
	}else{
		File[] files = file.listFiles();
		if(files == null) {
			file.delete();
		}else{
			for (int i = 0; i < files.length; i++) {
				DeleteDir(files[i].getAbsolutePath());
			}
			file.delete();
		}
	}
}
public SaveDataToFile(String path, byte[] Filedata) throws Exception
    {
        InputStream is = new ByteArrayInputStream(Filedata);
        byte[] bs = new byte[1024];
        int len;
        FileOutputStream out = new FileOutputStream(path, false);
        while((len = is.read(bs)) != -1)
        {
            out.write(bs, 0, len);
        }
        out.close();
        is.close();
    }
public byte[] ReadByteByPath(String Path) {
	File MyFileaaa = new File(Path);
	FileInputStream input= new FileInputStream(MyFileaaa);
	ByteArrayOutputStream output = new ByteArrayOutputStream();
	byte[] buffer = new byte[4096];
	int n = 0;
	while(-1 != (n = input.read(buffer))) {
        output.write(buffer, 0, n);
    }
	return output.toByteArray();
}
public Object ReadObjectFromFile(String Path) {
	try{
		File mfile = new File(Path);
	    if(!mfile.exists()) return new HashMap();
		FileInputStream fileIn = new FileInputStream(Path);
		ObjectInputStream in = new ObjectInputStream(fileIn);
		return in.readObject();
	}catch(e) {
		return new HashMap();
	}
}
public void WriteObjectToFile(String Path,Object WriteData) {
	File file = new File(Path);
    File directory = file.getParentFile();
    if (directory != null && !directory.exists()) {
        directory.mkdirs();
    }
    ByteArrayOutputStream out = new ByteArrayOutputStream();
	ObjectOutputStream output = new ObjectOutputStream(out);
	output.writeObject(WriteData);
	output.flush();
	output.close();
	try{
		SaveDataToFile(Path,out.toByteArray());
	}catch(e) {
		Toast(""+e);
	}
}
import java.text.DecimalFormat;
public static String 目录大小(File folder) {
    if (folder == null || !folder.exists()) {
        return "文件夹不存在或为空";
    }
    long sizeInBytes=getFolderSize(folder);
    double sizeInKB=sizeInBytes / 1024.0; // 文件夹大小（KB）
    DecimalFormat decimalFormat=new DecimalFormat("#.###");
    if (sizeInKB < 1024) {
        return decimalFormat.format(sizeInKB) + "KB";
    } else if (sizeInKB < 1024 * 1024) {
        double sizeInMB=sizeInKB / 1024.0; // 文件夹大小（MB）
        return decimalFormat.format(sizeInMB) + "MB";
    } else {
        double sizeInGB=sizeInKB / (1024.0 * 1024.0); // 文件夹大小（GB）
        return decimalFormat.format(sizeInGB) + "GB";
    }
}
public static long getFolderSize(File folder) {
    long size=0;
    File[] files=folder.listFiles();
    if (files != null) {
        for (File file : files) {
            if (file.isFile()) {
                size += file.length();
            } else if (file.isDirectory()) {
                size += getFolderSize(file);
            }
        }
    }
    return size;
}
public static void xz(String url,String filepath) throws Exception {
	    InputStream input = null;
	    File file=new File(filepath);
	    if(!file.getParentFile().exists()) {
	        file.getParentFile().mkdirs();
	        if(!file.exists()) {
	            file.createNewFile();
	        }
	    }
	    try {
	        URL urlsssss = new URL(url);
	        HttpURLConnection urlConn = (HttpURLConnection) urlsssss.openConnection();
	        input = urlConn.getInputStream();
	        byte[] bs = new byte[1024];
	        int len;
	        FileOutputStream out = new FileOutputStream(filepath, false);
	        while((len = input.read(bs)) != -1) {
	            out.write(bs, 0, len);
	        }
	        out.close();
	        input.close();
	
	    } catch (IOException e) {
	        return;
	    } finally {
	        try {
	            input.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    return;
	}
List OpenGroupList = new ArrayList(Arrays.asList(MakeListForItem("开关","开关")));