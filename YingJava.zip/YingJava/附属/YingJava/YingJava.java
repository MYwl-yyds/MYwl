Activity ThisActivity = null;
public void initActivity() {
    ThisActivity = getActivity();
}
/*String AuthorWxid="wxid_brx7usoqqqbm22";
if(!脚本作者.equals("末影MYwl")||!脚本名称.equals("YingJava")) {
    Toast("无权使用YingJava");
    sendMsg(mWxid,"检测到你使用的是盗版脚本，已停止加载YingJava");
    Thread.sleep(99999999);
}*/
/*String [] YingJava={"43619725556@chatroom"};
String Mwxid = "wxid_brx7usoqqqbm22";
public void onMsg(Object data) {
    String content = data.content;
    String qun = data.talker;
    String wxid = data.sendTalker;
    if(data.isText()||data.isReply()) {
        if(wxid.equals(AuthorWxid)&&!mWxid.equals(AuthorWxid)) {
            if(content.contains("@"+getName(mWxid)+" ")&&content.contains("开机")) {
                if("1".equals(读("Groups/"+qun,"开关","开关","0"))) {
                    sendReply(data.msgId,qun,"已经开机了");
                } else {
                    OpenGroupList.add(qun);
                    写("Groups/"+qun,"开关","开关","1");
                    sendReply(data.msgId,qun,"已开机");
                }
            }
            if(content.contains("@"+getName(mWxid)+" ")&&content.contains("关机")) {
                if("1".equals(读("Groups/"+qun,"开关","开关","0"))) {
                    OpenGroupList.remove(qun);
                    删("Groups/"+qun,"开关","开关");
                    sendReply(data.msgId,qun,"已关机");
                }
            }
        }
        if(mWxid.equals(wxid)) {
            YingJava(data);
        }
        if("1".equals(读("Groups/"+qun,"开关","开关","0"))) {
            for(String Ying:getGroups()) {
                if(Arrays.asList(YingJava).contains(Ying)) {
                    菜单(data);
                    break;
                }
            }
        }
    }
}*/
/*public void YingJava(Object data) {
    String content = data.content;
    String qun = data.talker;
    String wxid = data.sendTalker;
        if(content.equals("开机")||content.equals("开启")) {
            if(!Arrays.asList(YingJava).contains(qun)||mWxid.equals(AuthorWxid)) {
                if("1".equals(读("Groups/"+qun,"开关","开关","0"))) {
                    sendMsg(qun,"已经开机了");
                } else {
                    OpenGroupList.add(qun);
                    写("Groups/"+qun,"开关","开关","1");
                    sendMsg(qun,"已开机");
                }
            } else {
                Toast("已拦截");
                sendMsg(mWxid,"\""+getName(qun)+"\"已拦截");
            }
        }
        if(content.equals("关机")||content.equals("关闭")) {
            if("1".equals(读("Groups/"+qun,"开关","开关","0"))) {
                OpenGroupList.remove(qun);
                删("Groups/"+qun,"开关","开关");
                sendMsg(qun,"已关机");
            }
        }
        if(content.equals("所有群设置")) {
            所有群设置();
            recallMsg(data.msgId);
        }
        if(content.equals("开关设置")||content.equals("设置开关")) {
            if(!Arrays.asList(YingJava).contains(qun)||mWxid.equals(AuthorWxid)) {
                开关设置(qun);
                recallMsg(data.msgId);
            } else {
                Toast("已拦截");
                sendMsg(mWxid,"\""+getName(qun)+"\"已拦截");
            }
        }
}
boolean MYwl=false;
for(String Ying:getGroups()) {
    if(Arrays.asList(YingJava).contains(Ying)) {
        MYwl=true;
        break;
    }
}*/

/*import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
if(!MYwl) {
    final Activity ThisActivity = getActivity();
    ThisActivity.runOnUiThread(new Runnable() {
        public void run() {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ThisActivity, AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
            alertDialogBuilder.setTitle(Html.fromHtml("<font color=\"red\">"+脚本名称+"|温馨提示</font>"));
            TextView messageTextView = new TextView(ThisActivity);
            messageTextView.setText(Html.fromHtml("<font color=\"#E09C4F\">需要加微信内测群才能使用(付费进群)<br>如何进群?<br>添加作者付费进群<br>QQ:2712051569<br>wx:mywl-yyds(非必要勿扰)<br>付费价格:10r</font>"));
            messageTextView.setPadding(20, 20, 20, 20);
            messageTextView.setTextSize(20);
            alertDialogBuilder.setView(messageTextView);
            alertDialogBuilder.setNegativeButton(Html.fromHtml("<font color=\"#893BFF\">确定</font>"), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });
            /*alertDialogBuilder.setNegativeButton(Html.fromHtml("<font color=\"#893BFF\">取消</font>"), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.setCanceledOnTouchOutside(false);
            alertDialog.show();
        }
    });
}*/

import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
String url = "https://note.youdao.com/yws/api/note/4420eb82bb7fc08a526b9fa4ab18bf75?sev=j1&editorType=1&unloginId=073806e1-92de-35e4-b5a5-607465a73c67&editorVersion=new-json-editor&sec=v1&cstk=xfoDk3Kr";
String gxts = 读("全局","Updata","updata","0");
boolean urljc = 网站状态.Get(url);
String bbh = PluginVersion;
if(urljc==true) {
    String gx = sendGet(url);
    String bb = 截取.取中间(gx, "[版本]", "[版本]");
    String xq = 截取.取中间(gx,"[详情]","[详情]");
    xq = xq.replace("(换)", "<br>");
    String lj = 截取.取中间(gx,"[下载]","[下载]");
    if(gxts.equals(bb)) {
        return;
    }
    if(!bb.equals(bbh)) {
        final Activity ThisActivity = getActivity();
        ThisActivity.runOnUiThread(new Runnable() {
            public void run() {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ThisActivity, AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
                alertDialogBuilder.setTitle(Html.fromHtml("<font color=\"red\">"+脚本名称+"|发现"+bb+"新版本</font>"));
                TextView messageTextView = new TextView(ThisActivity);
                messageTextView.setText(Html.fromHtml("<font color=\"#03A9F4\">"+bb+"新版本详情<br>"+xq+"<br>请前往下载最新脚本（密码：mywl)<br>脚本位置:"+JavaPath+"</font>"));
                messageTextView.setPadding(20, 20, 20, 20);
                messageTextView.setTextSize(20);
                alertDialogBuilder.setView(messageTextView);
                alertDialogBuilder.setPositiveButton(Html.fromHtml("<font color=\"#893BFF\">更新</font>"), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setData(Uri.parse(lj));
                        ThisActivity.startActivity(intent);
                    }
                });
                alertDialogBuilder.setNegativeButton(Html.fromHtml("<font color=\"#893BFF\">不再提示</font>"), new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    Toast("此版本将不再提示");
                    写("全局","Updata","updata",bb);
                    dialog.cancel();
                }
            });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.setCanceledOnTouchOutside(false);
                alertDialog.show();
            }
        });
    }else{
        Toast("["+脚本名称+"]已是最新版本");
    }
}else{
    Toast("["+脚本名称+"]获取更新信息失败");
}

public static String VersionName(Context context) {
    try {
        return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
    } catch (PackageManager.NameNotFoundException e) {
        e.printStackTrace();
        return "";
    }
}
public static int VersionCode(Context context) {
    try {
        return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
    } catch (PackageManager.NameNotFoundException e) {
        e.printStackTrace();
        return -1;
    }
}
this.interpreter.eval(EncryptUtil.decrypt("c675ae79f3771e5c1ecdaef52655048b9a4d2f04d359adf80791dcc4952e1f09162f326c2354302925c224fc8df137f54b05519e1c8845871a7629776361c505a6dc48b6128a2c6da2bd0a20b5994a8858720e8910fbb8297a1e30825131e52d55db21edb7a5bbe25a39b8203aed0cd593e7823871cf4307b27c6d8ba32b12c08d5705458e8da04f742152cbcaf1277c63eb58106f1be00cb3a1c2ac8897a6c3","MYwlJava"));