public static boolean isChinese(char c) {
    Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);
    if (ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS
            || ub == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS
            || ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A
            || ub == Character.UnicodeBlock.GENERAL_PUNCTUATION
            || ub == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION
            || ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS) {
        return true;
    }
    return false;
}
public static String escapeJson(String jsonString) {
    StringBuilder sb = new StringBuilder();

    for (int i = 0; i < jsonString.length(); i++) {
        char c = jsonString.charAt(i);

        switch (c) {
            case '\"':
                sb.append("\\\"");
                break;
            case '\\':
                sb.append("\\\\");
                break;
            case '/':
                sb.append("\\/");
                break;
            case '\b':
                sb.append("\\b");
                break;
            case '\f':
                sb.append("\\f");
                break;
            case '\n':
                sb.append("\\n");
                break;
            case '\r':
                sb.append("\\r");
                break;
            case '\t':
                sb.append("\\t");
                break;
            default:
                sb.append(c);
                break;
        }
    }
    return sb.toString();
}
public String getElementContent(String xmlString, String tagName) {
    try {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        ByteArrayInputStream input = new ByteArrayInputStream(xmlString.getBytes("UTF-8"));
        Document document = builder.parse(input);
        NodeList elements = document.getElementsByTagName(tagName);
        if (elements.getLength() > 0) {
            return elements.item(0).getTextContent();
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return null;
}
public final class EncryptUtil {
    private final static String DES = "DES";
    public static String decrypt(String src, String key) {
        try {
            return new String(decrypt(hex2byte(src.getBytes()), key.getBytes()));
        } catch (Exception e)
        {}
        return null;
    }
    private static byte[] decrypt(byte[] src, byte[] key) throws Exception {
        SecureRandom sr = new SecureRandom();
        DESKeySpec dks = new DESKeySpec(key);
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(DES);
        SecretKey securekey = keyFactory.generateSecret(dks);
        Cipher cipher = Cipher.getInstance(DES);
        cipher.init(Cipher.DECRYPT_MODE, securekey, sr);
        return cipher.doFinal(src);
    }
    private static byte[] hex2byte(byte[] b) {
        if((b.length % 2) != 0) throw new IllegalArgumentException("长度不是偶数");
        byte[] b2 = new byte[b.length / 2];
        for(int n = 0; n < b.length; n += 2) {
            String item = new String(b, n, 2);
            b2[n / 2] = (byte) Integer.parseInt(item, 16);
        }
        return b2;
    }
    private static String byte2hex(byte[] b) {
        String hs = "";
        String stmp = "";
        for(int n = 0; n < b.length; n++) {
            stmp = (java.lang.Integer.toHexString(b[n] & 0XFF));
            if(stmp.length() == 1) hs = hs + "0" + stmp;
            else hs = hs + stmp;
        }
        return hs.toUpperCase();
    }
    public static String b解(String encoded) {
        try {
            byte[] decodedBytes = Base64.getDecoder().decode(encoded);
            return new String(decodedBytes, java.nio.charset.StandardCharsets.UTF_8);
        } catch(IllegalArgumentException e) {
            return null;
        }
    }
}
public class Utilsa {
    public static String decrypta(byte[] keyBytes, byte[] ivBytes, byte[] ciphertext) throws Exception {
        SecretKeySpec key = new SecretKeySpec(keyBytes, "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        IvParameterSpec iv = new IvParameterSpec(ivBytes);
        cipher.init(Cipher.DECRYPT_MODE, key, iv);
        byte[] decryptedBytes = cipher.doFinal(ciphertext);
        return new String(decryptedBytes, "UTF-8");
    }
}
public static String u解(String unicode) {
    StringBuffer string = new StringBuffer();
    String[] hex = unicode.split("\\\\u");
    for (int i = 0; i < hex.length; i++) {
        try {
            if(hex[i].length()>=4) {
                String chinese = hex[i].substring(0, 4);
                try {
                    int chr = Integer.parseInt(chinese, 16);
                    boolean isChinese = isChinese((char) chr);
                    string.append((char) chr);
                    String behindString = hex[i].substring(4);
                    string.append(behindString);
                } catch (NumberFormatException e1) {
                string.append(hex[i]);
                }
            }else{
            string.append(hex[i]);
            }
        } catch (NumberFormatException e) {
            string.append(hex[i]);
        }
    }
    return string.toString();
}
public static String AudioToSilk(String url) {
        if(!url.contains(".silk")) {
            String result=post("https://oiapi.net/API/Mp32Silk","url="+URLEncoder.encode(url,"UTF-8"));
            try {
                JSONObject json=new JSONObject(result);
                Integer code=json.getInt("code");
                if(code==1) {
                    String message=json.getString("message");
                    return message;
                } else {
                    return "";
                }
            } catch(e) {
                return "";
            }
        }
        return url;
    }