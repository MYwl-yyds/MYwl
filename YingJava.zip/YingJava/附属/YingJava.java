public String GetRamdomTextChar(String text) {
    String mytext = text;
	ArrayList list = new ArrayList();
	int index = 0;
	while(index < mytext.length()) {
		int offset = mytext.offsetByCodePoints(index,1);
		list.add(index);
		index = offset;
	}
	int rnd = (int) (Math.random()*(list.size()-1));
	return mytext.substring((int)list.get(rnd),(int)list.get(rnd+1));
}
public String fixMessage(String qun, String originalText,int gs) {
    String 标题 = 读("Groups/"+qun, "Msg", "标题", "无");
    String 表情 = 读("Groups/"+qun, "Msg", "表情", "无");
    String 表情2 = 读("Groups/"+qun, "Msg", "表情2", "无");
    String 尾巴 = 读("Groups/"+qun, "Msg", "尾巴", "无");
    if(标题.equals("无")) {
        标题 = 读("全局", "Msg", "标题", "───"+脚本名称+"───");
    }else{
        标题 = 读("Groups/"+qun, "Msg", "标题", "无");
    }
    if(表情.equals("无")) {
        表情 = 读("全局", "Msg", "表情", "🐮🐯🐶🐱🐭🐹🐷🐸🐣🐥🐙");
    }else{
        表情 = 读("Groups/"+qun, "Msg", "表情", "无");
    }
    if(表情2.equals("无")) {
        表情2 = 读("全局", "Msg", "表情2", "🐸🐰🦊🐻🐼🐨🐯🦁🐮🐵");
    }else{
        表情2 = 读("Groups/"+qun, "Msg", "表情2", "无");
    }
    if(尾巴.equals("无")) {
        尾巴 = 读("全局", "Msg", "尾巴", "🕓[time2]");
    }else{
        尾巴 = 读("Groups/"+qun, "Msg", "尾巴", "无");
    }
    String modifiedText = 标题 + "\n" + originalText + "\n" + 尾巴;
    modifiedText = modifiedText.replace("[e]", GetRamdomTextChar(表情));
    modifiedText = modifiedText.replace("[e2]", GetRamdomTextChar(表情2));
    modifiedText = modifiedText.replace("[time1]", GetTime(1));
    modifiedText = modifiedText.replace("[time2]", GetTime(2));
    modifiedText = modifiedText.replace("[time3]", GetTime(3));
    modifiedText = modifiedText.replace("[time4]", GetTime(4));
    modifiedText = modifiedText.replace("[time5]", GetTime(5));
    modifiedText = modifiedText.replace("[time6]", GetTime(6));
    modifiedText = modifiedText.replace("[yy]", sendGet("https://v1.hitokoto.cn/?encode=text"));
    modifiedText = modifiedText.replace("void", "获取异常");
    if(gs==1) {
        modifiedText = modifiedText.replace("[Y]", ""+GetYear());
        modifiedText = modifiedText.replace("[M]", ""+GetMonth());
        modifiedText = modifiedText.replace("[D]", ""+GetDay());
        modifiedText = modifiedText.replace("[h]", ""+GetHour());
        modifiedText = modifiedText.replace("[m]", ""+GetMinute());
        modifiedText = modifiedText.replace("[s]", ""+GetSecond());
        modifiedText = modifiedText.replace("[wd]", ""+GetWeek());
    }
    return modifiedText;
}
public void sendm(String qun, String text, int gs) {
    if ("1".equals(读("Groups/"+qun, "Msg", "发送模式", "0"))) {
        String url = fixMessage(qun,text.replace("\n","\\n"),0);
        String encodedUrl = URLEncoder.encode(url, "UTF-8");
        sendPic(qun,"http://api.mrgnb.cn/api/zt.php?hh=\\n&text="+encodedUrl);
        return;
    } else {
        if(gs==1) {
            sendMsg(qun,text);
            return;
        }else if(gs==2) {
            sendMsg(qun, fixMessage(qun,text,1));
        }else{
            sendMsg(qun, fixMessage(qun,text,0));
            return;
        }
    }
}
public void sendc(int lx,String qun,String 标题,String 介绍,String 封面,String 音源或网页,String id) {
    if(lx==1) {
        JSONObject webData = new JSONObject();
        webData.put("title",标题);
        webData.put("description",介绍);
        webData.put("thumb",封面);
        webData.put("webpageUrl",音源或网页);
        sendWebCard(qun,webData);
    }else{
        JSONObject musicData = new JSONObject();
        musicData.put("title",标题);
        musicData.put("description",介绍);
        musicData.put("thumb",封面);
        musicData.put("musicUrl",封面);
        musicData.put("musicDataUrl",音源或网页);
        if(id==null) {
            id = "wx485a97c844086dc9";
        }
        musicData.put("appId",id);
        sendMusicCard(qun,musicData);
    }
}