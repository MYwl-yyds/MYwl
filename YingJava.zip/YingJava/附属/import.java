//智能系统
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONException;
//娱乐游戏
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Random;
//图片功能
import com.bug.utils.JSONUtils;
//File
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.FileOutputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.File;
//Text
import org.json.JSONObject;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.json.JSONArray;
//Other
import java.security.SecureRandom;
import javax.crypto.Cipher;  
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.SecretKeyFactory;
import javax.crypto.SecretKey;
import java.util.Base64;
import javax.crypto.spec.IvParameterSpec;
import java.util.Arrays;
//Time
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
//Url
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedOutputStream;
import java.io.OutputStream;
//YingJava
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import android.app.AlertDialog;
import android.app.Activity;
import android.text.*;
import android.widget.*;
import android.text.Html;
import android.view.Gravity;
import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;
import android.app.ProgressDialog;
import android.content.DialogInterface;